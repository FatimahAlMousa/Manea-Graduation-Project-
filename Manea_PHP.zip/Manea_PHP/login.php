<?php
session_start();

// ── Handle POST (AJAX login) ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $email    = trim($_POST['email']    ?? '');
    $password =      $_POST['password'] ?? '';

    if (!$email || !$password) {
        echo json_encode(['success' => false, 'message' => 'Email and password are required.']);
        exit;
    }

    $conn = new mysqli('localhost', 'root', 'Root@123', 'manea');
    if ($conn->connect_error) {
        echo json_encode(['success' => false, 'message' => 'DB error: ' . $conn->connect_error]);
        exit;
    }

    $stmt = $conn->prepare('SELECT user_id, full_name, password_hash, role, is_active FROM users WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $conn->close();

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'email_not_found']);
        exit;
    }
    if (!$user['is_active']) {
        echo json_encode(['success' => false, 'message' => 'Your account has been deactivated.']);
        exit;
    }
    if (!password_verify($password, $user['password_hash'])) {
        echo json_encode(['success' => false, 'message' => 'wrong_password']);
        exit;
    }

    // Portal check
    $portalRole = strtoupper(trim($_POST['portal'] ?? ''));
    $actualRole = $user['role'];

    if ($portalRole && $portalRole !== $actualRole) {
        echo json_encode([
            'success' => false,
            'message' => 'wrong_portal',
            'actual'  => ucfirst(strtolower($actualRole))
        ]);
        exit;
    }

    $_SESSION['user_id']   = $user['user_id'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['role']      = $user['role'];

    $redirects = [
        'EMPLOYEE'   => 'employee/dashboard.php',
        'ACCOUNTANT' => 'accountant/dashboard.php',
        'AUDITOR'    => 'http://localhost:5000/dashboard',
    ];

    echo json_encode([
        'success'  => true,
        'message'  => 'Login successful!',
        'role'     => $user['role'],
        'name'     => $user['full_name'],
        'redirect' => $redirects[$user['role']] ?? 'login.php'
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manea &mdash; Login</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root { --teal:#0097B2; --navy:#1F2247; --ivory:#F1F0EC; --teal-light:rgba(0,151,178,0.12); }
    html,body { height:100%; background:var(--ivory); font-family:'DM Sans',sans-serif; color:var(--navy); }
    #bg-canvas { position:fixed; inset:0; z-index:0; pointer-events:none; }
    .page { position:relative; z-index:5; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px; }
    .login-card { background:rgba(255,255,255,.88); backdrop-filter:blur(20px); border:1.5px solid rgba(31,34,71,.09); border-radius:24px; padding:52px 48px 48px; width:100%; max-width:440px; box-shadow:0 24px 64px rgba(31,34,71,.11); animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both; }
    @keyframes fadeUp { from{opacity:0;transform:translateY(22px)} to{opacity:1;transform:translateY(0)} }
    .role-badge { display:inline-flex; align-items:center; gap:6px; font-size:11px; font-weight:600; letter-spacing:.09em; text-transform:uppercase; color:var(--teal); background:var(--teal-light); border:1px solid rgba(0,151,178,.18); padding:5px 12px; border-radius:100px; margin-bottom:22px; }
    .role-badge-dot { width:5px; height:5px; border-radius:50%; background:var(--teal); animation:blink 2s ease-in-out infinite; }
    @keyframes blink { 0%,100%{opacity:1} 50%{opacity:.3} }
    .login-title { font-family:'DM Serif Display',serif; font-size:30px; font-weight:400; letter-spacing:-.02em; line-height:1.2; margin-bottom:8px; }
    .login-subtitle { font-size:14px; color:rgba(31,34,71,.45); margin-bottom:36px; }
    .field { display:flex; flex-direction:column; gap:7px; margin-bottom:20px; }
    .field label { font-size:12.5px; font-weight:600; color:rgba(31,34,71,.6); }
    .field input { width:100%; padding:13px 16px; border-radius:12px; border:1.5px solid rgba(31,34,71,.12); background:rgba(241,240,236,.55); font-family:'DM Sans',sans-serif; font-size:14.5px; color:var(--navy); outline:none; transition:all .2s; }
    .field input:focus { border-color:var(--teal); background:#fff; box-shadow:0 0 0 3.5px rgba(0,151,178,.10); }
    .password-wrapper { position:relative; }
    .password-wrapper input { padding-right:44px; }
    .eye-btn { position:absolute; right:12px; top:50%; transform:translateY(-50%); background:none; border:none; cursor:pointer; padding:4px; color:rgba(31,34,71,.35); transition:color .2s; }
    .eye-btn:hover,.eye-btn.active { color:var(--teal); }
    .field-error { display:none; align-items:center; gap:5px; font-size:12px; font-weight:500; color:#c94040; margin-top:-4px; }
    .field-error.visible { display:flex; }
    .field input.input-error { border-color:#e05252; box-shadow:0 0 0 3.5px rgba(224,82,82,.10); }
    .alert-banner { display:none; align-items:center; gap:10px; padding:12px 15px; border-radius:11px; font-size:13px; font-weight:500; margin-bottom:18px; }
    .alert-banner.error { background:rgba(224,82,82,.09); border:1.5px solid rgba(201,64,64,.20); color:#c94040; }
    .alert-banner.success { background:rgba(0,151,178,.09); border:1.5px solid rgba(0,151,178,.25); color:var(--teal); }
    .alert-banner.visible { display:flex; }
    .back-btn { display:inline-flex; align-items:center; gap:8px; position:fixed; top:20px; left:24px; font-family:'DM Sans',sans-serif; font-size:13.5px; font-weight:600; color:var(--navy); background:#fff; border:1.5px solid rgba(31,34,71,.12); border-radius:10px; padding:10px 18px; cursor:pointer; text-decoration:none; transition:all .2s; box-shadow:0 2px 10px rgba(31,34,71,.10); z-index:999; }
    .back-btn:hover { color:var(--teal); border-color:var(--teal); box-shadow:0 4px 16px rgba(0,151,178,.15); }
    .login-btn { display:flex; align-items:center; justify-content:center; gap:9px; width:100%; margin-top:8px; padding:14px 20px; background:var(--navy); color:#fff; border:none; border-radius:12px; font-family:'DM Sans',sans-serif; font-size:14.5px; font-weight:600; cursor:pointer; transition:all .22s; }
    .login-btn:hover { background:var(--teal); box-shadow:0 8px 24px rgba(0,151,178,.28); transform:translateY(-1px); }
    .login-btn.loading { opacity:.7; pointer-events:none; }
  </style>
</head>
<body>
<canvas id="bg-canvas"></canvas>
<a href="/Manea/Manea_PHP/manea-landing.html" class="back-btn" onclick="window.location.href='/Manea/Manea_PHP/manea-landing.html'; return false;">
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15,18 9,12 15,6"/></svg>
  Back
</a>
<div class="page">
  <div class="login-card">
    <div class="role-badge"><span class="role-badge-dot"></span><span id="role-label">Login</span></div>
    <h1 class="login-title">Welcome back</h1>
    <p class="login-subtitle">Log in to access your dashboard</p>

    <div class="alert-banner error" id="alert-banner">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      <span id="alert-text"></span>
    </div>

    <div class="field">
      <label>Email address</label>
      <input id="email" type="email" placeholder="you@manea.com" autocomplete="email"/>
      <div class="field-error" id="email-error"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><span id="email-error-text"></span></div>
    </div>

    <div class="field">
      <label>Password</label>
      <div class="password-wrapper">
        <input id="password" type="password" placeholder="••••••••" autocomplete="current-password"/>
        <button type="button" class="eye-btn" id="eye-btn" onclick="togglePw()">
          <svg id="eye-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
      </div>
      <div class="field-error" id="pw-error"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><span id="pw-error-text"></span></div>
    </div>

    <button class="login-btn" id="login-btn" onclick="doLogin()">
      Log In
      <svg width="13" height="13" viewBox="0 0 10 10" fill="none" stroke="#fff" stroke-width="2.2"><path d="M2 5h6M6 3l2 2-2 2"/></svg>
    </button>
  </div>
</div>

<script>
  // Role badge from URL
  const role = new URLSearchParams(location.search).get('role') || '';
  document.getElementById('role-label').textContent = role ? role + ' Login' : 'Login';
  document.title = role ? 'Manea — ' + role + ' Login' : 'Manea — Login';

  function showAlert(msg, type='error') {
    const b = document.getElementById('alert-banner');
    document.getElementById('alert-text').textContent = msg;
    b.className = 'alert-banner ' + type + ' visible';
  }
  function fieldErr(inputId, errId, textId, msg) {
    document.getElementById(inputId).classList.add('input-error');
    document.getElementById(textId).textContent = msg;
    document.getElementById(errId).classList.add('visible');
  }
  function clearErr(inputId, errId) {
    document.getElementById(inputId).classList.remove('input-error');
    document.getElementById(errId).classList.remove('visible');
  }

  document.getElementById('email').addEventListener('input', () => { clearErr('email','email-error'); document.getElementById('alert-banner').classList.remove('visible'); });
  document.getElementById('password').addEventListener('input', () => { clearErr('password','pw-error'); document.getElementById('alert-banner').classList.remove('visible'); });
  document.getElementById('email').addEventListener('keydown', e => e.key==='Enter' && doLogin());
  document.getElementById('password').addEventListener('keydown', e => e.key==='Enter' && doLogin());

  async function doLogin() {
    const email = document.getElementById('email').value.trim();
    const pw    = document.getElementById('password').value;
    clearErr('email','email-error'); clearErr('password','pw-error');
    document.getElementById('alert-banner').classList.remove('visible');

    let err = false;
    if (!email) { fieldErr('email','email-error','email-error-text','Please enter your email.'); err=true; }
    if (!pw)    { fieldErr('password','pw-error','pw-error-text','Please enter your password.'); err=true; }
    if (err) return;

    const btn = document.getElementById('login-btn');
    btn.classList.add('loading');

    try {
      const fd = new FormData();
      fd.append('email', email);
      fd.append('password', pw);
      fd.append('portal', role.toUpperCase());

      const res  = await fetch('login.php', { method:'POST', body:fd });
      const data = await res.json();
      btn.classList.remove('loading');

      if (data.success) {
        showAlert('Login successful! Redirecting…', 'success');
        setTimeout(() => { location.href = data.redirect; }, 900);
      } else if (data.message === 'email_not_found') {
        fieldErr('email','email-error','email-error-text','Email not found.');
        showAlert('Email not found. Please check and try again.');
      } else if (data.message === 'wrong_password') {
        fieldErr('password','pw-error','pw-error-text','Incorrect password.');
        showAlert('Incorrect password. Please try again.');
      } else if (data.message === 'wrong_portal') {
        showAlert('Wrong portal. You are registered as ' + data.actual + '.');
      } else {
        showAlert(data.message || 'Login failed.');
      }
    } catch(e) {
      btn.classList.remove('loading');
      showAlert('Connection error. Please try again.');
    }
  }

  function togglePw() {
    const inp = document.getElementById('password');
    const btn = document.getElementById('eye-btn');
    const ico = document.getElementById('eye-icon');
    const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    btn.classList.toggle('active', show);
    ico.innerHTML = show
      ? '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>'
      : '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
  }

  // Animated background
  const canvas = document.getElementById('bg-canvas');
  const ctx = canvas.getContext('2d');
  let W, H, dots, mouse={x:-999,y:-999};
  function resize(){ W=canvas.width=innerWidth; H=canvas.height=innerHeight; dots=[]; for(let r=0;r<Math.ceil(H/44)+1;r++) for(let c=0;c<Math.ceil(W/44)+1;c++) dots.push({bx:c*44,by:r*44,phase:Math.random()*Math.PI*2,speed:.4+Math.random()*.6}); }
  window.addEventListener('mousemove',e=>{mouse.x=e.clientX;mouse.y=e.clientY;});
  window.addEventListener('resize',resize); resize();
  let f=0;
  (function draw(){ requestAnimationFrame(draw); f++; const t=f*.012;
    ctx.clearRect(0,0,W,H); ctx.fillStyle='#F1F0EC'; ctx.fillRect(0,0,W,H);
    dots.forEach(d=>{ const x=d.bx+Math.sin(t*d.speed+d.phase)*3.5, y=d.by+Math.cos(t*d.speed*.8+d.phase+1)*3.5;
      const dist=Math.hypot(x-mouse.x,y-mouse.y), prox=Math.max(0,1-dist/140);
      ctx.fillStyle=`rgba(0,151,178,${.18+prox*.55})`; ctx.beginPath(); ctx.arc(x,y,1.4+prox*2.5,0,Math.PI*2); ctx.fill(); }); })();
</script>
</body>
</html>
