<?php
/**
 * Manea — Shared Helpers
 */

function json_response(bool $success, string $message, array $data = []): never {
    header('Content-Type: application/json');
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $data));
    exit;
}

function require_employee(PDO $pdo): array {
    if (session_status() === PHP_SESSION_NONE) session_start();

    $userId = $_SESSION['user_id'] ?? null;
    $role   = $_SESSION['role']   ?? null;

    if (!$userId || $role !== 'EMPLOYEE') {
        header('Location: ../login.php?role=Employee');
        exit;
    }

    $stmt = $pdo->prepare('SELECT user_id, full_name, email, role, department FROM users WHERE user_id = ? AND is_active = 1');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        session_destroy();
        header('Location: ../login.php?role=Employee');
        exit;
    }

    return $user;
}

function require_accountant(\mysqli $conn): array {
    if (session_status() === PHP_SESSION_NONE) session_start();

    $userId = $_SESSION['user_id'] ?? null;
    $role   = $_SESSION['role']   ?? null;

    if (!$userId || $role !== 'ACCOUNTANT') {
        header('Location: ../login.php?role=Accountant');
        exit;
    }

    $stmt = $conn->prepare('SELECT user_id, full_name, email, role FROM users WHERE user_id = ? AND is_active = 1');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        session_destroy();
        header('Location: ../login.php?role=Accountant');
        exit;
    }

    return $user;
}

function employee_code(int $userId): string {
    return 'EMP-' . str_pad($userId, 3, '0', STR_PAD_LEFT);
}

function initials(string $fullName): string {
    $parts = explode(' ', trim($fullName));
    $init  = '';
    foreach ($parts as $p) {
        if ($p !== '') $init .= mb_strtoupper(mb_substr($p, 0, 1));
        if (mb_strlen($init) >= 2) break;
    }
    return $init ?: '?';
}

function flag_reason_to_invoice_status(?string $flagReason): ?string {
    if (!$flagReason) return null;
    return match($flagReason) {
        'AI_AMOUNT_MISMATCH'  => 'Mismatch',
        'DUPLICATE_INVOICE'   => 'Duplicate',
        'OVERDUE_TRANSACTION' => 'Overdue',
        'MANUAL_REVIEW'       => 'Under Review',
        default               => 'Flagged',
    };
}

function invoice_due_text(?string $txnDate, string $invoiceStatus, ?string $dueDate): string {
    if (in_array($invoiceStatus, ['Uploaded','Mismatch','Duplicate','Flagged','Under Review'])) {
        return '';
    }
    // For Overdue status, always show how many days overdue
    if ($invoiceStatus === 'Overdue') {
        $due = $dueDate ? strtotime($dueDate) : ($txnDate ? strtotime($txnDate . ' +7 days') : null);
        if (!$due) return 'Overdue';
        $diff = (int)(($due - time()) / 86400);
        if ($diff >= 0) return 'Due today';
        return abs($diff) . ' day' . (abs($diff) !== 1 ? 's' : '') . ' overdue';
    }
    if (!$dueDate && !$txnDate) return 'Due soon';
    $due = $dueDate ? strtotime($dueDate) : strtotime($txnDate . ' +7 days');
    $now  = time();
    $diff = (int)(($due - $now) / 86400);
    if ($diff < 0)  return abs($diff) . ' day' . (abs($diff) !== 1 ? 's' : '') . ' overdue';
    if ($diff === 0) return 'Due today';
    return 'Due in ' . $diff . ' day' . ($diff !== 1 ? 's' : '');
}

function map_request_status(string $status, bool $hasFlagged = false): string {
    if ($hasFlagged) return 'Flagged';
    return match(strtoupper($status)) {
        'PENDING'        => 'Pending',
        'APPROVED'       => 'Approved',
        'ACTIVE'         => 'Spending',
        'READY_TO_CLOSE' => 'Ready to Close',
        'COMPLETED',
        'CLOSED'         => 'Completed',
        'REJECTED'       => 'Rejected',
        'CANCELED'       => 'Canceled',
        default          => ucfirst(strtolower($status)),
    };
}

function format_sar(float $amount): string {
    return number_format($amount, 2) . ' SAR';
}
