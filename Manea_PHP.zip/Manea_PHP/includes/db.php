<?php
/**
 * Manea — Shared Database Connection
 * MySQL Community Server: localhost:3306  pass=Root@123  db=manea
 */

function manea_mysqli(): mysqli {
    static $conn = null;
    if ($conn instanceof mysqli) return $conn;

    $conn = new mysqli('localhost', 'root', 'Root@123', 'manea', 3306);

    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode(['error' => 'DB error: ' . $conn->connect_error]));
    }

    $conn->set_charset('utf8mb4');
    return $conn;
}

function manea_pdo(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $pdo = new PDO(
        'mysql:host=localhost;port=3306;dbname=manea;charset=utf8mb4',
        'root', 'Root@123',
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
    return $pdo;
}

$conn = manea_mysqli();
$pdo  = manea_pdo();
