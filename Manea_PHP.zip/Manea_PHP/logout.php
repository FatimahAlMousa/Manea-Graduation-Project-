<?php
session_start();
$role = $_SESSION['role'] ?? '';
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time()-42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

// Redirect to correct login page based on role
$roleMap = [
    'EMPLOYEE'   => 'Employee',
    'ACCOUNTANT' => 'Accountant',
    'AUDITOR'    => 'Auditor',
];
$roleParam = $roleMap[$role] ?? 'Employee';
header('Location: login.php?role=' . $roleParam);
exit;
