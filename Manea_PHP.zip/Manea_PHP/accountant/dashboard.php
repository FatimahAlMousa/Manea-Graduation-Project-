<?php
session_start();
require_once __DIR__ . '/../includes/db.php';
if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'ACCOUNTANT') { header('Location: ../login.php?role=Accountant'); exit; }

// fetch user
$userId = $_SESSION['user_id'] ?? null;

$name = "Accountant";
$initials = "A";

if ($userId) {

  $stmt = $conn->prepare("
    SELECT full_name
    FROM users
    WHERE user_id = ?
  ");

  $stmt->bind_param("i", $userId);
  $stmt->execute();

  $row = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if (!empty($row['full_name'])) {
    $name = $row['full_name'];
    $parts = explode(' ', $name);
    $initials = strtoupper(($parts[0][0] ?? '') . ($parts[1][0] ?? ''));
  }
}
?>




<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manea &mdash; Accountant Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet"/>
  <style>

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --teal:#0097B2; --teal-dim:rgba(0,151,178,.12); --teal-mid:rgba(0,151,178,.22);
      --navy:#1F2247; --navy-faint:rgba(31,34,71,.06); --navy-dim:rgba(31,34,71,.45);
      --ivory:#F1F0EC; --green:#059669; --green-dim:rgba(5,150,105,.10);
      --red:#DC2626; --red-dim:rgba(220,38,38,.10); --amber:#D97706; --amber-dim:rgba(217,119,6,.10);
      --purple:#7C3AED; --purple-dim:rgba(124,58,237,.10);
	  --brown: #6b3f2a;
      --brown-dim: rgba(107, 63, 42, 0.12);
      --sidebar-w:260px; --sidebar-col:66px;
    }
    html,body{height:100%;background:var(--ivory);font-family:'DM Sans',sans-serif;color:var(--navy);overflow:hidden;}
    .app{display:flex;height:100vh;overflow:hidden;}
    .sidebar{width:var(--sidebar-w);background:var(--navy);display:flex;flex-direction:column;transition:width .25s cubic-bezier(.4,0,.2,1);flex-shrink:0;overflow:hidden;z-index:30;}
    .sidebar.collapsed{width:var(--sidebar-col);}
    .sb-head{display:flex;align-items:center;justify-content:space-between;padding:18px 14px;border-bottom:1px solid rgba(255,255,255,.07);min-height:76px;gap:8px;}
    .sidebar.collapsed .sb-head{justify-content:center;}
    .sb-wordmark-wrap { flex:1; display:flex; align-items:center; justify-content:center; }
    .sb-wordmark-svg { width:120px; height:auto; display:block; }
    .sidebar.collapsed .sb-wordmark-wrap { display:none; }
    .sb-toggle{width:30px;height:30px;border-radius:7px;background:rgba(255,255,255,.08);border:none;color:rgba(255,255,255,.55);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .2s;flex-shrink:0;}
    .sb-toggle:hover{background:rgba(255,255,255,.15);}
    .sb-role{margin:12px 14px 4px;font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal);background:rgba(0,151,178,.12);padding:4px 10px;border-radius:6px;display:inline-block;transition:opacity .2s;}
    .sidebar.collapsed .sb-role{opacity:0;pointer-events:none;}
    .sb-nav{flex:1;padding:8px 10px;display:flex;flex-direction:column;gap:2px;overflow-y:auto;}
    .nav-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;color:rgba(255,255,255,.45);border:1px solid transparent;cursor:pointer;transition:all .17s;font-size:13px;font-weight:400;white-space:nowrap;background:none;width:100%;text-align:left;font-family:'DM Sans',sans-serif;}
    .nav-item:hover{color:rgba(255,255,255,.8);background:rgba(255,255,255,.07);}
    .nav-item.active{color:#fff;background:rgba(0,151,178,.18);border-color:rgba(0,151,178,.32);font-weight:600;}
    .nav-icon{flex-shrink:0;width:18px;height:18px;display:flex;align-items:center;justify-content:center;}
    .nav-label{flex:1;}
    .sidebar.collapsed .nav-label{display:none;}
    .sidebar.collapsed .nav-item{justify-content:center;padding:11px 0;}
    .nav-badge{font-size:10.5px;font-weight:700;background:var(--teal);color:#fff;border-radius:20px;padding:2px 8px;min-width:22px;text-align:center;flex-shrink:0;}
    .sidebar.collapsed .nav-badge{display:none;}
    .main{flex:1;display:flex;flex-direction:column;overflow:hidden;}
    .topbar{height:64px;background:rgba(255,255,255,.88);backdrop-filter:blur(14px);border-bottom:1px solid rgba(31,34,71,.07);display:flex;align-items:center;justify-content:space-between;padding:0 28px;flex-shrink:0;gap:16px;}
    .page-title{font-family:'DM Serif Display',serif;font-size:20px;font-weight:400;color:var(--navy);letter-spacing:-.015em;}
    .topbar-right{display:flex;align-items:center;gap:10px;}
    .icon-btn{width:36px;height:36px;border-radius:10px;background:var(--navy-faint);border:1px solid rgba(31,34,71,.08);display:flex;align-items:center;justify-content:center;color:var(--navy-dim);cursor:pointer;transition:all .2s;position:relative;}
    .icon-btn:hover{background:var(--teal-dim);color:var(--teal);}
    .notif-dot{position:absolute;top:7px;right:7px;width:7px;height:7px;border-radius:50%;background:var(--red);border:2px solid #fff;}

#notif-dot {
  display: none;
}

#notif-dot.active {
  display: block;
}
    .user-pill{display:flex;align-items:center;gap:9px;padding:5px 14px 5px 6px;background:var(--navy-faint);border-radius:100px;border:1px solid rgba(31,34,71,.08);}
    .avatar{width:28px;height:28px;border-radius:50%;background:var(--teal);display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;font-weight:700;}
    .user-name{font-size:13px;font-weight:500;color:var(--navy);}
    .logout-btn{display:flex;align-items:center;gap:7px;font-size:13px;font-weight:500;color:var(--navy-dim);background:transparent;border:1.5px solid rgba(31,34,71,.10);border-radius:100px;padding:7px 14px;cursor:pointer;transition:all .2s;font-family:'DM Sans',sans-serif;}
    .logout-btn:hover{color:var(--red);border-color:rgba(220,38,38,.25);}
    .content{flex:1;overflow-y:auto;padding:28px;}
    .view{display:none;} .view.active{display:block;}
    @keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
    .stats-grid{display:grid;gap:16px;margin-bottom:24px;}
    .stat-card{background:rgba(255,255,255,.88);backdrop-filter:blur(10px);border:1.5px solid rgba(31,34,71,.08);border-radius:16px;padding:20px 22px;display:flex;flex-direction:column;gap:10px;transition:transform .2s,box-shadow .2s;animation:fadeUp .4s ease both;}
    .stat-card:hover{transform:translateY(-2px);box-shadow:0 10px 30px rgba(31,34,71,.09);}
    .stat-icon{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;}
    .stat-label{font-size:11.5px;font-weight:600;color:var(--navy-dim);letter-spacing:.04em;text-transform:uppercase;}
    .stat-value{font-family:'DM Serif Display',serif;font-size:32px;font-weight:400;color:var(--navy);line-height:1;letter-spacing:-.02em;}
    .stat-change{font-size:12px;font-weight:500;display:flex;align-items:center;gap:4px;}
    .stat-change.up{color:var(--green);} .stat-change.down{color:var(--red);}
    .panel{background:rgba(255,255,255,.88);backdrop-filter:blur(10px);border:1.5px solid rgba(31,34,71,.08);border-radius:16px;overflow:hidden;margin-bottom:20px;animation:fadeUp .4s ease both;}
    .panel-header{padding:18px 22px 14px;border-bottom:1px solid rgba(31,34,71,.06);display:flex;align-items:center;justify-content:space-between;}
    .panel-title{font-family:'DM Serif Display',serif;font-size:18px;font-weight:400;color:var(--navy);}
    .panel-sub{font-size:13px;color:var(--navy-dim);margin-top:2px;}
    .filter-bar{display:flex;gap:8px;align-items:center;padding:14px 22px;border-bottom:1px solid rgba(31,34,71,.05);flex-wrap:wrap;}
    .filter-pill{padding:5px 14px;border-radius:20px;font-size:12px;font-weight:500;border:1.5px solid rgba(31,34,71,.10);color:var(--navy-dim);cursor:pointer;transition:all .17s;background:transparent;font-family:'DM Sans',sans-serif;}
    .filter-pill:hover{border-color:var(--teal);color:var(--teal);}
    .filter-pill.active{background:var(--teal);border-color:var(--teal);color:#fff;font-weight:600;}
    .search-box{display:flex;align-items:center;gap:8px;padding:7px 14px;background:var(--navy-faint);border:1.5px solid rgba(31,34,71,.08);border-radius:10px;margin-left:auto;}
    .search-box input{border:none;background:transparent;font-family:'DM Sans',sans-serif;font-size:13px;color:var(--navy);outline:none;width:160px;}
    .search-box input::placeholder{color:rgba(31,34,71,.3);}
    .tbl-head{display:grid;padding:10px 22px;border-bottom:1px solid rgba(31,34,71,.06);background:rgba(31,34,71,.02);}
    .th{font-size:10.5px;font-weight:700;color:rgba(31,34,71,.38);text-transform:uppercase;letter-spacing:.07em;}
    .tbl-row{display:grid;padding:13px 22px;align-items:center;min-height:52px;border-bottom:1px solid rgba(31,34,71,.045);transition:background .13s;}
    .tbl-row:last-child{border-bottom:none;}
    .tbl-row:hover{background:rgba(0,151,178,.03);}
    .cell{font-size:13.5px;color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
    .cell.mono{font-family:'IBM Plex Mono',monospace;font-size:12px;font-weight:600;color:var(--teal);}
    .cell.muted{color:var(--navy-dim);font-size:12.5px;}
    .cell.bold{font-weight:600;}
    .badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:6px;font-size:11.5px;font-weight:600;white-space:nowrap;}
    .badge-teal{background:var(--teal-dim);color:var(--teal);}
    .badge-green{background:var(--green-dim);color:var(--green);}
    .badge-red{background:var(--red-dim);color:var(--red);}
    .badge-amber{background:var(--amber-dim);color:var(--amber);}
    .badge-navy{background:var(--navy-faint);color:var(--navy);}
    .badge-purple{background:var(--purple-dim);color:var(--purple);}
    .badge-dot{width:5px;height:5px;border-radius:50%;background:currentColor;display:inline-block;}
    .btn{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .15s;font-family:'DM Sans',sans-serif;}
    .btn-primary{background:var(--navy);color:#fff;} .btn-primary:hover{background:var(--teal);box-shadow:0 6px 18px rgba(0,151,178,.25);}
    .btn-teal{background:var(--teal-dim);color:var(--teal);border-color:rgba(0,151,178,.2);} .btn-teal:hover{background:var(--teal);color:#fff;}
    .btn-review{background:var(--teal-dim);color:var(--teal);border-color:rgba(0,151,178,.18);} .btn-review:hover{background:var(--teal);color:#fff;}
    .btn-approve{background:var(--green-dim);color:var(--green);border-color:rgba(5,150,105,.2);} .btn-approve:hover{background:var(--green);color:#fff;}
    .btn-reject{background:var(--red-dim);color:var(--red);border-color:rgba(220,38,38,.2);} .btn-reject:hover{background:var(--red);color:#fff;}
    .pri-high{background:rgba(220,38,38,.08);color:var(--red);border:1px solid rgba(220,38,38,.18);border-radius:6px;padding:3px 10px;font-size:11.5px;font-weight:600;display:inline-block;white-space:nowrap;}
    .pri-medium{background:rgba(217,119,6,.08);color:var(--amber);border:1px solid rgba(217,119,6,.18);border-radius:6px;padding:3px 10px;font-size:11.5px;font-weight:600;display:inline-block;white-space:nowrap;}
    .pri-low{background:rgba(5,150,105,.08);color:var(--green);border:1px solid rgba(5,150,105,.18);border-radius:6px;padding:3px 10px;font-size:11.5px;font-weight:600;display:inline-block;white-space:nowrap;}
    .modal-overlay{display:none;position:fixed;inset:0;z-index:100;background:rgba(31,34,71,.45);backdrop-filter:blur(4px);align-items:center;justify-content:center;}
    .modal-overlay.open{display:flex;animation:fadeIn .2s ease;}
    @keyframes fadeIn{from{opacity:0}to{opacity:1}}
    .modal{background:#fff;border-radius:16px;width:100%;max-width:560px;overflow:hidden;box-shadow:0 24px 64px rgba(31,34,71,.22);animation:slideUp .25s cubic-bezier(.22,1,.36,1);}
    @keyframes slideUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
    .modal-hdr{background:var(--navy);padding:14px 24px;display:flex;align-items:flex-start;justify-content:space-between;}
    .modal-title{font-family:'DM Serif Display',serif;font-size:19px;font-weight:400;color:#fff;}
    .modal-sub{font-size:12px;color:rgba(255,255,255,.45);margin-top:3px;font-family:'IBM Plex Mono',monospace;}
    .modal-close{width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.10);border:none;color:rgba(255,255,255,.7);cursor:pointer;display:flex;align-items:center;justify-content:center;}
    .modal-close:hover{background:rgba(255,255,255,.2);}
    .modal-body{padding:12px 24px 4px;}
    .modal-row{display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid rgba(31,34,71,.07);}
    .modal-row:last-of-type{border-bottom:none;}
    .modal-row-label{font-size:13px;color:var(--navy-dim);}
    .modal-row-value{font-size:13px;font-weight:500;color:var(--navy);text-align:right;}
    .modal-row-value.teal{color:var(--teal);font-family:'IBM Plex Mono',monospace;font-weight:600;}
    .modal-confirm{background:rgba(31,34,71,.04);border-top:1px solid rgba(31,34,71,.07);padding:10px 24px;text-align:center;font-size:13px;font-weight:600;color:var(--navy);margin-top:4px;}
    .modal-footer{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;padding:10px 24px 16px;}
    .modal-btn-approve{padding:12px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--green);color:#fff;transition:all .18s;}
    .modal-btn-approve:hover{background:#047857;}
    .modal-btn-reject{padding:12px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--red);color:#fff;transition:all .18s;}
    .modal-btn-reject:hover{background:#b91c1c;}
    .modal-btn-cancel{padding:12px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:600;cursor:pointer;background:rgba(31,34,71,.07);border:1.5px solid rgba(31,34,71,.12);color:var(--navy);}
    .toast{position:fixed;bottom:28px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--navy);color:#fff;padding:12px 22px;border-radius:10px;font-size:13.5px;font-weight:500;box-shadow:0 8px 24px rgba(31,34,71,.25);opacity:0;transition:opacity .3s,transform .3s;z-index:300;pointer-events:none;}
    .toast.show{opacity:1;transform:translateX(-50%) translateY(0);}
    .empty{padding:48px;text-align:center;color:var(--navy-dim);font-size:14px;}
    ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:transparent;} ::-webkit-scrollbar-thumb{background:rgba(31,34,71,.12);border-radius:3px;}
    .drop-zone{border:2px dashed rgba(31,34,71,.15);border-radius:14px;padding:52px 24px;text-align:center;background:rgba(241,240,236,.4);transition:all .2s;cursor:pointer;}
    .drop-zone.drag{border-color:var(--teal);background:rgba(0,151,178,.04);}

    .stats-grid{ grid-template-columns:repeat(4,1fr); }
    .stats-grid-3{ grid-template-columns:repeat(3,1fr); }
    @media(max-width:1100px){.stats-grid{grid-template-columns:repeat(2,1fr)}}

    /* NOTIFICATION DROPDOWN */
    .notif-panel{display:none;position:fixed;top:72px;right:28px;width:340px;background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(31,34,71,.22),0 4px 16px rgba(31,34,71,.10);border:1.5px solid rgba(31,34,71,.08);z-index:99999;overflow:hidden;}
    .notif-panel.open{display:block;animation:slideDown .2s cubic-bezier(.22,1,.36,1);}
    @keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
    .notif-panel-header{display:flex;align-items:center;justify-content:space-between;padding:16px 18px 12px;border-bottom:1px solid rgba(31,34,71,.07);}
    .notif-panel-title{font-family:'DM Serif Display',serif;font-size:16px;font-weight:400;color:var(--navy);}
    .notif-count{font-size:11px;font-weight:700;background:var(--teal);color:#fff;border-radius:20px;padding:2px 8px;}
    .notif-actions{display:flex;gap:8px;align-items:center;}
    .notif-mark-all{font-size:11.5px;font-weight:600;color:var(--teal);background:none;border:none;cursor:pointer;font-family:'DM Sans',sans-serif;padding:0;}
    .notif-mark-all:hover{text-decoration:underline;}
    .notif-list{max-height:360px;overflow-y:auto;}
    .notif-item{display:flex;align-items:flex-start;gap:12px;padding:13px 18px;border-bottom:1px solid rgba(31,34,71,.05);cursor:pointer;transition:background .13s;}
    .notif-item:last-child{border-bottom:none;}
    .notif-item:hover{background:rgba(0,151,178,.04);}
    .notif-item.unread{background:rgba(0,151,178,.05);}
    .notif-item.unread:hover{background:rgba(0,151,178,.09);}
    .notif-icon{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;}
    .notif-body{flex:1;min-width:0;}
    .notif-msg{font-size:13px;font-weight:500;color:var(--navy);line-height:1.45;margin-bottom:4px;}
    .notif-item.unread .notif-msg{font-weight:600;}
    .notif-time{font-size:11px;color:rgba(31,34,71,.38);font-family:'IBM Plex Mono',monospace;}
    .notif-unread-dot{width:7px;height:7px;border-radius:50%;background:var(--teal);flex-shrink:0;margin-top:6px;}
    .notif-empty{padding:36px 18px;text-align:center;color:var(--navy-dim);font-size:13px;}
    .notif-footer{padding:12px 18px;border-top:1px solid rgba(31,34,71,.07);text-align:center;}
    .notif-footer-btn{font-size:12.5px;font-weight:600;color:var(--teal);background:none;border:none;cursor:pointer;font-family:'DM Sans',sans-serif;display:inline-flex;align-items:center;gap:5px;}
    .notif-footer-btn:hover{text-decoration:underline;}

    /* DECLINE REASON MODAL */
    .decline-overlay{display:none;position:fixed;inset:0;z-index:200;background:rgba(31,34,71,.5);backdrop-filter:blur(4px);align-items:center;justify-content:center;}
    .decline-overlay.open{display:flex;animation:fadeIn .18s ease;}
    .decline-box{background:#fff;border-radius:16px;width:100%;max-width:440px;overflow:hidden;box-shadow:0 24px 64px rgba(31,34,71,.22);animation:slideUp .22s cubic-bezier(.22,1,.36,1);}
    .decline-hdr{background:var(--navy);padding:18px 22px;display:flex;align-items:center;justify-content:space-between;}
    .decline-hdr-title{font-family:'DM Serif Display',serif;font-size:18px;color:#fff;}
    .decline-hdr-sub{font-size:11px;color:rgba(255,255,255,.45);margin-top:2px;font-family:'IBM Plex Mono',monospace;}
    .decline-body{padding:20px 22px;}
    .decline-label{font-size:12px;font-weight:600;color:var(--navy-dim);letter-spacing:.04em;text-transform:uppercase;margin-bottom:8px;}
    .decline-textarea{width:100%;min-height:110px;padding:12px 14px;border:1.5px solid rgba(31,34,71,.12);border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13.5px;color:var(--navy);resize:vertical;outline:none;background:rgba(241,240,236,.4);transition:border-color .2s,box-shadow .2s;}
    .decline-textarea::placeholder{color:rgba(31,34,71,.3);}
    .decline-textarea:focus{border-color:var(--teal);background:#fff;box-shadow:0 0 0 3px rgba(0,151,178,.10);}
    .decline-footer{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:0 22px 20px;}
    .decline-submit{padding:13px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--red);color:#fff;transition:all .15s;}
    .decline-submit:hover{background:#b91c1c;}
    .decline-cancel{padding:13px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:600;cursor:pointer;background:rgba(31,34,71,.07);border:1.5px solid rgba(31,34,71,.12);color:var(--navy);}
    .decline-cancel:hover{background:rgba(31,34,71,.12);}

    /* CONFIRMATION DIALOG */
    .confirm-overlay {
  display: none;
  position: fixed;
  inset: 0;
  z-index: 20000;
  background: rgba(31,34,71,.50);
  backdrop-filter: blur(4px);
  align-items: center;
  justify-content: center;
}

.confirm-overlay.open {
  display: flex;
}



/* optional separation (recommended) */
.recovery-overlay { z-index: 20000; }
.success-overlay { z-index: 20001; }
.approve-overlay {z-index: 20002;}
    .confirm-box{background:#fff;border-radius:18px;width:100%;max-width:440px;overflow:hidden;box-shadow:0 28px 70px rgba(31,34,71,.22);animation:slideUp .22s cubic-bezier(.22,1,.36,1);}
    .confirm-icon-row{display:flex;justify-content:center;padding:32px 24px 16px;}
    .confirm-icon{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;}
    .confirm-icon.warn{background:var(--red-dim);color:var(--red);}
    .confirm-icon.info{background:var(--teal-dim);color:var(--teal);}
    .confirm-icon.exit{background:var(--navy-faint);color:var(--navy);}
    .confirm-icon.success{background:var(--green-dim);color:var(--green);}
    .confirm-title{font-family:'DM Serif Display',serif;font-size:19px;font-weight:400;color:var(--navy);text-align:center;padding:0 24px 8px;line-height:1.3;}
    .confirm-desc{font-size:13px;color:var(--navy-dim);text-align:center;padding:0 28px 24px;line-height:1.6;}
    .confirm-btns{display:grid;gap:10px;padding:0 20px 22px;}
    .confirm-btns.two-col{grid-template-columns:1fr 1fr;}
    .confirm-btns.one-col{grid-template-columns:1fr;}
    .cbtn{padding:13px 20px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:600;cursor:pointer;border:none;transition:all .15s;}
    .cbtn-primary{background:var(--navy);color:#fff;} .cbtn-primary:hover{background:#14173a;}
    .cbtn-red{background:var(--red);color:#fff;} .cbtn-red:hover{background:#b91c1c;}
    .cbtn-green{background:var(--green);color:#fff;} .cbtn-green:hover{background:#047857;}
    .cbtn-ghost{background:rgba(31,34,71,.07);color:var(--navy);border:1.5px solid rgba(31,34,71,.12);} .cbtn-ghost:hover{background:rgba(31,34,71,.12);}
.ongoing-grid {
  display: grid;
  grid-template-columns: 90px 1fr 1fr 80px 120px 110px 110px 220px 140px;
align-items: center;}
  .cell.wrap {
  white-space: normal;
  overflow: visible;
  text-overflow: unset;
  word-break: break-word;
  line-height: 1.4;
   text-align: center;
  justify-content: center;}
	
	.badge-brown {
background:var(--brown-dim);color:var(--brown);}

.badge-brown .badge-dot {
  background: #6b3f2a;
}
.btn-danger-icon {
  background: var(--red-dim);
  color: var(--red);
  border: 1px solid rgba(220, 38, 38, 0.2);
  gap: 6px;
  padding: 5px 8px;
  font-size: 11.5px;
  margin-top: 4px;

  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.btn-danger-icon:hover {
  background: rgba(220, 38, 38, 0.12);
}

/* icon styling */
.btn-danger-icon .btn-icon {
  width: 11px;
  height: 11px;
  stroke: currentColor;
  fill: none;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.btn-recover-icon {
  background: var(--purple-dim);
  color: var(--purple);
  border: 1px solid rgba(124, 58, 237, 0.2);

  gap: 6px;
  padding: 5px 8px;
  font-size: 11.5px;
  margin-top: 4px;

  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.btn-recover-icon:hover {
  background: rgba(124, 58, 237, 0.12);
}

.btn-recover-icon .btn-icon {
  width: 11px;
  height: 11px;
  stroke: currentColor;
  fill: none;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.pri-high {
  color: #e53935;
  font-weight: 600;
}

.pri-medium {
  color: #fb8c00;
  font-weight: 600;
}

.pri-low {
  color: #43a047;
  font-weight: 600;
}
  .toast.error{
  background:#dc2626;
}

.toast.success{
  background:#16a34a;
}

.toast.info{
  background:#1F2247; 
  color:#ffffff;
}
.toast.warning{
  background:red; 
  color:#ffffff;
}
}

  </style>
</head>
<body>
<div class="app">

<aside class="sidebar" id="sidebar">
    <div class="sb-head">
      <div class="sb-wordmark-wrap"><div class="sb-wordmark-svg"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" zoomAndPan="magnify" viewBox="0 0 337.5 187.499995" preserveAspectRatio="xMidYMid meet" version="1.0"><defs><g></g><clipPath id="69d8563f3b"><rect x="0" width="265" y="0" height="158"></rect></clipPath><clipPath id="4a4d1c3cce"><path d="M 4.804688 4.765625 L 22.65625 4.765625 L 22.65625 22.617188 L 4.804688 22.617188 Z M 4.804688 4.765625 " clip-rule="nonzero"></path></clipPath><clipPath id="4d2650adb0"><path d="M 13.730469 4.765625 C 8.800781 4.765625 4.804688 8.761719 4.804688 13.691406 C 4.804688 18.621094 8.800781 22.617188 13.730469 22.617188 C 18.660156 22.617188 22.65625 18.621094 22.65625 13.691406 C 22.65625 8.761719 18.660156 4.765625 13.730469 4.765625 Z M 13.730469 4.765625 " clip-rule="nonzero"></path></clipPath><clipPath id="b9bbec4bb1"><path d="M 0.804688 0.765625 L 18.65625 0.765625 L 18.65625 18.617188 L 0.804688 18.617188 Z M 0.804688 0.765625 " clip-rule="nonzero"></path></clipPath><clipPath id="b545ad424a"><path d="M 9.730469 0.765625 C 4.800781 0.765625 0.804688 4.761719 0.804688 9.691406 C 0.804688 14.621094 4.800781 18.617188 9.730469 18.617188 C 14.660156 18.617188 18.65625 14.621094 18.65625 9.691406 C 18.65625 4.761719 14.660156 0.765625 9.730469 0.765625 Z M 9.730469 0.765625 " clip-rule="nonzero"></path></clipPath><clipPath id="2f86d00c01"><rect x="0" width="19" y="0" height="19"></rect></clipPath><clipPath id="de643e8a4e"><path d="M 7 6.960938 L 20.457031 6.960938 L 20.457031 20.421875 L 7 20.421875 Z M 7 6.960938 " clip-rule="nonzero"></path></clipPath><clipPath id="9040a17bd3"><path d="M 13.730469 6.960938 C 10.011719 6.960938 7 9.976562 7 13.691406 C 7 17.40625 10.011719 20.421875 13.730469 20.421875 C 17.445312 20.421875 20.457031 17.40625 20.457031 13.691406 C 20.457031 9.976562 17.445312 6.960938 13.730469 6.960938 Z M 13.730469 6.960938 " clip-rule="nonzero"></path></clipPath><clipPath id="ba2eb6533a"><path d="M 8.050781 8.011719 L 19.730469 8.011719 L 19.730469 19.691406 L 8.050781 19.691406 Z M 8.050781 8.011719 " clip-rule="nonzero"></path></clipPath><clipPath id="85b099582b"><rect x="0" width="27" y="0" height="27"></rect></clipPath><clipPath id="fea0f96916"><path d="M 21.511719 3.914062 L 40.574219 3.914062 L 40.574219 22.976562 L 21.511719 22.976562 Z M 21.511719 3.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="12d611a9d9"><path d="M 31.042969 3.914062 C 25.777344 3.914062 21.511719 8.183594 21.511719 13.445312 C 21.511719 18.710938 25.777344 22.976562 31.042969 22.976562 C 36.304688 22.976562 40.574219 18.710938 40.574219 13.445312 C 40.574219 8.183594 36.304688 3.914062 31.042969 3.914062 Z M 31.042969 3.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="285a6d3d53"><path d="M 0.511719 0.914062 L 19.574219 0.914062 L 19.574219 19.976562 L 0.511719 19.976562 Z M 0.511719 0.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="020bad4bb2"><path d="M 10.042969 0.914062 C 4.777344 0.914062 0.511719 5.183594 0.511719 10.445312 C 0.511719 15.710938 4.777344 19.976562 10.042969 19.976562 C 15.304688 19.976562 19.574219 15.710938 19.574219 10.445312 C 19.574219 5.183594 15.304688 0.914062 10.042969 0.914062 Z M 10.042969 0.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="956c204d63"><rect x="0" width="20" y="0" height="20"></rect></clipPath><clipPath id="245db32a48"><path d="M 23.855469 6.261719 L 38.226562 6.261719 L 38.226562 20.628906 L 23.855469 20.628906 Z M 23.855469 6.261719 " clip-rule="nonzero"></path></clipPath><clipPath id="bcb1073d7a"><path d="M 31.042969 6.261719 C 27.074219 6.261719 23.855469 9.476562 23.855469 13.445312 C 23.855469 17.414062 27.074219 20.628906 31.042969 20.628906 C 35.007812 20.628906 38.226562 17.414062 38.226562 13.445312 C 38.226562 9.476562 35.007812 6.261719 31.042969 6.261719 Z M 31.042969 6.261719 " clip-rule="nonzero"></path></clipPath><clipPath id="7e98c60055"><path d="M 24.976562 7.378906 L 37.449219 7.378906 L 37.449219 19.855469 L 24.976562 19.855469 Z M 24.976562 7.378906 " clip-rule="nonzero"></path></clipPath><clipPath id="ce8093f24c"><path d="M 4.617188 3.914062 L 23.683594 3.914062 L 23.683594 22.976562 L 4.617188 22.976562 Z M 4.617188 3.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="ea71ee7392"><path d="M 14.148438 3.914062 C 8.886719 3.914062 4.617188 8.183594 4.617188 13.445312 C 4.617188 18.710938 8.886719 22.976562 14.148438 22.976562 C 19.414062 22.976562 23.683594 18.710938 23.683594 13.445312 C 23.683594 8.183594 19.414062 3.914062 14.148438 3.914062 Z M 14.148438 3.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="ad3dec466e"><path d="M 0.617188 0.914062 L 19.683594 0.914062 L 19.683594 19.976562 L 0.617188 19.976562 Z M 0.617188 0.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="d0bbcc6f66"><path d="M 10.148438 0.914062 C 4.886719 0.914062 0.617188 5.183594 0.617188 10.445312 C 0.617188 15.710938 4.886719 19.976562 10.148438 19.976562 C 15.414062 19.976562 19.683594 15.710938 19.683594 10.445312 C 19.683594 5.183594 15.414062 0.914062 10.148438 0.914062 Z M 10.148438 0.914062 " clip-rule="nonzero"></path></clipPath><clipPath id="b68ff58271"><rect x="0" width="20" y="0" height="20"></rect></clipPath><clipPath id="90844f80c6"><path d="M 6.964844 6.261719 L 21.335938 6.261719 L 21.335938 20.628906 L 6.964844 20.628906 Z M 6.964844 6.261719 " clip-rule="nonzero"></path></clipPath><clipPath id="96ccdf60a7"><path d="M 14.148438 6.261719 C 10.179688 6.261719 6.964844 9.476562 6.964844 13.445312 C 6.964844 17.414062 10.179688 20.628906 14.148438 20.628906 C 18.117188 20.628906 21.335938 17.414062 21.335938 13.445312 C 21.335938 9.476562 18.117188 6.261719 14.148438 6.261719 Z M 14.148438 6.261719 " clip-rule="nonzero"></path></clipPath><clipPath id="72b62c73a7"><path d="M 8.082031 7.378906 L 20.558594 7.378906 L 20.558594 19.855469 L 8.082031 19.855469 Z M 8.082031 7.378906 " clip-rule="nonzero"></path></clipPath><clipPath id="2ed8797546"><rect x="0" width="45" y="0" height="27"></rect></clipPath></defs><g transform="matrix(1, 0, 0, 1, 36, 17)"><g clip-path="url(#69d8563f3b)"><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(1.366805, 123.791473)"><g><path d="M 65.71875 -25.9375 L 65.71875 0 L 16.75 0 L 16.75 1.890625 C 16.75 2.722656 17.019531 3.410156 17.5625 3.953125 C 18.101562 4.503906 18.796875 4.78125 19.640625 4.78125 L 42.296875 4.78125 L 42.296875 26.5625 L 23.046875 26.5625 C 18.171875 26.5625 14.160156 24.988281 11.015625 21.84375 C 7.867188 18.695312 6.296875 14.691406 6.296875 9.828125 L 6.296875 -9.1875 C 6.296875 -13.976562 7.828125 -17.945312 10.890625 -21.09375 C 13.953125 -24.238281 17.832031 -25.851562 22.53125 -25.9375 L 12.34375 -39.40625 L 12.34375 -65.71875 L 51.375 -65.71875 C 53.46875 -65.71875 55.3125 -64.941406 56.90625 -63.390625 C 58.5 -61.835938 59.296875 -59.84375 59.296875 -57.40625 L 59.296875 -39.40625 L 49.234375 -25.9375 Z M 43.8125 -33.109375 L 27.703125 -33.109375 L 32.984375 -25.9375 L 38.53125 -25.9375 Z M 43.8125 -33.109375 "></path></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(65.825457, 123.791473)"><g><path d="M -1.265625 0 L -1.265625 -25.9375 L 24.421875 -25.9375 L 24.421875 0 Z M -1.265625 0 "></path></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(88.990287, 123.791473)"><g><path d="M 33.609375 -25.9375 L 33.609375 0 L -1.265625 0 L -1.265625 -25.9375 L 10.328125 -25.9375 L 10.328125 -65.71875 L 20.78125 -65.71875 L 20.78125 -25.9375 Z M 14.984375 12.96875 L 21.78125 6.296875 L 29.96875 14.484375 L 21.78125 22.78125 L 14.984375 15.984375 L 8.3125 22.78125 L 0 14.484375 L 8.3125 6.296875 Z M 14.984375 12.96875 "></path></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(121.34551, 123.791473)"><g><path d="M -1.265625 0 L -1.265625 -25.9375 L 24.421875 -25.9375 L 24.421875 0 Z M -1.265625 0 "></path></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(144.51034, 123.791473)"><g><path d="M 23.671875 -80.328125 L 15.484375 -72.015625 L 7.171875 -80.328125 L 15.484375 -88.515625 Z M 33.609375 -25.9375 L 33.609375 0 L -1.265625 0 L -1.265625 -25.9375 L 10.328125 -25.9375 L 10.328125 -65.71875 L 20.78125 -65.71875 L 20.78125 -25.9375 Z M 33.609375 -25.9375 "></path></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(176.865563, 123.791473)"><g><path d="M -1.265625 0 L -1.265625 -25.9375 L 24.421875 -25.9375 L 24.421875 0 Z M -1.265625 0 "></path></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(200.030393, 123.791473)"><g><path d="M 40.546875 -65.71875 C 45.410156 -65.71875 49.414062 -64.144531 52.5625 -61 C 55.707031 -57.851562 57.28125 -53.847656 57.28125 -48.984375 L 57.28125 0 L -1.265625 0 L -1.265625 -25.9375 L 5.15625 -25.9375 L 5.15625 -65.71875 Z M 15.609375 -25.9375 L 46.84375 -25.9375 L 46.84375 -30.21875 C 46.84375 -31.050781 46.566406 -31.738281 46.015625 -32.28125 C 45.472656 -32.832031 44.78125 -33.109375 43.9375 -33.109375 L 15.609375 -33.109375 Z M 15.609375 -25.9375 "></path></g></g></g></g></g><path stroke-linecap="butt" transform="matrix(0.70424, -0.252106, 0.252106, 0.70424, 240.525223, 59.282541)" fill="none" stroke-linejoin="miter" d="M 0.00210982 2.001302 L 63.961941 2.000846 " stroke="#f1f0ec" stroke-width="4" stroke-opacity="1" stroke-miterlimit="4"></path><g transform="matrix(1, 0, 0, 1, 182, 47)"><g clip-path="url(#85b099582b)"><g clip-path="url(#4a4d1c3cce)"><g clip-path="url(#4d2650adb0)"><g transform="matrix(1, 0, 0, 1, 4, 4)"><g clip-path="url(#2f86d00c01)"><g clip-path="url(#b9bbec4bb1)"><g clip-path="url(#b545ad424a)"><path fill="#f1f0ec" d="M 0.804688 0.765625 L 18.65625 0.765625 L 18.65625 18.617188 L 0.804688 18.617188 Z M 0.804688 0.765625 " fill-opacity="1" fill-rule="nonzero"></path></g></g></g></g></g></g><g clip-path="url(#de643e8a4e)"><g clip-path="url(#9040a17bd3)"><path stroke-linecap="butt" transform="matrix(1.062015, 0, 0, 1.062015, 7.000809, 6.96228)" fill="none" stroke-linejoin="miter" d="M 6.336692 -0.00126388 C 2.835093 -0.00126388 -0.000761592 2.838269 -0.000761592 6.33619 C -0.000761592 9.834111 2.835093 12.673644 6.336692 12.673644 C 9.834614 12.673644 12.670468 9.834111 12.670468 6.33619 C 12.670468 2.838269 9.834614 -0.00126388 6.336692 -0.00126388 Z M 6.336692 -0.00126388 " stroke="#0097b2" stroke-width="2.817307" stroke-opacity="1" stroke-miterlimit="4"></path></g></g><g clip-path="url(#ba2eb6533a)"><path fill="#1f2247" d="M 19.398438 13.683594 C 15.144531 14.46875 14.507812 15.105469 13.722656 19.359375 C 12.941406 15.105469 12.304688 14.46875 8.050781 13.683594 C 12.304688 12.902344 12.941406 12.265625 13.722656 8.011719 C 14.507812 12.265625 15.144531 12.902344 19.398438 13.683594 Z M 19.398438 13.683594 " fill-opacity="1" fill-rule="nonzero"></path></g></g></g><g transform="matrix(1, 0, 0, 1, 117, 142)"><g clip-path="url(#2ed8797546)"><g clip-path="url(#fea0f96916)"><g clip-path="url(#12d611a9d9)"><g transform="matrix(1, 0, 0, 1, 21, 3)"><g clip-path="url(#956c204d63)"><g clip-path="url(#285a6d3d53)"><g clip-path="url(#020bad4bb2)"><path fill="#f1f0ec" d="M 0.511719 0.914062 L 19.574219 0.914062 L 19.574219 19.976562 L 0.511719 19.976562 Z M 0.511719 0.914062 " fill-opacity="1" fill-rule="nonzero"></path></g></g></g></g></g></g><g clip-path="url(#245db32a48)"><g clip-path="url(#bcb1073d7a)"><path stroke-linecap="butt" transform="matrix(1.133988, 0, 0, 1.133988, 23.856151, 6.260488)" fill="none" stroke-linejoin="miter" d="M 6.33765 0.00108563 C 2.837833 0.00108563 -0.00060156 2.836075 -0.00060156 6.335893 C -0.00060156 9.83571 2.837833 12.6707 6.33765 12.6707 C 9.834023 12.6707 12.672457 9.83571 12.672457 6.335893 C 12.672457 2.836075 9.834023 0.00108563 6.33765 0.00108563 Z M 6.33765 0.00108563 " stroke="#0097b2" stroke-width="2.638495" stroke-opacity="1" stroke-miterlimit="4"></path></g></g><g clip-path="url(#7e98c60055)"><path fill="#1f2247" d="M 37.09375 13.4375 C 32.550781 14.277344 31.871094 14.953125 31.035156 19.5 C 30.199219 14.953125 29.519531 14.277344 24.976562 13.4375 C 29.519531 12.601562 30.199219 11.925781 31.035156 7.378906 C 31.871094 11.925781 32.550781 12.601562 37.09375 13.4375 Z M 37.09375 13.4375 " fill-opacity="1" fill-rule="nonzero"></path></g><g clip-path="url(#ce8093f24c)"><g clip-path="url(#ea71ee7392)"><g transform="matrix(1, 0, 0, 1, 4, 3)"><g clip-path="url(#b68ff58271)"><g clip-path="url(#ad3dec466e)"><g clip-path="url(#d0bbcc6f66)"><path fill="#f1f0ec" d="M 0.617188 0.914062 L 19.683594 0.914062 L 19.683594 19.976562 L 0.617188 19.976562 Z M 0.617188 0.914062 " fill-opacity="1" fill-rule="nonzero"></path></g></g></g></g></g></g><g clip-path="url(#90844f80c6)"><g clip-path="url(#96ccdf60a7)"><path stroke-linecap="butt" transform="matrix(1.133988, 0, 0, 1.133988, 6.96438, 6.260488)" fill="none" stroke-linejoin="miter" d="M 6.335216 0.00108563 C 2.835398 0.00108563 0.000408516 2.836075 0.000408516 6.335893 C 0.000408516 9.83571 2.835398 12.6707 6.335216 12.6707 C 9.835033 12.6707 12.673467 9.83571 12.673467 6.335893 C 12.673467 2.836075 9.835033 0.00108563 6.335216 0.00108563 Z M 6.335216 0.00108563 " stroke="#0097b2" stroke-width="2.638495" stroke-opacity="1" stroke-miterlimit="4"></path></g></g><g clip-path="url(#72b62c73a7)"><path fill="#1f2247" d="M 20.203125 13.4375 C 15.65625 14.277344 14.980469 14.953125 14.144531 19.5 C 13.304688 14.953125 12.628906 14.277344 8.082031 13.4375 C 12.628906 12.601562 13.304688 11.925781 14.144531 7.378906 C 14.980469 11.925781 15.65625 12.601562 20.203125 13.4375 Z M 20.203125 13.4375 " fill-opacity="1" fill-rule="nonzero"></path></g></g></g></svg></div></div>
      <button class="sb-toggle" onclick="toggleSidebar()">
        <svg id="toggle-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9,18 15,12 9,6"></polyline></svg>
      </button>
    </div>

    <div class="sb-role">Accountant</div>
    <nav class="sb-nav">
      <button class="nav-item active" onclick="navigate('overview',this)">
        <span class="nav-icon"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg></span>
        <span class="nav-label">Overview</span>
      </button>
      <button class="nav-item" onclick="navigate('newly',this)">
        <span class="nav-icon"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="12" y1="11" x2="12" y2="17"/><line x1="9" y1="14" x2="15" y2="14"/></svg></span>
        <span class="nav-label">Manage Newly Requested</span>
        <span class="nav-badge" id="badge-new"></span>
      </button>
      <button class="nav-item" onclick="navigate('ongoing',this)">
        <span class="nav-icon"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg></span>
        <span class="nav-label">Manage Ongoing Requests</span>
        <span class="nav-badge" id="badge-ongoing"></span>
      </button>
      <button class="nav-item" onclick="navigate('import',this)">
        <span class="nav-icon"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span>
        <span class="nav-label">Import Transactions</span>
      </button>
    </nav>
  </aside>
  
  

  <div class="main">
    <header class="topbar">
      <h1 class="page-title" id="page-title">Overview</h1>
      <div class="topbar-right">
        <div class="icon-btn" id="notif-btn" onclick="toggleNotifPanel()" title="Notifications">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          <span class="notif-dot" id="notif-dot"></span>
        </div>
<div class="user-pill">

  <div class="avatar">
    <?= $initials ?>
  </div>

  <span class="user-name">
    <?= htmlspecialchars($name) ?>
  </span>

</div>
<button class="logout-btn" onclick="showConfirm('logout', function () {
  window.location.href='../logout.php';
})">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          Logout
        </button>
		

      </div>
    </header>
	
	
	

    <div class="content">

      <!-- OVERVIEW -->
      <div class="view active" id="view-overview">
        <div class="stats-grid" style="grid-template-columns:repeat(2,1fr);">
          <div class="stat-card" style="animation-delay:.05s">
            <div class="stat-icon" style="background:var(--amber-dim);color:var(--amber)"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/></svg></div>
            <div class="stat-label">Pending Requests</div>
            <div class="stat-value" id="stat-pending"></div>
            <div class="stat-change down">Awaiting review</div>
          </div>
          <div class="stat-card" style="animation-delay:.10s">
            <div class="stat-icon" style="background:var(--teal-dim);color:var(--teal)"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg></div>
            <div class="stat-label">Ongoing Requests</div>
            <div class="stat-value" id="stat-ongoing"></div>
            <div class="stat-change down">Currently in progress</div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-header">
            <div><div class="panel-title">Pending Requests</div><div class="panel-sub">Requires your action</div></div>
            <button class="btn btn-primary" onclick="navigate('newly',document.querySelectorAll('.nav-item')[1])">View all &rarr;</button>
          </div>
          <div class="tbl-head" style="grid-template-columns:90px 1fr 1fr 90px 110px 110px 120px">
              <span class="th">Request ID</span>
  <span class="th">Project Name</span>
  <span class="th">Requester Name</span>
  <span class="th">Emp ID</span>
  <span class="th">Amount</span>
  <span class="th">Date</span>
  <span class="th">Priority</span>
</div> <div id="pending-rows"></div>
          <div id="overview-rows"></div>
        </div>

        <div class="panel" style="animation-delay:.15s">
          <div class="panel-header">
            <div><div class="panel-title">Ongoing Requests</div><div class="panel-sub">Currently being processed</div></div>
            <button class="btn btn-primary" onclick="navigate('ongoing',document.querySelectorAll('.nav-item')[2])">View all &rarr;</button>
          </div>
          <div class="tbl-head" style="grid-template-columns:90px 1fr 1fr 90px 110px 110px 120px">
              <span class="th">Request ID</span>
  <span class="th">Project Name</span>
  <span class="th">Requester Name</span>
  <span class="th">Emp ID</span>
  <span class="th">Amount</span>
  <span class="th">Deadline</span>
  <span class="th">Status</span>
</div> 
          <div id="overview-ongoing-rows"></div>
        </div>
      </div>

      <!-- NEWLY REQUESTED -->
 <div class="view" id="view-newly">
  <div class="panel">
    <div class="panel-header">
      <div>
        <div class="panel-title">Manage Newly Requested</div>
        <div class="panel-sub" id="pendingtext-new">-</div>
      </div>
    </div>

    <!-- Filter + Search bar -->
    <div class="filter-bar">
      <button class="filter-pill active" data-priority="all">All</button>
      <button class="filter-pill" data-priority="high">High Priority</button>
      <button class="filter-pill" data-priority="medium">Medium Priority</button>
      <button class="filter-pill" data-priority="low">Low Priority</button>

      <div class="search-box">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <input placeholder="Search requests using ID or project..." oninput="newlySearch(this.value)"/>
      </div>
    </div>

    <!-- A STYLE APPLIED HERE -->
    <div class="tbl-head ongoing-grid"
         style="grid-template-columns:90px 1fr 1fr 80px 110px 110px 90px 110px 120px">
      <span class="th">Request ID</span>
      <span class="th">Project Name</span>
      <span class="th">Requester Name</span>
      <span class="th">Emp ID</span>
      <span class="th">Requested Amount</span>
      <span class="th">Request Date</span>
      <span class="th">Priority</span>
      <span class="th">Status</span>
      <span class="th">Action</span>
    </div>

    <!-- IMPORTANT FIX: rows must also follow A grid -->
    <div id="newly-rows">
      <div class="tbl-row"
           style="grid-template-columns:90px 1fr 1fr 80px 110px 110px 90px 110px 120px;align-items:center;">
        <!-- row content unchanged -->
      </div>
    </div>

  </div>
</div>

      <!-- ONGOING -->
      <div class="view" id="view-ongoing">
        <div class="panel">
          <div class="panel-header">
            <div><div class="panel-title">Ongoing Requests</div><div class="panel-sub">Requests currently being processed</div></div>
          </div>
          <div class="filter-bar" id="ongoing-filter-bar">

  <button class="filter-pill active" data-status="all">All</button>

  <button class="filter-pill" data-status="approved">Approved</button>

  <button class="filter-pill" data-status="active">Spending / Invoice Pending</button>

  <button class="filter-pill" data-status="flagged">Flagged</button>

  <button class="filter-pill" data-status="closed">Closed</button>

  <button class="filter-pill" data-status="ready_to_close">Ready to Close</button>

            <div class="search-box">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input placeholder="Search by ID or project..." oninput="searchOngoing(this.value)"/>
            </div>
          </div>
          <div class="tbl-head" style="grid-template-columns:90px 1fr 1fr 80px 120px 110px 110px 220px 140px">
            <span class="th">Request ID</span><span class="th">Project Name</span><span class="th">Requester Name</span>
            <span class="th">Emp ID</span><span class="th">Requested Amt</span><span class="th">Remaining Amt</span><span class="th">Deadline</span><span class="th">Status</span><span class="th">Action</span>
          </div>
          <div id="ongoing-rows"></div>
        </div>
      </div>

      <!-- IMPORT -->
      <div class="view" id="view-import">
        <div class="panel">
          <div class="panel-header">
            <div><div class="panel-title">Import Transactions</div><div class="panel-sub">Upload your transaction file</div></div>
          </div>
          <div style="padding:28px 28px 32px">
            <div class="drop-zone" id="drop-zone" onclick="document.getElementById('csv-file').click()"
              ondragover="event.preventDefault();this.classList.add('drag')"
              ondragleave="this.classList.remove('drag')"
              ondrop="handleDrop(event)">
              <div style="color:rgba(31,34,71,.28);display:flex;justify-content:center;margin-bottom:14px">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              </div>
              <div style="font-size:15px;font-weight:600;color:var(--navy);margin-bottom:6px" id="drop-title">Drop your file here or click to browse</div>
              <div style="font-size:12px;color:rgba(31,34,71,.38);margin-top:8px;">Supports: CSV, XLS, XLSX &mdash; Max file size: 10MB</div>
              <input id="csv-file" type="file" accept=".csv,.xls,.xlsx" style="display:none" onchange="handleFile(this.files[0])"/>
            </div>
            <div id="drop-actions" style="display:none;gap:12px;margin-top:20px;display:none">
              <button class="btn btn-primary" style="padding:11px 24px;font-size:14px;border-radius:10px" onclick="importFile()">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Import Now
              </button>
            </div>
            <div style="margin-top:28px;padding:20px;background:rgba(0,151,178,.05);border:1px solid rgba(0,151,178,.14);border-radius:12px">
              <div style="font-size:13px;font-weight:700;color:var(--teal);margin-bottom:12px;display:flex;align-items:center;gap:7px">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                File Format Requirements
              </div>
              <div style="display:flex;flex-direction:column;gap:9px">
                <div style="font-size:12.5px;color:var(--navy-dim);display:flex;align-items:flex-start;gap:8px"><span style="width:5px;height:5px;border-radius:50%;background:var(--teal);display:inline-block;flex-shrink:0;margin-top:5px"></span><span><strong style="color:var(--navy)">Required columns:</strong> transaction_date, amount, card_suffix, transaction_type, description</span></div>
                <div style="font-size:12.5px;color:var(--navy-dim);display:flex;align-items:flex-start;gap:8px"><span style="width:5px;height:5px;border-radius:50%;background:var(--teal);display:inline-block;flex-shrink:0;margin-top:5px"></span><span><strong style="color:var(--navy)">Date format:</strong> YYYY-MM-DD or DD/MM/YYYY</span></div>
                <div style="font-size:12.5px;color:var(--navy-dim);display:flex;align-items:flex-start;gap:8px"><span style="width:5px;height:5px;border-radius:50%;background:var(--teal);display:inline-block;flex-shrink:0;margin-top:5px"></span><span><strong style="color:var(--navy)">Amount:</strong> Numeric values only &mdash; no currency symbols</span></div>
                <div style="font-size:12.5px;color:var(--navy-dim);display:flex;align-items:flex-start;gap:8px"><span style="width:5px;height:5px;border-radius:50%;background:var(--teal);display:inline-block;flex-shrink:0;margin-top:5px"></span><span><strong style="color:var(--navy)">Headers:</strong> First row must contain column headers</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="icon-btn"
     id="notif-btn"
     onclick="toggleNotifPanel()"
     title="Notifications">

  <svg width="16"
       height="16"
       viewBox="0 0 24 24"
       fill="none"
       stroke="currentColor"
       stroke-width="1.8"
       stroke-linecap="round"
       stroke-linejoin="round">

    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>

    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
  </svg>

  <span class="notif-dot" id="notif-dot"></span>

  <!-- NOTIFICATION PANEL -->
  <div class="notif-panel"
       id="notif-panel"
       style="top: 59.6px; right: 28px; left: auto;">

    <div class="notif-panel-header">

      <span class="notif-panel-title">
        Notifications
      </span>

      <div class="notif-actions">

        <span class="notif-count"
              id="notif-count">
          3
        </span>

        <button class="notif-mark-all"
                onclick="markAllRead()">
          Mark all read
        </button>

      </div>
    </div>

    <div class="notif-list"
         id="notif-list">
    </div>

    <div class="notif-footer">

      <button class="notif-footer-btn"
              onclick="clearAllNotifs()">

        <svg width="12"
             height="12"
             viewBox="0 0 24 24"
             fill="none"
             stroke="currentColor"
             stroke-width="2.2"
             stroke-linecap="round"
             stroke-linejoin="round">

          <polyline points="3,6 5,6 21,6"></polyline>

          <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path>

          <path d="M10 11v6M14 11v6"></path>
        </svg>

        Clear all
      </button>

    </div>
  </div>
</div>

<div class="toast" id="toast"></div>
<!-- REVIEW MODAL <div class="icon-btn" id="notif-btn" onclick="toggleNotifPanel()" title="Notifications"> 
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
</svg> <span class="notif-dot" id="notif-dot"></span> 
</div> -->

<div class="modal-overlay" id="review-modal">
  <div class="modal">

    <div class="modal-hdr">
      <div>
        <div class="modal-title">Review Request</div>
        <div class="modal-sub" id="m-id">REQ-001</div>
      </div>

      <button class="modal-close" onclick="closeModal()">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <div class="modal-body">

      <div class="modal-row">
        <span class="modal-row-label">Project Name</span>
        <span class="modal-row-value" id="m-project">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Requester Name</span>
        <span class="modal-row-value" id="m-requester">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Employee ID</span>
        <span class="modal-row-value teal" id="m-empid">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Requested Amount</span>
        <span class="modal-row-value" id="m-amount">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Request Date</span>
        <span class="modal-row-value" id="m-date">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Deadline</span>
        <span class="modal-row-value" id="m-deadline">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Priority</span>
        <span class="modal-row-value" id="m-priority">-</span>

      </div>

 

      <div class="modal-row">
        <span class="modal-row-label">Description</span>
        <span class="modal-row-value" id="m-description"
              style="max-width:220px;white-space:normal;text-align:right;line-height:1.5;">
          -
        </span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Status</span>
        <span class="modal-row-value" id="m-status">
          <span class="badge badge-amber">
            <span class="badge-dot"></span>
            Pending
          </span>
        </span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Purpose</span>
        <span class="modal-row-value" id="m-purpose"
              style="max-width:220px;white-space:normal;text-align:right;line-height:1.5;">
          -
        </span>
      </div>

    </div>

    <div class="modal-footer" style="grid-template-columns:1fr 1fr;">

      <button class="modal-btn-approve" id="approve-btn">
        Approve
      </button>

      <button class="modal-btn-reject" id="reject-btn">
        Decline
      </button>

    </div>

  </div>
</div>

<div class="confirm-overlay approve-overlay" id="reqapprove-overlay">
  <div class="confirm-box">
    <div class="confirm-icon-row">
      <div class="confirm-icon info" id="confirm-icon">
        <svg id="confirm-icon-svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
      </div>
    </div>
    <div class="confirm-title" id="confirm-title">Approve this request?</div>
    <div class="confirm-desc" id="confirm-desc">The request will be approved and the requester will be notified.</div>
    <div class="confirm-btns two-col" id="confirm-btns">
      <button class="cbtn cbtn-green" id="confirm-ok" onclick="confirmOk()">Yes, Approve</button>
      <button class="cbtn cbtn-ghost" id="confirm-cancel" onclick="confirmCancel()" style="">Cancel</button>
    </div>
  </div>
</div>
<!-- ONGOING VIEW MODAL -->
<div class="modal-overlay" id="ongoing-modal" onclick="closeModal(event)">
  <div class="modal">

    <div class="modal-hdr">
      <div>
        <div class="modal-title">Request Details</div>
        <div class="modal-sub" id="m-ido">REQ-001</div>
      </div>

      <button class="modal-close" onclick="closeOngoingModal()">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor"
             stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <div class="modal-body">

      <div class="modal-row">
        <span class="modal-row-label">Project Name</span>
        <span class="modal-row-value" id="m-projecto">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Requester Name</span>
        <span class="modal-row-value" id="m-requestero">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Employee ID</span>
        <span class="modal-row-value teal" id="m-empido">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Requested Amount</span>
        <span class="modal-row-value" id="m-amounto">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Remaining Amount</span>
        <span class="modal-row-value teal" id="m-remaining_amounto">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Deadline</span>
        <span class="modal-row-value" id="m-deadlineo">-</span>
      </div>

      <div class="modal-row">
        <span class="modal-row-label">Status</span>
        <span class="modal-row-value" id="m-statuso">-</span>
      </div>

    </div>

    <div class="modal-footer" style="grid-template-columns:1fr;">

      <button class="modal-btn-cancel"
              style="background:var(--navy);color:#fff;padding:13px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:14px;font-weight:600;cursor:pointer;border:none;"
              onclick="closeOngoingModal()">
        Close
      </button>

    </div>

  </div>
</div>

<!-- confirm MODAL -->
<div class="confirm-overlay recovery-overlay" id="recovery-modal">

  <div class="confirm-box">

    <div class="confirm-icon-row">

      <div class="confirm-icon info" id="confirm-icon">

        <svg id="confirm-icon-svg"
             width="26"
             height="26"
             viewBox="0 0 24 24"
             fill="none"
             stroke="currentColor"
             stroke-width="2"
             stroke-linecap="round"
             stroke-linejoin="round">

          <polyline points="1,4 1,10 7,10"></polyline>
          <path d="M3.51 15a9 9 0 1 0 .49-4.95"></path>

        </svg>

      </div>

    </div>

    <div class="confirm-title" id="confirm-title">
      Recover remaining amount?
    </div>

    <div class="confirm-desc" id="confirm-desc">
      The remaining balance will be recovered and returned to the company account.
    </div>

    <div class="confirm-btns two-col" id="confirm-btns">

      <button type="button"
              class="cbtn cbtn-green"
              id="confirm-recover-btn">
        Yes, Recover
      </button>

      <button class="cbtn cbtn-ghost"
              onclick="closeRecoveryModal()">
        Cancel
      </button>

    </div>

  </div>

</div>



<!-- Successful Approval Modal--->
<div class="confirm-overlay" id="approvalSuccess">
  <div class="confirm-box">

    <div class="confirm-icon-row">
      <div class="confirm-icon success" id="confirm-icon">
        <svg id="confirm-icon-svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 11l3 3L22 4"></path>
          <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
        </svg>
      </div>
    </div>

    <div class="confirm-title" id="confirm-title">
      Request Approved
    </div>

    <div class="confirm-desc" id="confirm-desc">
      The request has been approved successfully.
    </div>

    <div class="confirm-btns one-col" id="confirm-btns">
      <button class="cbtn cbtn-primary" id="approved-req" onclick="closeApprovalSuccess()">
        Done
      </button>
    </div>

  </div>
</div>

<div class="confirm-overlay" id="declineSuccess">
  <div class="confirm-box">

    <div class="confirm-icon-row">
      <div class="confirm-icon success" id="confirm-icon">
        <svg id="confirm-icon-svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 11l3 3L22 4"></path>
          <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
        </svg>
      </div>
    </div>

    <div class="confirm-title">
      Request Declined
    </div>

    <div class="confirm-desc">
      The request has been declined successfully.
    </div>

    <div class="confirm-btns one-col">
      <button class="cbtn cbtn-primary" onclick="closeDeclineSuccess()">
        Done
      </button>
    </div>

  </div>
</div>


<div class="confirm-overlay" id="cancelSuccess-overlay">

  <div class="confirm-box">

    <div class="confirm-icon-row">

      <div class="confirm-icon success" id="confirm-icon">

        <svg id="confirm-icon-svg"
             width="26"
             height="26"
             viewBox="0 0 24 24"
             fill="none"
             stroke="currentColor"
             stroke-width="2"
             stroke-linecap="round"
             stroke-linejoin="round">

          <path d="M9 11l3 3L22 4"></path>

          <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>

        </svg>

      </div>

    </div>

    <div class="confirm-title" id="confirm-title">
      Request Cancelled
    </div>

    <div class="confirm-desc" id="confirm-desc">
      Request REQ-<span id="cancel-id"></span> has been cancelled and marked as closed.
    </div>

    <div class="confirm-btns one-col" id="confirm-btns">

      <button class="cbtn cbtn-primary"
              onclick="closeCancel()">
        Done
      </button>

    </div>

  </div>

</div>





<script>
function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const icon = document.getElementById('toggle-icon');

  sidebar.classList.toggle('collapsed');

  // Change arrow direction
  if (sidebar.classList.contains('collapsed')) {
    icon.innerHTML = `
      <polyline points="9,18 15,12 9,6"></polyline>
    `;
  } else {
    icon.innerHTML = `
      <polyline points="15,18 9,12 15,6"></polyline>
    `;
  }
}
</script>

<script>



const AccountantDashboard = (() => {


  // ===============================
  // STATE (NEWLY / PENDING)
  // ===============================
  let newlyCache = [];
  let newlyPriFilter = 'all';
  let newlySearch = '';

  // ===============================
  // STATE (ONGOING)
  // ===============================
  let ongoingCache = [];
  let ongoingFilter = 'all';
  let ongoingSearch = '';
  window.recoveryRequestId = null;
  window.currentApproveId = null;
  window.cancelRequestId = null;

  // ===============================
  // DOM
  // ===============================
  const DOM = {
    newlyRows: document.getElementById("newly-rows"),

    modal: document.getElementById("review-modal"),
	ongoingmodal: document.getElementById("ongoing-modal"),
	recoverymodal: document.getElementById("recovery-modal"),

    mId: document.getElementById("m-id"),
    mProject: document.getElementById("m-project"),
    mRequester: document.getElementById("m-requester"),
    mEmpId: document.getElementById("m-empid"),
    mAmount: document.getElementById("m-amount"),
    mDate: document.getElementById("m-date"),
    mDeadline: document.getElementById("m-deadline"),
    mPriority: document.getElementById("m-priority"),
  
    mDescription: document.getElementById("m-description"),
    mPurpose: document.getElementById("m-purpose"),

    closeBtn: document.getElementById("closeModalBtn")
  };

  // ===============================
  // INIT
  // ===============================
  
  function setActiveFilter(barSelector, attr, value) {

  const bar = document.querySelector(barSelector);
  if (!bar) return;

  // remove active from only this group
  bar.querySelectorAll(".filter-pill")
    .forEach(btn => btn.classList.remove("active"));

  // activate selected button
  const activeBtn = bar.querySelector(`[${attr}="${value}"]`);
  if (activeBtn) activeBtn.classList.add("active");
}
  function init() {
    bindEvents();
	
renderNewly();
  renderOngoing();

  // =========================
  // DEFAULT STATES
  // =========================

  newlyPriFilter = 'all';
  ongoingFilter = 'all';

  applyNewlyFilter();
  applyOngoingFilter();

  setActiveFilter("#view-newly", "data-priority", "all");
  setActiveFilter("#ongoing-filter-bar", "data-status", "all");
	

  }

  // ===============================
  // EVENTS
  // ===============================
  function bindEvents() {

    // NEWLY FILTER BUTTONS
document.querySelectorAll("#view-newly .filter-pill").forEach(btn => {
  btn.addEventListener("click", () => {

    AccountantDashboard.filter(btn.dataset.priority);

    setActiveFilter("#view-newly", "data-priority", btn.dataset.priority);
  });
});
 

    // MODAL CLOSE
    DOM.closeBtn?.addEventListener("click", closeModal);

 // ===============================
// MODAL ROUTER
// ===============================
const modalMap = {
  newly: openModal,
  ongoing: openOngoingModal,
  recovery: openRecoveryModal,
  cancel: openCancelConfirmModal,
  
};

function mapStatus(status) {
  const s = (status || '').trim().toLowerCase();

  switch (s) {
    case 'spending / invoice pending':
      return 'active';
    case 'approved':
      return 'approved';
    case 'flagged':
      return 'flagged';
    case 'ready to close':
      return 'ready_to_close';
    default:
      return s;
  }
}

document.addEventListener("click", (e) => {

  const btn = e.target.closest("[data-action]");
if (!btn) return;

  const action = btn.dataset.action;
  const id = btn.dataset.id;

  console.log(action, id);

  const handler = modalMap[action];

  if (handler) {
    handler(id);
  }
});
    // ONGOING FILTER BUTTONS 
    document.querySelectorAll("#ongoing-filter-bar .filter-pill").forEach(btn => {
  btn.addEventListener("click", () => {

    AccountantDashboard.filterOngoing(btn.dataset.status || 'all');

    setActiveFilter("#ongoing-filter-bar", "data-status", btn.dataset.status || 'all');
  });
});

document.getElementById("confirm-recover-btn")
  ?.addEventListener("click", () => {

    const id = window.recoveryRequestId;

    if (!id) {
      console.error("Missing recoveryRequestId");
      alert("Invalid request. Please reopen modal.");
      return;
    }

    recoverOngoing(id);
  });
  
  // open decline modal
document.getElementById("reject-btn")
  .addEventListener("click", () => {

    document.getElementById("decline-overlay")
      .classList.add("open");

    document.getElementById("decline-req-id")
      .textContent = `REQ-${window.currentApproveId}`;
});
  
  }

  // ===============================
  // FETCH NEWLY (PENDING)
  // ===============================
  async function renderNewly() {
    try {
      const res = await fetch("fetch.php?action=fetch_pending");
      const data = await res.json();

      newlyCache = Array.isArray(data) ? data : [];

      applyNewlyFilter();
	   updateStats();

    } catch (err) {
      console.error("Fetch error:", err);
      DOM.newlyRows.innerHTML = "<div class='empty'>Error loading data</div>";
    }
  }

  // ===============================
  // NEWLY FILTER ENGINE
  // ===============================
  function applyNewlyFilter() {

    let data = [...newlyCache];

    data = data.filter(r =>
      (r.status || '').toLowerCase().trim() === 'pending'
    );

    if (newlyPriFilter !== 'all') {
      data = data.filter(r =>
        (r.priority || '').toLowerCase().trim() === newlyPriFilter
      );
    }

    if (newlySearch) {
      const s = newlySearch.toLowerCase();

      data = data.filter(r =>
        (r.request_title || '').toLowerCase().includes(s) ||
        String(r.fund_request_id || '').includes(s)
      );
    }

    renderNewlyTable(data);
  }

  // ===============================
  // NEWLY TABLE RENDER
  // ===============================
  function renderNewlyTable(data) {

    if (!data.length) {
      DOM.newlyRows.innerHTML = "<div class='empty'>No requests found.</div>";
      return;
    }

    DOM.newlyRows.innerHTML = data.map(r => `

<div class="tbl-row" style="grid-template-columns:90px 1fr 1fr 80px 110px 110px 90px 110px 120px;align-items:center;">

  <span class="cell mono">REQ-${r.fund_request_id}</span>

  <span class="cell">${r.request_title ?? '-'}</span>

  <span class="cell">${r.full_name ?? '-'}</span>

  <span class="cell muted">EMP-${r.employee_id ?? '-'}</span>

  <span class="cell bold">
    SAR ${Number(r.amount_requested || 0).toLocaleString()}
  </span>

   <span class="cell muted">${r.request_date ?? '-'}</span>

  <span class="cell">
    <span class="pri-${(r.priority || '').toLowerCase()}"
          style="display:inline-block;white-space:nowrap;">
      ${r.priority ?? '-'}
    </span>
  </span>

  <span class="cell">${renderStatusBadge(r.status)}</span>

  <span class="cell">
    <button class="btn btn-review"
            data-action="newly"
            data-id="${r.fund_request_id}">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
        <circle cx="12" cy="12" r="3"></circle>
      </svg>
      Review
    </button>
  </span>

</div>
    `).join("");
	
	const pendingRows = document.getElementById("pending-rows");

pendingRows.innerHTML = data.map(r => `
  <div class="tbl-row"
       style="grid-template-columns:90px 1fr 1fr 90px 110px 110px 120px">

    <span class="cell mono">REQ-${r.fund_request_id}</span>
    <span class="cell">${r.request_title}</span>
    <span class="cell muted">${r.full_name}</span>
    <span class="cell muted">EMP-${r.employee_id}</span>
    <span class="cell bold">SAR ${Number(r.amount_requested).toLocaleString()}</span>
    <span class="cell muted">${r.request_date}</span>
      <span class="cell">
    <span class="pri-${(r.priority || '').toLowerCase()}"
          style="display:inline-block;white-space:nowrap;">
      ${r.priority ?? '-'}
    </span>
  </span>

  </div>
`).join("");
  }
// =========================== Overview======//


  // ===============================
  // FETCH ONGOING
  // ===============================
  async function renderOngoing() {
    try {
      const res = await fetch("fetch.php?action=fetch_ongoing");
      const data = await res.json();

      ongoingCache = Array.isArray(data) ? data : [];

    const ongoingCount = ongoingCache.filter(r =>
      ['APPROVED', 'FLAGGED', 'READY_TO_CLOSE', 'ACTIVE']
        .includes((r.status || '').trim().toUpperCase())
    ).length;

    document.getElementById("stat-ongoing").textContent =
      ongoingCount;
      applyOngoingFilter();
	  updateStats();
	  

    } catch (err) {
      console.error("Ongoing fetch error:", err);
    }
  }

  // ===============================
  // ONGOING FILTER ENGINE
  // ===============================
function applyOngoingFilter() {

  let data = [...ongoingCache];


  // ===============================
  // STATUS FILTER (FIXED)
  // ===============================
  if (ongoingFilter !== 'all') {

    data = data.filter(r => {

      const dbStatus = (r.status || '').toLowerCase().trim();
      const filterStatus = (ongoingFilter || '').toLowerCase().trim();

      return dbStatus === filterStatus;
    });
  }

  // ===============================
  // SEARCH FILTER (UNCHANGED LOGIC STYLE)
  // ===============================
  if (ongoingSearch) {

    const s = ongoingSearch.toLowerCase();

    data = data.filter(r =>
      (r.request_title || '').toLowerCase().includes(s) ||
  
      String(r.fund_request_id || '').includes(s)
    );
  }

  renderOngoingTable(data);
}

  // ===============================
  // ONGOING TABLE RENDER
  // ===============================
  function renderOngoingTable(data) {

    const tbody = document.getElementById("ongoing-rows");
    if (!tbody) return;

    if (!data.length) {
      tbody.innerHTML = "<div class='empty'>No ongoing requests found.</div>";
      return;
    }

    tbody.innerHTML = data.map(r => `
<div class="tbl-row" style="grid-template-columns:90px 1fr 1fr 80px 120px 110px 110px 220px 140px;align-items:center;">

  <span class="cell mono ">REQ-${r.fund_request_id}</span>
  <span class="cell">${r.request_title ?? '-'}</span>
  <span class="cell">${r.full_name ?? '-'}</span>
  <span class="cell  muted">EMP-${r.employee_id ?? '-'}</span>

  <span class="cell bold ">
    SAR ${Number(r.amount_requested || 0).toLocaleString()}
  </span>

  <span class="cell bold " style="color:var(--teal)">
    SAR ${Number(r.remaining_amount || 0).toLocaleString()}
  </span>

  <span class="cell muted">${r.project_due_date ?? '-'}</span>

  <!-- STATUS (A STYLE FIX) -->
  <span class="cell" style="overflow:visible;">
    ${renderStatusBadge(r.status)}
  </span>

  <!-- ACTIONS (A STYLE FIX: vertical buttons like A) -->
  <span class="cell">
    <div style="display:flex;flex-direction:column;align-items:flex-start;gap:4px;">

      <button class="btn btn-review"
              data-action="ongoing"
              data-id="${r.fund_request_id}">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
          <circle cx="12" cy="12" r="3"></circle>
        </svg>
        View
      </button>

${(r.status === 'FLAGGED' || r.status === 'READY_TO_CLOSE') ? `
<button
  class="btn btn-recover-icon"
  style="
    background:var(--purple-dim);
    color:var(--purple);
    border:1.5px solid rgba(124,58,237,.2);
    gap:4px;
    padding:5px 8px;
    font-size:11.5px;
    margin-top:4px;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius:8px;
    cursor:pointer;
    transition:all .2s ease;
  "
  data-action="recovery"
  data-id="${r.fund_request_id}"
  data-amount="${r.remaining_amount}"
>
  <svg width="11"
       height="11"
       viewBox="0 0 24 24"
       fill="none"
       stroke="currentColor"
       stroke-width="2"
       stroke-linecap="round"
       stroke-linejoin="round">
    <polyline points="1,4 1,10 7,10"></polyline>
    <path d="M3.51 15a9 9 0 1 0 .49-4.95"></path>
  </svg>

  Recover
</button>
` : ''}

    </div>
  </span>

</div>
    `).join("");
const ongoingOverviewRows = document.getElementById("overview-ongoing-rows");

const allowedStatuses = [
  "active",
  "approved",
  "flagged",
  "ready_to_close"
];

const filteredData = data.filter(r => {

  const status = (r.status || "")
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "_");

  return allowedStatuses.includes(status);
});

ongoingOverviewRows.innerHTML = filteredData.map(r => `
  <div class="tbl-row"
       style="grid-template-columns:90px 1fr 1fr 90px 110px 110px 120px">

    <span class="cell mono">REQ-${r.fund_request_id}</span>
    <span class="cell">${r.request_title}</span>
    <span class="cell muted">${r.full_name}</span>
    <span class="cell muted">EMP-${r.employee_id}</span>
    <span class="cell bold">SAR ${Number(r.amount_requested).toLocaleString()}</span>
    <span class="cell muted">${r.project_due_date}</span>
    <span class="cell">${renderStatusBadge(r.status)}</span>

  </div>
`).join("");
  }
  
function updateStats() {

  // ===============================
  // PENDING COUNT
  // ===============================
  const pendingCount = newlyCache.filter(r => {

    const status = (r.status || "")
      .toLowerCase()
      .trim();

    return status === "pending";

  }).length;

  // ===============================
  // ONGOING COUNT
  // ===============================
  const ongoingCount = ongoingCache.filter(r => {

    const status = (r.status || "")
      .toLowerCase()
      .trim()
      .replace(/\s+/g, "_");

    return status === "approved" ||
           status === "flagged" ||
           status === "ready_to_close" ||
           status === "active";

  }).length;

  // ===============================
  // STAT CARDS
  // ===============================
  const statPending =
    document.getElementById("stat-pending");

  if (statPending) {
    statPending.textContent = pendingCount;
  }

  const statOngoing =
    document.getElementById("stat-ongoing");

  if (statOngoing) {
    statOngoing.textContent = ongoingCount;
  }

  // ===============================
  // SIDEBAR BADGES
  // ===============================
  const badgeNew =
    document.getElementById("badge-new");

  if (badgeNew) {
    badgeNew.textContent = pendingCount;
  }

  const badgeOngoing =
    document.getElementById("badge-ongoing");

  if (badgeOngoing) {
    badgeOngoing.textContent = ongoingCount;
  }
  
  
    const pendingTextNew =
    document.getElementById("pendingtext-new");

  if (pendingTextNew) {
    pendingTextNew.textContent = pendingCount + " requests pending approval";
  }
}









function autoCloseRequests() {
  fetch("fetch.php?action=auto_close_requests", {
    method: "POST",
    credentials: "include"
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {

      console.log("Auto-close completed");

      // refresh UI automatically
      loadNotifications?.();
      loadOngoingRequests?.();
      loadPendingRequests?.();

    } else {
      console.error("Auto-close failed");
    }
  })
  .catch(err => {
    console.error("Error:", err);
  });
}


async function recoverOngoing(id) {
  if (!id) {
    console.error("Invalid id:", id);
    alert("Invalid request ID");
    return;
  }

  try {

   const res = await fetch("fetch.php?action=recover_ongoing", {
  method: "POST",
  credentials: "include", 
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    fund_request_id: Number(id)
  })
});

    const data = await res.json();

    if (!data.success) {
      alert(data.message || "Recovery failed.");
      return;
    }

    // refresh UI AFTER success
    await renderOngoing();

    // use backend value OR fallback from cache
const recovered = data.recovered_amount ?? 0;

requestAnimationFrame(() => {

  openRecoverySuccessModal(
    'Amount Recovered | SAR ' +
    Number(recovered).toLocaleString() +
    ' has been recovered for REQ-' + id
  );

  });}
  catch (err) {
    console.error(err);
    alert("Recovery error");
  }
}





window.newlySearch = function(value) {
  newlySearch = value;
  applyNewlyFilter();
};

window.searchOngoing = function(value) {
  ongoingSearch = value;
  applyOngoingFilter();
};

 // ===============================
  // PUBLIC API
  // ===============================
 window.recoverOngoing = recoverOngoing;
  return {
	  
    init,
	renderNewly,
renderOngoing,

    filter(priority) {
      newlyPriFilter = priority;
      applyNewlyFilter();
    },

    search(value) {
      newlySearch = value;
      applyNewlyFilter();
    },

    filterOngoing(status, btn) {
      ongoingFilter = (status || 'all').toLowerCase();
      applyOngoingFilter();

      if (btn) {
        document.querySelectorAll('#view-ongoing .filter-pill')
          .forEach(p => p.classList.remove('active'));

        btn.classList.add('active');
      }
    },

    searchOngoing(value) {
      ongoingSearch = value;
      applyOngoingFilter();
    },

    closeModal
  };

})();

// ===============================
// BOOT
// ===============================
document.addEventListener("DOMContentLoaded", () => {
  AccountantDashboard.init();
  // Auto-navigate after CSV import
  const _p = new URLSearchParams(window.location.search);
  if (_p.get('view') === 'ongoing') {
    setTimeout(() => {
      const btn = document.querySelector('[data-section="ongoing"]') || document.getElementById('nav-ongoing');
      if (btn) btn.click();
    }, 400);
    history.replaceState({}, '', window.location.pathname);
  }
});




function setOngoingActiveButton(status) {
  document.querySelectorAll("#ongoing-filter-bar .filter-pill")
    .forEach(p => p.classList.remove("active"));

  const btn = document.querySelector(`#ongoing-filter-bar [data-status="${status}"]`);
  if (btn) btn.classList.add("active");
}



function renderStatusBadge(status) {
  const s = (status || '').toLowerCase().trim();

  const map = {
    pending: {
      class: 'badge-amber',
      label: 'Pending'
    },
    closed: {
      class: 'badge-navy',
      label: 'Closed'
    },
    active: {
      class: 'badge-teal',
      label: 'Spending / Invoice Pending'
    },
    flagged: {
      class: 'badge-red',
      label: 'Flagged'
    },
    ready_to_close: {
      class: 'badge-purple',
      label: 'Ready to Close'
    },
    approved: {
      class: 'badge-green',
      label: 'Approved'
    },
    rejected: {
      class: 'badge-brown',
      label: 'Rejected'
    }
  };

  const item = map[s] || {
    class: 'badge-gray',
    label: status || '-'
  };

  return `
    <span class="badge ${item.class}"
          style="white-space:nowrap;display:inline-flex;align-items:center;gap:5px;max-width:100%;">
      <span class="badge-dot"></span>
      ${item.label}
    </span>
  `;
}





window.confirmCancelRequest = async function () {

  const id = window.cancelRequestId;

  if (!id) {
    alert("Invalid cancel request");
    return;
  }

  try {

    const res = await fetch(
      "fetch.php?action=cancel_approved",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          fund_request_id: id
        })
      }
    );

    const data = await res.json();

    console.log(data);

    if (!data.success) {

      alert(data.message || "Cancel failed");

      return;
    }

    // 1. clear state
    window.cancelRequestId = null;

    // 2. CLOSE confirm modal FIRST
    document.getElementById("confirmCancel-overlay")
      ?.classList.remove("open");

    // 3. refresh table
    await AccountantDashboard.renderOngoing();

    // 4. OPEN success modal
    openCancelSuccessModal(id);

  } catch (err) {

    console.error(err);

    alert("Cancel error");
  }
};


async function approveRequest(id) {

  try {

    const formData = new FormData();

    formData.append("id", id);
    formData.append("status", "APPROVED");

    const res = await fetch(
      "fetch.php?action=update_status",
      {
        method: "POST",
        body: formData
      }
    );

    const data = await res.json();

    console.log(data);

    if (!data.success) {
      alert(data.error || "Approval failed.");
      return;
    }

    // close request modal
    closeModal();

    // close confirmation modal
    document.getElementById("reqapprove-overlay")
      ?.classList.remove("open");

    // refresh tables
    await AccountantDashboard.renderNewly();
    await AccountantDashboard.renderOngoing();

    // OPEN SUCCESS MODAL
    document.getElementById("approvalSuccess")
      ?.classList.add("open");

  } catch (err) {

    console.error(err);
    alert("Approval error");
  }
}

window.confirmOk = async function () {

  const id = window.currentApproveId;

  if (!id) {
    alert("Invalid request");
    return;
  }

  await approveRequest(id);
};

// success modal Done button
window.closeApprovalSuccess = function () {
  document.getElementById("approvalSuccess")
    .classList.remove("open");
};

window.confirmCancel = function() {

  document.getElementById("reqapprove-overlay")
    .classList.remove("open");
};





// Fetch single request and show modal

window.openModal = function(id) {

  fetch(`fetch.php?action=get_request&id=${id}`)
    .then(res => res.json())
    .then(r => {

      if (!r || r.error) {
        return alert("Failed to load request");
      }

      window.currentRequestId = r.fund_request_id;
	  window.currentApproveId = r.fund_request_id;

      document.getElementById("approve-btn").onclick = () => {

  // store current request id
  window.currentApproveId = r.fund_request_id;

  // open confirmation modal
  document.getElementById("reqapprove-overlay")
    .classList.add("open");
};

      document.getElementById("m-id").textContent =
        "REQ-" + r.fund_request_id;

      document.getElementById("m-project").textContent =
        r.request_title ?? "-";

      document.getElementById("m-requester").textContent =
        r.full_name ?? "-";

      document.getElementById("m-empid").textContent =
        "EMP-" + r.employee_id ?? "-";

      document.getElementById("m-amount").textContent =
        "SAR " + Number(r.amount_requested || 0).toLocaleString();

      document.getElementById("m-date").textContent =
        r.request_date ?? "-";

      document.getElementById("m-deadline").textContent =
        r.project_due_date ?? "-";

     const el = document.getElementById("m-priority");

const priority = r.priority || "-";

el.className = `modal-row-value pri-${priority.toLowerCase()}`;
el.textContent = priority;
el.style.whiteSpace = "nowrap";
el.style.display = "inline-block";



      document.getElementById("m-description").textContent =
        r.description ?? "-";

      document.getElementById("m-purpose").textContent =
        r.purpose ?? "-";

      document.getElementById("review-modal")
        .classList.add("open");
    });
};
window.closeModal = function() {
  document.getElementById("review-modal").classList.remove("open");
};

window.openOngoingModal = function(id) {
  fetch(`fetch.php?action=get_request&id=${id}`)
    .then(res => res.json())
    .then(r => {

      if (!r || r.error) return alert("Failed to load request");

      document.getElementById("m-ido").textContent = "REQ-" + r.fund_request_id;
      document.getElementById("m-projecto").textContent = r.request_title ?? "-";
      document.getElementById("m-requestero").textContent = r.full_name ?? "-";
      document.getElementById("m-empido").textContent = "EMP-" + r.employee_id ?? "-";
      document.getElementById("m-amounto").textContent = "SAR " + Number(r.amount_requested || 0).toLocaleString();
     
      document.getElementById("m-deadlineo").textContent = r.project_due_date ?? "-";
      document.getElementById("m-remaining_amounto").textContent = r.remaining_amount ?? "-";
	  document.getElementById("m-statuso").innerHTML =
  renderStatusBadge(r.status);
	  

	  


      document.getElementById("ongoing-modal").classList.add("open");
	  
    });
};
window.closeOngoingModal = function() {
  document.getElementById("ongoing-modal").classList.remove("open");
};



window.openRecoveryModal = function(id) {
	
	window.recoveryRequestId = id;
  fetch(`fetch.php?action=get_request&id=${id}`)
    .then(res => res.json())
    .then(r => {

      if (!r || r.error) return alert("Failed to load request");

      

      document.getElementById("recovery-modal").classList.add("open");
    });
};


window.openRecoverySuccessModal = function(text) {

  document.getElementById("recovery-modal")?.classList.remove("open");

  document.getElementById("recovery-success-text").textContent = text;

  document.getElementById("recovery-success-modal")
    .classList.add("open");
};



function closeRecoveryModal() {

  document.getElementById("recovery-modal")
    .classList.remove("open");
}

function closeBothModals() {
  document.getElementById("recovery-success-modal")?.classList.remove("open");
}


async function submitDecline() {

  const id = window.currentApproveId;

  const reason = document.getElementById("decline-reason")
    .value
    .trim();

  console.log("Decline ID:", id);

  if (!id) {
    alert("Invalid request");
    return;
  }

 if (!reason) {

  const textarea = document.getElementById("decline-reason");

  textarea.style.border = "1.5px solid var(--red)";
 

  setTimeout(() => {
    textarea.style.border = "";
    textarea.style.boxShadow = "";
  }, 1000);

  return;
}

  try {

    const formData = new FormData();

    formData.append("id", id);
    formData.append("reason", reason);

    const res = await fetch(
      "fetch.php?action=update_decline",
      {
        method: "POST",
        body: formData
      }
    );

    const data = await res.json();

    console.log(data);

    if (!data.success) {
      alert(data.error || "Decline failed");
      return;
    }

    // close review modal
    closeModal();

    // close decline modal
    closeDeclineModal();

    // refresh tables
    await AccountantDashboard.renderNewly();
    await AccountantDashboard.renderOngoing();

    // clear textarea
    document.getElementById("decline-reason").value = "";

    // show success modal
    document.getElementById("declineSuccess")
      .classList.add("open");

  } catch (err) {

    console.error(err);
    alert("Decline error");
  }
}

function closeDeclineModal() {

  document.getElementById("decline-overlay")
    .classList.remove("open");
	
}

function closeDeclineSuccess() {

  document.getElementById("declineSuccess")
    .classList.remove("open");
	showToast("Request has been declined", "info");
}


window.openCancelConfirmModal = function(id) {
   window.cancelRequestId = id;

  document.getElementById("confirm-title").textContent =
    "Cancel this request?";

  document.getElementById("confirm-desc").textContent =
    "This will cancel the request permanently.";

  document.getElementById("confirmCancel-overlay").classList.add("open");
};

window.closeCancelConfirm = function () {

  document.getElementById("confirmCancel-overlay")
    .classList.remove("open");
};


window.openCancelSuccessModal = function (id) {

  document.getElementById("confirm-icon")
    .classList.remove("warn");

  document.getElementById("confirm-icon")
    .classList.add("success");

  document.getElementById("confirm-title").textContent =
    "Request Cancelled";

  document.getElementById("confirm-desc").textContent =
    `Request REQ-${id} has been cancelled and marked as closed.`;


  document.getElementById("confirmCancel-overlay")
    .classList.remove("open");

  // then open success modal (THIS is the key missing behavior)
  document.getElementById("cancel-id").textContent = id;
  document.getElementById("cancelSuccess-overlay")
    .classList.add("open");
};

window.closeCancelSuccess = function () {

  document.getElementById("confirmCancel-overlay")
    .classList.remove("open");
};




window.closeCancel = function () {

  document.getElementById("cancelSuccess-overlay")
    .classList.remove("open");
};


function toggleNotifPanel() {

  const panel =
    document.getElementById("notif-panel");

  if (!panel) return;

  panel.classList.toggle("open");
}

let confirmCallback = null;

function showConfirm(type, callback) {
  confirmCallback = callback;

  const overlay = document.getElementById("logout-overlay");
  overlay.classList.add("open");
}

function confirmLogout() {
  const overlay = document.getElementById("logout-overlay");
  overlay.classList.remove("open");

  if (typeof confirmCallback === "function") {
    confirmCallback();
  }

  confirmCallback = null;
}

function cancelLogout() {
  const overlay = document.getElementById("logout-overlay");
  overlay.classList.remove("open");
  confirmCallback = null;
}














  
  

  







 

  
  
  
  const TITLES = {
    'overview':  'Overview',
    'newly':     'Manage Newly Requested',
    'ongoing':   'Manage Ongoing Requests',
    'import':    'Import Transactions'
  };

  function navigate(section, btn) {
    document.querySelectorAll('.view').forEach(function(v){ v.classList.remove('active'); });
    document.querySelectorAll('.nav-item').forEach(function(n){ n.classList.remove('active'); });
    document.getElementById('view-' + section).classList.add('active');
    if (btn) btn.classList.add('active');
    document.getElementById('page-title').textContent = TITLES[section] || section;
  }
  function closeModal(e) { if (e.target.classList.contains('modal-overlay')) closeModalDirect(); }
  function closeModalDirect() { document.querySelectorAll('.modal-overlay').forEach(function(m){ m.classList.remove('open'); }); }
  function showToast(msg) {
    var t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    setTimeout(function(){ t.classList.remove('show'); }, 3000);
  }

</script>


<!-- SheetJS Library -->
<script src="https://cdn.jsdelivr.net/npm/xlsx/dist/xlsx.full.min.js"></script>

<script>
  let uploadedFile = null;

  // REQUIRED COLUMNS
  const REQUIRED_COLUMNS = [
"transaction_date",
  "amount",
  "card_suffix",
  "transaction_type",
  "description"
  ];

  // ===============================
  // HANDLE DROP
  // ===============================
  function handleDrop(event) {
    event.preventDefault();

    document.getElementById("drop-zone").classList.remove("drag");

    const file = event.dataTransfer.files[0];
    handleFile(file);
  }

  // ===============================
  // HANDLE FILE
  // ===============================
  async function handleFile(file) {

    if (!file) return;

    const allowed = [".csv", ".xls", ".xlsx"];
    const lower = file.name.toLowerCase();

    const isValidType = allowed.some(ext => lower.endsWith(ext));

    if (!isValidType) {
      alert("Only CSV, XLS, and XLSX files are allowed.");
      return;
    }

    // MAX 10MB
    if (file.size > 10 * 1024 * 1024) {
      alert("File size exceeds 10MB.");
      return;
    }

    try {

      // READ FILE
      const data = await file.arrayBuffer();

      const workbook = XLSX.read(data, {
        type: "array"
      });

      const sheetName = workbook.SheetNames[0];

      const worksheet = workbook.Sheets[sheetName];

      // GET ROWS
      const rows = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: ""
      });

      if (!rows.length) {
        alert("The uploaded file is empty.");
        return;
      }

      // FIRST ROW = HEADERS
      const headers = rows[0].map(h =>
  String(h).trim().toLowerCase()
);

      // CHECK REQUIRED COLUMNS
      const missingColumns = REQUIRED_COLUMNS.filter(
        col => !headers.includes(col)
      );

      if (missingColumns.length > 0) {
showToast("Missing required columns: " + missingColumns.join(", "));
        return;
      }

      // BLOCK EXTRA COLUMNS
    
      const extraColumns = headers.filter(
        h => !REQUIRED_COLUMNS.includes(h)
      );

      if (extraColumns.length > 0) {	
		showToast("Unexpected columns found:\n" + extraColumns.join(", "));
        return;
      }
      

      // SUCCESS
      uploadedFile = file;

      document.getElementById("drop-title").innerText =
        file.name + " selected";

      document.getElementById("drop-actions").style.display = "flex";

    } catch (err) {

      console.error(err);

      alert("Failed to read the file.");
    }
  }

  // ===============================
  // IMPORT
  // ===============================
  var _importInProgress = false;
  async function importFile() {
  if (_importInProgress) { showToast('Import already in progress...'); return; }
  if (!uploadedFile) {
    alert("Please upload a valid file first.");
    return;
  }
  _importInProgress = true;
  var importBtn = document.querySelector('.btn.btn-primary[onclick="importFile()"]');
  if (importBtn) { importBtn.disabled = true; importBtn.textContent = '⏳ Importing...'; }

  const formData = new FormData();
  formData.append("file", uploadedFile);

  try {

const res = await fetch("fetch.php?action=import_transactions", {
 method: "POST",
  body: formData,
  credentials: "include"   
});

const text = await res.text();
console.log("RAW RESPONSE:", text);

let data;
try {
  data = JSON.parse(text);
} catch (e) {
  console.error("NOT JSON:", text);
  alert("Server returned invalid response");
  return;
}

if (!data.success) {

  const errors = Array.isArray(data.errors)
    ? data.errors
    : [];

  if (errors.length) {

    const firstError = errors.sort(
      (a, b) => (a.row ?? 0) - (b.row ?? 0)
    )[0];

showToast(
  `No transactions imported because of an error in Row ${firstError.row}: ${firstError.message}`,
  "warning"
);
  } else {
    showToast("Import failed", "warning");
  }

  clearFile();
  _importInProgress = false; if (importBtn) { importBtn.disabled = false; importBtn.textContent = 'Import Now'; }

  document.getElementById("drop-actions").style.display = "none";

  document.getElementById("drop-title").innerText =
    "Drag your file here or click to browse";

  return;
}

/* SUCCESS */
showToast(
  data.message || "Transactions imported successfully",
  "success"
);

clearFile();

// Reload to show updated Spending status
setTimeout(() => {
  window.location.href = window.location.pathname + '?view=ongoing&t=' + Date.now();
}, 1800);

  } catch (err) {
    console.error(err);
    alert("Upload failed.");
  }
}

async function readNotif(id) {

  try {

    await fetch(
      "fetch.php?action=mark_notification_read",
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          notification_id: id
        })
      }
    );

    loadNotifications();

  } catch (err) {

    console.error(err);

  }
}


function showToast(msg, type = "error") {
  const toast = document.createElement("div");

  toast.className = "toast " + type;
  toast.innerText = msg;

  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add("show"), 10);

  const duration =
    type === "warning" ? 9000 :
    type === "success" ? 3000 :
    3000;

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

async function loadNotifications() {

  try {

    const res = await fetch(
      "fetch.php?action=fetch_notifications",
      {
        credentials: "include"
      }
    );

    const data = await res.json();

    const list  = document.getElementById("notif-list");
    const count = document.getElementById("notif-count");

    list.innerHTML = "";
	if (!data.length) {

  list.innerHTML = `
    <div class="notif-empty">
      No notifications
    </div>
  `;

  count.textContent = "0";

  return;
}

    if (!Array.isArray(data)) return;

    let unread = 0;

    data.forEach(n => {

      if (Number(n.is_read) === 0) unread++;

      // -----------------------------------
      // ICON / COLOR BY TYPE
      // -----------------------------------
      let iconBg   = "var(--teal-dim)";
      let iconColor = "var(--teal)";
      let iconSvg = `
        <svg width="15" height="15"
             viewBox="0 0 24 24"
             fill="none"
             stroke="currentColor"
             stroke-width="2"
             stroke-linecap="round"
             stroke-linejoin="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14,2 14,8 20,8"></polyline>
        </svg>
      `;

 const type = (n.type || "").toLowerCase();

// success / approved
if (
  type.includes("approved") ||
  type.includes("success") ||
  type.includes("processed") ||
  type.includes("account_cleared") ||
  type.includes("disbursed")
) {

  iconBg = "var(--green-dim)";
  iconColor = "var(--green)";

  iconSvg = `
    <svg width="15" height="15"
         viewBox="0 0 24 24"
         fill="none"
         stroke="currentColor"
         stroke-width="2"
         stroke-linecap="round"
         stroke-linejoin="round">
      <path d="M9 11l3 3L22 4"></path>
      <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
    </svg>
  `;
}


      // warning / flagged
      else if (
        type.includes("warning") ||
        type.includes("priority") ||
		type.includes("account_ready") ||
        type.includes("flagged")
      ) {

        iconBg = "var(--red-dim)";
        iconColor = "var(--red)";

        iconSvg = `
          <svg width="15" height="15"
               viewBox="0 0 24 24"
               fill="none"
               stroke="currentColor"
               stroke-width="2"
               stroke-linecap="round"
               stroke-linejoin="round">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
          </svg>
        `;
      }

      // -----------------------------------
      // CREATE ITEM
      // -----------------------------------
      const div = document.createElement("div");

      div.className =
        "notif-item" +
        (Number(n.is_read) === 0 ? " unread" : "");

      div.onclick = () => readNotif(n.notification_id);

      div.innerHTML = `

        <div class="notif-icon"
             style="background:${iconBg};color:${iconColor}">
          ${iconSvg}
        </div>

        <div class="notif-body">

          <div class="notif-msg">
            ${n.message}
          </div>

          <div class="notif-time">
            ${new Date(n.created_at).toLocaleString()}
          </div>

        </div>

        ${
          Number(n.is_read) === 0
          ? `<div class="notif-unread-dot"></div>`
          : ``
        }

      `;

      list.appendChild(div);

    });

    count.textContent = unread;

const notifDot = document.getElementById("notif-dot");

notifDot.classList.toggle("active", unread > 0);

if (notifDot) {

  // Case 1: no notifications at all
  if (!Array.isArray(data) || data.length === 0) {
    notifDot.style.display = "none";
    return;
  }

  // Case 2: count unread
  const unread = data.filter(n => Number(n.is_read) === 0).length;

  notifDot.style.display = unread > 0 ? "block" : "none";
}

  } catch (err) {

    console.error("Notification error:", err);

  }
}





// -----------------------------------
// MARK ALL READ
// -----------------------------------
function markAllRead() {

  fetch(
    "fetch.php?action=mark_all_read",
    {
      method: "POST",
      credentials: "include"
    }
  )
  .then(() => loadNotifications());

}


async function clearAllNotifs() {

  try {

    await fetch(
      "fetch.php?action=clear_all_notifs",
      {
        method: "POST",
        credentials: "include"
      }
    );


    const list = document.getElementById("notif-list");
    const count = document.getElementById("notif-count");
    const dot = document.getElementById("notif-dot");

    list.innerHTML = `<div class="notif-empty">No notifications</div>`;
    count.textContent = "0";

    if (dot) {
      dot.style.display = "none";
    }

    // 🔄 then sync with server
    loadNotifications();

  } catch (err) {
    console.error(err);
    alert("Error clearing notifications");
  }
}

function clearFile() {

  const fileInput = document.getElementById("fileInput");

  if (!fileInput) return;

  // reset file input
  fileInput.value = "";

  // clear preview text (if you have one)
  const fileNameDisplay = document.getElementById("file-name");
  if (fileNameDisplay) {
    fileNameDisplay.textContent = "";
  }

  // clear any stored variable (optional)
  window.uploadedFile = null;

  console.log("File cleared");
}


// -----------------------------------
// INITIAL LOAD
// -----------------------------------
document.addEventListener("DOMContentLoaded", () => {

  loadNotifications();

  // auto refresh every 10s
  setInterval(loadNotifications, 10000);

});

</script>




<div class="confirm-overlay success-overlay" id="recovery-success-modal">

  <div class="confirm-box">

    <div class="confirm-icon-row">

      <div class="confirm-icon success" id="confirm-icon">

        <svg id="confirm-icon-svg"
             width="26"
             height="26"
             viewBox="0 0 24 24"
             fill="none"
             stroke="currentColor"
             stroke-width="2"
             stroke-linecap="round"
             stroke-linejoin="round">

          <path d="M9 11l3 3L22 4"></path>

          <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>

        </svg>

      </div>

    </div>

    <div class="confirm-title" id="confirm-title">
      Amount Recovered
    </div>

    <div class="confirm-desc" id="recovery-success-text">
      -
    </div>

    <div class="confirm-btns one-col" id="confirm-btns">

      <button class="cbtn cbtn-primary"
              onclick="closeBothModals()">
        Done
      </button>

    </div>

  </div>

</div>

<!-- DECLINE REASON MODAL -->
<div class="decline-overlay" id="decline-overlay">
  <div class="decline-box">
    <div class="decline-hdr">
      <div>
        <div class="decline-hdr-title">Decline Request</div>
        <div class="decline-hdr-sub" id="decline-req-id">REQ-001</div>
      </div>
      <button class="modal-close" onclick="closeDeclineModal()">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="decline-body">
      <div class="decline-label">Reason for Declining</div>
      <textarea class="decline-textarea" id="decline-reason" placeholder="Please provide a clear reason for declining this request..."></textarea>
    </div>
    <div class="decline-footer">
      <button class="decline-submit" onclick="submitDecline()">Submit Decline</button>
      <button class="decline-cancel" onclick="closeDeclineModal()">Cancel</button>
    </div>
  </div>
</div>



<div class="confirm-overlay" id="logout-overlay"> <div class="confirm-box"> <div class="confirm-icon-row"> 
<div class="confirm-icon exit" id="confirm-icon"> 
<svg id="confirm-icon-svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16,17 21,12 16,7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg> </div> </div> <div class="confirm-title" id="confirm-title">Log out?</div> <div class="confirm-desc" id="confirm-desc">You will be returned to the Manea landing page.</div> <div class="confirm-btns two-col" id="confirm-btns"> 
<button class="cbtn cbtn-primary" id="confirm-ok" onclick="confirmLogout()">Log Out</button> 
<button class="cbtn cbtn-ghost" id="confirm-cancel" onclick="cancelLogout()">Cancel</button> 
</div> </div> </div>









<script>
  // All DOM elements exist now — run inits
  renderOverview();
  renderNewly();
  renderOngoing();
  renderNotifications();
</script>

<!-- CONFIRMATION DIALOG -->

<div class="confirm-overlay" id="confirmCancel-overlay">

  <div class="confirm-box">

    <div class="confirm-icon-row">
      <div class="confirm-icon warn" id="confirm-icon">

        <svg id="confirm-icon-svg"
             width="26"
             height="26"
             viewBox="0 0 24 24"
             fill="none"
             stroke="currentColor"
             stroke-width="2"
             stroke-linecap="round"
             stroke-linejoin="round">

          <circle cx="12" cy="12" r="10"></circle>
          <line x1="15" y1="9" x2="9" y2="15"></line>
          <line x1="9" y1="9" x2="15" y2="15"></line>

        </svg>

      </div>
    </div>

    <div class="confirm-title" id="confirm-title">
      Cancel this request?
    </div>

    <div class="confirm-desc" id="confirm-desc">
      This will cancel the ongoing request and mark it as closed.
    </div>

    <div class="confirm-btns two-col" id="confirm-btns">

      <button class="cbtn cbtn-red"
              id="confirm-ok"
              onclick="confirmCancelRequest()">
        Yes, Cancel
      </button>

      <button class="cbtn cbtn-ghost"
              id="confirm-cancel"
              onclick="closeCancelSuccess()">
        Cancel
      </button>

    </div>

  </div>

</div>


</body>
</html>
