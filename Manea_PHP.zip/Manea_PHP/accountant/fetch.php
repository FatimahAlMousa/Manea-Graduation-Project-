<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');

require_once __DIR__ . '/../includes/db.php';



$action = $_GET['action'] ?? '';



function refreshFundStatus($conn) {

  // First: set FLAGGED for any request with open flags
  $conn->query("
    UPDATE fund_requests fr
    SET status = 'FLAGGED'
    WHERE status NOT IN ('PENDING','REJECTED','CLOSED','READY_TO_CLOSE')
    AND EXISTS (
      SELECT 1 FROM flags f
      WHERE f.fund_request_id = fr.fund_request_id
      AND f.status = 'OPEN'
    )
  ");

  $conn->query("
    UPDATE fund_requests
    SET status = CASE

      WHEN status = 'PENDING'
      THEN 'PENDING'

      WHEN status = 'REJECTED'
      THEN 'REJECTED'

      WHEN status = 'FLAGGED'
      THEN 'FLAGGED'

      WHEN status = 'CLOSED'
      THEN 'CLOSED'

      WHEN status IN ('APPROVED','ACTIVE')
           AND project_due_date IS NOT NULL
           AND project_due_date < NOW()
           AND (amount_requested - amount_spent) > 0
      THEN 'READY_TO_CLOSE'

      WHEN status = 'APPROVED'
           AND (amount_requested - amount_spent) < amount_requested
           AND (amount_requested - amount_spent) > 0
      THEN 'ACTIVE'

      WHEN status != 'REJECTED'
           AND ((amount_requested - amount_spent) <= 0)
      THEN 'CLOSED'

      WHEN status = 'APPROVED'
           AND (amount_requested - amount_spent) >= amount_requested
           AND (amount_requested - amount_spent) > 0
      THEN 'APPROVED'

      ELSE status

    END
  ");



  // ----------------------------------------
  // GET NEW STATUSES
  // ----------------------------------------
  $res2 = $conn->query("
    SELECT
      fund_request_id,
      employee_id,
      status
    FROM fund_requests
  ");

  while ($r = $res2->fetch_assoc()) {

    $id = $r['fund_request_id'];
    $newStatus = $r['status'];
    $oldStatus = $before[$id] ?? null;

    // only notify if status changed
    if ($oldStatus === $newStatus) {
      continue;
    }

    $employeeId = $r['employee_id'];

    // ----------------------------------------
    // READY TO CLOSE
    // ----------------------------------------
    if ($newStatus === '') {

      $type = '';

      $message =
        "Fund request #{$id} is ready to close.";

      $stmt = $conn->prepare("
        INSERT INTO notifications
        (user_id, type, message, is_read, created_at)
        VALUES (?, ?, ?, 0, NOW())
      ");

      $stmt->bind_param(
        "iss",
        $employeeId,
        $type,
        $message
      );

      $stmt->execute();
      $stmt->close();
    }

    // ----------------------------------------
    // CLOSED
    // ----------------------------------------
    if ($newStatus === 'CLOSED') {

      $type = 'REQUEST_CLOSED';

      $message =
        "Fund request #{$id} has been closed.";

      $stmt = $conn->prepare("
        INSERT INTO notifications
        (user_id, type, message, is_read, created_at)
        VALUES (?, ?, ?, 0, NOW())
      ");

      $stmt->bind_param(
        "iss",
        $employeeId,
        $type,
        $message
      );

      $stmt->execute();
      $stmt->close();
    }
  }
}

function sendAccountantNotifications($conn) {

  // --------------------------------------------------
  // GET ALL ACCOUNTANTS
  // --------------------------------------------------
  $accResult = $conn->query("
    SELECT user_id
    FROM users
    WHERE role = 'ACCOUNTANT'
  ");

  if (!$accResult) return;

  while ($acc = $accResult->fetch_assoc()) {

    $accountantId = $acc['user_id'];

    // ==================================================
    // 1. PENDING REQUESTS
    // ==================================================
    $pendingResult = $conn->query("
      SELECT fund_request_id
      FROM fund_requests
      WHERE status = 'PENDING'
    ");

    while ($p = $pendingResult->fetch_assoc()) {

      $requestId = $p['fund_request_id'];

      // avoid duplicate notifications
      $check = $conn->query("
        SELECT notification_id
        FROM notifications
        WHERE user_id = $accountantId
        AND type = ''
        AND message = 'Fund request #$requestId is pending approval.'
        LIMIT 1
      ");

      if ($check->num_rows == 0) {

        $message =
          "Fund request #$requestId is pending approval.";

        $stmt = $conn->prepare("
          INSERT INTO notifications
          (
            user_id,
            type,
            message,
            is_read,
            created_at
          )
          VALUES
          (
            ?,
            '',
            ?,
            0,
            NOW()
          )
        ");

        $stmt->bind_param(
          "is",
          $accountantId,
          $message
        );

        $stmt->execute();
        $stmt->close();
      }
    }

    // ==================================================
    // 2. ACTIVE
    // ==================================================
    $activeResult = $conn->query("
      SELECT fund_request_id
      FROM fund_requests
      WHERE status = 'ACTIVE'
    ");

    while ($a = $activeResult->fetch_assoc()) {

      $requestId = $a['fund_request_id'];

      $message =
        "Fund request #$requestId is now actively spending.";

      $check = $conn->query("
        SELECT notification_id
        FROM notifications
        WHERE user_id = $accountantId
        AND type = ''
        AND message = '$message'
        LIMIT 1
      ");

      if ($check->num_rows == 0) {

        $stmt = $conn->prepare("
          INSERT INTO notifications
          (
            user_id,
            type,
            message,
            is_read,
            created_at
          )
          VALUES
          (
            ?,
            '',
            ?,
            0,
            NOW()
          )
        ");

        $stmt->bind_param(
          "is",
          $accountantId,
          $message
        );

        $stmt->execute();
        $stmt->close();
      }
    }

    // ==================================================
    // 3. READY TO CLOSE
    // ==================================================
    $readyResult = $conn->query("
      SELECT fund_request_id
      FROM fund_requests
      WHERE status = ''
    ");

    while ($r = $readyResult->fetch_assoc()) {

      $requestId = $r['fund_request_id'];

      $message =
        "Fund request #$requestId is ready to close.";

      $check = $conn->query("
        SELECT notification_id
        FROM notifications
        WHERE user_id = $accountantId
        AND type = ''
        AND message = '$message'
        LIMIT 1
      ");

      if ($check->num_rows == 0) {

        $stmt = $conn->prepare("
          INSERT INTO notifications
          (
            user_id,
            type,
            message,
            is_read,
            created_at
          )
          VALUES
          (
            ?,
            '',
            ?,
            0,
            NOW()
          )
        ");

        $stmt->bind_param(
          "is",
          $accountantId,
          $message
        );

        $stmt->execute();
        $stmt->close();
      }
    }

    // ==================================================
    // 4. CLOSED / CLEARED
    // ==================================================
    $closedResult = $conn->query("
      SELECT fund_request_id
      FROM fund_requests
      WHERE status = 'CLOSED'
    ");

    while ($c = $closedResult->fetch_assoc()) {

      $requestId = $c['fund_request_id'];

      $message =
        "Fund request #$requestId has been cleared.";

      $check = $conn->query("
        SELECT notification_id
        FROM notifications
        WHERE user_id = $accountantId
        AND type = 'ACCOUNT_CLEARED'
        AND message = '$message'
        LIMIT 1
      ");

      if ($check->num_rows == 0) {

        $stmt = $conn->prepare("
          INSERT INTO notifications
          (
            user_id,
            type,
            message,
            is_read,
            created_at
          )
          VALUES
          (
            ?,
            'ACCOUNT_CLEARED',
            ?,
            0,
            NOW()
          )
        ");

        $stmt->bind_param(
          "is",
          $accountantId,
          $message
        );

        $stmt->execute();
        $stmt->close();
      }
    }

    // ==================================================
    // 5. FLAGGED
    // ==================================================
    $flaggedResult = $conn->query("
      SELECT fund_request_id
      FROM fund_requests
      WHERE status = 'FLAGGED'
    ");

    while ($f = $flaggedResult->fetch_assoc()) {

      $requestId = $f['fund_request_id'];

      $message =
        "Fund request #$requestId has flagged transactions.";

      $check = $conn->query("
        SELECT notification_id
        FROM notifications
        WHERE user_id = $accountantId
        AND type = 'FLAGGED_TRANSACTION'
        AND message = '$message'
        LIMIT 1
      ");

      if ($check->num_rows == 0) {

        $stmt = $conn->prepare("
          INSERT INTO notifications
          (
            user_id,
            type,
            message,
            is_read,
            created_at
          )
          VALUES
          (
            ?,
            'FLAGGED_TRANSACTION',
            ?,
            0,
            NOW()
          )
        ");

        $stmt->bind_param(
          "is",
          $accountantId,
          $message
        );

        $stmt->execute();
        $stmt->close();
      }
    }
  }
}

switch ($action) {

  // ------------------------------------------------------------------
  // 1. FETCH ALL PENDING REQUESTS
  // ------------------------------------------------------------------
  case 'fetch_pending':

refreshFundStatus($conn);

    $sql = "SELECT 
              fund_requests.*,
              (fund_requests.amount_requested - fund_requests.amount_spent) AS remaining_amount,
              DATE(fund_requests.created_at) AS request_date,
              users.full_name
            FROM fund_requests
            INNER JOIN users
            ON fund_requests.employee_id = users.user_id
            WHERE fund_requests.status = 'PENDING'";

    $result = $conn->query($sql);

    $rows = [];

    while ($r = $result->fetch_assoc()) {
      $rows[] = $r;
    }

    echo json_encode($rows);
    exit;

  // ------------------------------------------------------------------
  // 2. FETCH ALL ONGOING REQUESTS
  // ------------------------------------------------------------------
  case 'fetch_ongoing':
  
  refreshFundStatus($conn);


$sql = "SELECT 
          fund_requests.*,
          (fund_requests.amount_requested - fund_requests.amount_spent) AS remaining_amount,
          DATE(fund_requests.created_at) AS request_date,
          users.full_name
        FROM fund_requests
        INNER JOIN users
        ON fund_requests.employee_id = users.user_id
        WHERE fund_requests.status NOT IN ('PENDING', 'REJECTED')";

    $result = $conn->query($sql);

    $rows = [];

    while ($r = $result->fetch_assoc()) {
      $rows[] = $r;
    }

    echo json_encode($rows);
    exit;

  // ------------------------------------------------------------------
  // 3. FETCH ONE REQUEST BY ID
  // ------------------------------------------------------------------
  case 'get_request':

    $id = intval($_GET['id'] ?? 0);

    if ($id <= 0) {

      echo json_encode([
        'error' => 'Invalid ID'
      ]);

      exit;
    }

    $stmt = $conn->prepare("
      SELECT 
        fund_requests.*,
        users.full_name
      FROM fund_requests
      INNER JOIN users
      ON fund_requests.employee_id = users.user_id
      WHERE fund_request_id = ?
    ");

    $stmt->bind_param("i", $id);

    $stmt->execute();
	

    $res = $stmt->get_result();

    echo json_encode(
      $res->fetch_assoc() ?: ['error' => 'Not found']
    );

    $stmt->close();

    exit;

  // ------------------------------------------------------------------
  // 4. DASHBOARD COUNTS
  // ------------------------------------------------------------------
  case 'fetch_counts':

    $pending = $conn->query("
      SELECT COUNT(*) AS c
      FROM fund_requests
      WHERE status = 'PENDING'
    ")->fetch_assoc()['c'];

    $ongoing = $conn->query("
      SELECT COUNT(*) AS c
      FROM fund_requests
      WHERE status != 'PENDING'
    ")->fetch_assoc()['c'];

    echo json_encode([
      'pending' => $pending,
      'ongoing' => $ongoing
    ]);

    exit;

  // ------------------------------------------------------------------
  // 5. UPDATE STATUS (APPROVE)
  // ------------------------------------------------------------------
  case 'update_status':

  $id = intval($_POST['id'] ?? 0);

  if (!$id) {

    echo json_encode([
      'success' => false,
      'error' => 'Invalid params'
    ]);

    exit;
  }

  // ----------------------------------------
  // UPDATE REQUEST STATUS
  // ----------------------------------------

  $stmt = $conn->prepare("
    UPDATE fund_requests
    SET status = 'APPROVED',
        amount_spent = 0,
        approved_at = NOW()
    WHERE fund_request_id = ?
  ");

  $stmt->bind_param("i", $id);

  $ok = $stmt->execute();
  refreshFundStatus($conn);
sendAccountantNotifications($conn);  

  $stmt->close();

  if ($ok) {
    refreshFundStatus($conn);
	sendAccountantNotifications($conn);
  }

  if (!$ok) {

    echo json_encode([
      'success' => false,
      'error' => 'Failed to update request'
    ]);

    exit;
  }

  echo json_encode([
    'success' => true
  ]);

  exit;

    // ----------------------------------------
    // GET REQUEST + EMPLOYEE
    // ----------------------------------------

    $stmtUser = $conn->prepare("
      SELECT employee_id
      FROM fund_requests
      WHERE fund_request_id = ?
    ");

    $stmtUser->bind_param("i", $id);

    $stmtUser->execute();

    $resultUser = $stmtUser->get_result();

    $rowUser = $resultUser->fetch_assoc();

    $stmtUser->close();

    $employeeId = $rowUser['employee_id'] ?? null;

    // ----------------------------------------
    // SEND NOTIFICATION
    // ----------------------------------------

    if ($employeeId) {

      $type = 'REQUEST_APPROVED';

      $message =
        "Your fund request #" . $id .
        " has been approved.";

      $stmtNotif = $conn->prepare("
        INSERT INTO notifications
        (
          user_id,
          type,
          message,
          is_read,
          created_at
        )
        VALUES
        (
          ?,
          ?,
          ?,
          0,
          NOW()
        )
      ");

      $stmtNotif->bind_param(
        "iss",
        $employeeId,
        $type,
        $message
      );

      $stmtNotif->execute();

      $stmtNotif->close();
    }

    echo json_encode([
      'success' => true
    ]);

    exit;

   // ------------------------------------------------------------------
  // 6. DECLINE WITH REASON
  // ------------------------------------------------------------------
  case 'update_decline':

    $id = intval($_POST['id'] ?? 0);

    $reason = trim($_POST['reason'] ?? '');

    if (!$id || !$reason) {

      echo json_encode([
        'success' => false,
        'error' => 'Missing decline reason'
      ]);

      exit;
    }

    // ----------------------------------------
    // UPDATE REQUEST
    // ----------------------------------------

    $stmt = $conn->prepare("
      UPDATE fund_requests
      SET status = 'REJECTED',
          rejection_reason = ?
      WHERE fund_request_id = ?
    ");

    $stmt->bind_param("si", $reason, $id);

    $ok = $stmt->execute();
	

    $stmt->close();
	


    if (!$ok) {

      echo json_encode([
        'success' => false,
        'error' => 'Failed to reject request'
      ]);

      exit;
    }




    // ----------------------------------------
    // GET EMPLOYEE ID
    // ----------------------------------------

    $stmtUser = $conn->prepare("
      SELECT employee_id
      FROM fund_requests
      WHERE fund_request_id = ?
    ");

    $stmtUser->bind_param("i", $id);

    $stmtUser->execute();

    $resultUser = $stmtUser->get_result();

    $rowUser = $resultUser->fetch_assoc();

    $stmtUser->close();

    $employeeId = $rowUser['employee_id'] ?? null;

    // ----------------------------------------
    // SEND NOTIFICATION
    // ----------------------------------------

    if ($employeeId) {

      $type = 'REQUEST_REJECTED';

      // MESSAGE = meaningful rejection message
      $message = 'Your fund request has been rejected. Reason: ' . $reason;

      $stmtNotif = $conn->prepare("
        INSERT INTO notifications
        (
          user_id,
          type,
          message,
          is_read,
          created_at
        )
        VALUES
        (
          ?,
          ?,
          ?,
          0,
          NOW()
        )
      ");

      $stmtNotif->bind_param(
        "iss",
        $employeeId,
        $type,
        $message
      );

      $stmtNotif->execute();

      $stmtNotif->close();
    }

    echo json_encode([
      'success' => true
    ]);

    exit;
	
	
	// ----------------------------------------
    // RECOVER REMAINING AMOUNT
    // ----------------------------------------

case 'recover_ongoing':

  session_start();
  header('Content-Type: application/json');

  $data = json_decode(file_get_contents("php://input"), true);

  if (!is_array($data)) {
    echo json_encode([
      "success" => false,
      "message" => "Invalid JSON body"
    ]);
    exit;
  }

  $fund_request_id = intval($data['fund_request_id'] ?? 0);

  if ($fund_request_id <= 0) {
    echo json_encode([
      "success" => false,
      "message" => "Invalid request ID"
    ]);
    exit;
  }

  // ✅ MOVE THIS DOWN (DO NOT EXIT HERE)
  // echo json_encode([...]);
  // exit;

  $accountant_id = $_SESSION['user_id'] ?? null;

  if (!$accountant_id) {
    echo json_encode([
      "success" => false,
      "message" => "Session expired. Please login again."
    ]);
    exit;
  }

  $conn->begin_transaction();

  try {

    // GET REQUEST FIRST
    $stmtGet = $conn->prepare("
      SELECT remaining_amount, employee_id
      FROM fund_requests
      WHERE fund_request_id = ?
    ");

    $stmtGet->bind_param("i", $fund_request_id);
    $stmtGet->execute();

    $result = $stmtGet->get_result();
    $row = $result->fetch_assoc();
    $stmtGet->close();

    if (!$row) {
      throw new Exception("Request not found");
    }

    $recoveredAmount = (float)($row['remaining_amount'] ?? 0);

    // UPDATE REQUEST
    $stmt = $conn->prepare("
      UPDATE fund_requests
      SET amount_spent = amount_requested,
          remaining_amount = 0,
          status = 'CLOSED'
      WHERE fund_request_id = ?
    ");

    $stmt->bind_param("i", $fund_request_id);

    if (!$stmt->execute()) {
      throw new Exception($stmt->error);
    }

    $stmt->close();

    // 🔥 AUTO STATUS FIX
    refreshFundStatus($conn);

    // INSERT RECOVERY LOG
    $stmtRec = $conn->prepare("
      INSERT INTO fund_recoveries
      (fund_request_id, accountant_id, amount_recovered, recovered_at)
      VALUES (?, ?, ?, NOW())
    ");

    $stmtRec->bind_param(
      "iid",
      $fund_request_id,
      $accountant_id,
      $recoveredAmount
    );

    if (!$stmtRec->execute()) {
      throw new Exception($stmtRec->error);
    }

    $stmtRec->close();

    $conn->commit();

    echo json_encode([
      "success" => true,
      "recovered_amount" => $recoveredAmount
    ]);
    exit;

  } catch (Exception $e) {

    $conn->rollback();

    echo json_encode([
      "success" => false,
      "message" => $e->getMessage()
    ]);
    exit;
  }
  
// ------------------------------------------------------------------
// AUTO CLOSE ALL ELIGIBLE REQUESTS
// ------------------------------------------------------------------
case 'auto_close_requests':

  $stmt = $conn->query("
    UPDATE fund_requests
    SET status = 'CLOSED',
        amount_spent = amount_requested
    WHERE (amount_requested - amount_spent) <= 0
      AND status != 'CLOSED'
  ");

  echo json_encode([
    "success" => true,
    "affected" => $conn->affected_rows
  ]);

  exit;

	
	
	  // ------------------------------------------------------------------
  // 8. CANCEL APPROVED REQUEST
  // ------------------------------------------------------------------
  case 'cancel_approved':

    $data = json_decode(
      file_get_contents("php://input"),
      true
    );

    if (!is_array($data)) {

      echo json_encode([
        "success" => false,
        "message" => "Invalid JSON body"
      ]);

      exit;
    }

    $fund_request_id = intval(
      $data['fund_request_id'] ?? 0
    );

    if ($fund_request_id <= 0) {

      echo json_encode([
        "success" => false,
        "message" => "Invalid request ID"
      ]);

      exit;
    }

    // ----------------------------------------
    // GET EMPLOYEE ID
    // ----------------------------------------

    $stmtGet = $conn->prepare("
      SELECT employee_id
      FROM fund_requests
      WHERE fund_request_id = ?
    ");

    $stmtGet->bind_param("i", $fund_request_id);

    $stmtGet->execute();

    $result = $stmtGet->get_result();

    $row = $result->fetch_assoc();

    $stmtGet->close();

    $employeeId =
      $row['employee_id'] ?? null;

    // ----------------------------------------
    // CLOSE REQUEST
    // ----------------------------------------

    $stmt = $conn->prepare("
      UPDATE fund_requests
      SET status = 'CLOSED'
      WHERE fund_request_id = ?
    ");

    $stmt->bind_param("i", $fund_request_id);

    $ok = $stmt->execute();

    $stmt->close();

    if (!$ok) {

      echo json_encode([
        "success" => false,
        "message" => "Failed to cancel request"
      ]);

      exit;
    }

    // ----------------------------------------
    // SEND NOTIFICATION
    // ----------------------------------------

    if ($employeeId) {

      $type = 'CANCELLED';

      $message =
        "Your approved fund request #" .
        $fund_request_id .
        " has been cancelled.";

      $stmtNotif = $conn->prepare("
        INSERT INTO notifications
        (
          user_id,
          type,
          message,
          is_read,
          created_at
        )
        VALUES
        (
          ?,
          ?,
          ?,
          0,
          NOW()
        )
      ");

      $stmtNotif->bind_param(
        "iss",
        $employeeId,
        $type,
        $message
      );

      $stmtNotif->execute();

      $stmtNotif->close();
    }

    echo json_encode([
      "success" => true
    ]);

    exit;
	

// ------------------------------------------------------------------
// 9. IMPORT TRANSACTIONS FILE
// ------------------------------------------------------------------
case 'import_transactions':

  // ------------------------------------------------------------
  // VALIDATE SESSION
  // ------------------------------------------------------------
  $accountantId = $_SESSION['user_id'] ?? null;

  if (!$accountantId) {

    echo json_encode([
      'success' => false,
      'error' => 'Session expired'
    ]);

    exit;
  }

  // ------------------------------------------------------------
  // VALIDATE FILE
  // ------------------------------------------------------------
  if (!isset($_FILES['file'])) {

    echo json_encode([
      'success' => false,
      'error' => 'No file uploaded'
    ]);

    exit;
  }

  $file = $_FILES['file'];

  $fileName = $file['name'];
  $fileTmp  = $file['tmp_name'];
  $fileSize = $file['size'];

  $extension = strtolower(
    pathinfo($fileName, PATHINFO_EXTENSION)
  );

  // ------------------------------------------------------------
  // VALIDATE EXTENSION
  // ------------------------------------------------------------
  $allowedExtensions = ['csv', 'xls', 'xlsx'];

  if (!in_array($extension, $allowedExtensions)) {

    echo json_encode([
      'success' => false,
      'error' => 'Invalid file type'
    ]);

    exit;
  }

  // ------------------------------------------------------------
  // VALIDATE SIZE
  // ------------------------------------------------------------
  if ($fileSize > 10 * 1024 * 1024) {

    echo json_encode([
      'success' => false,
      'error' => 'File exceeds 10MB'
    ]);

    exit;
  }

  // ------------------------------------------------------------
  // CREATE UPLOAD DIRECTORY
  // ------------------------------------------------------------
  $uploadDir = __DIR__ . "/../../uploads/csv_batches/";

  if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
  }

  // ------------------------------------------------------------
  // GENERATE UNIQUE FILE NAME
  // ------------------------------------------------------------
  $uniqueName =
    uniqid("batch_", true) .
    "." .
    $extension;

  $targetPath = $uploadDir . $uniqueName;

  // ------------------------------------------------------------
  // MOVE FILE
  // ------------------------------------------------------------
  if (!move_uploaded_file($fileTmp, $targetPath)) {

    echo json_encode([
      'success' => false,
      'error' => 'Failed to save uploaded file'
    ]);

    exit;
  }

  // ------------------------------------------------------------
  // SAVE BATCH RECORD
  // ------------------------------------------------------------
  $storedPath =
    "uploads/csv_batches/" . $uniqueName;

  $stmtBatch = $conn->prepare("
    INSERT INTO csv_batches
    (
      accountant_id,
      file_name,
      file_path
    )
    VALUES
    (
      ?,
      ?,
      ?
    )
  ");

  $stmtBatch->bind_param(
    "iss",
    $accountantId,
    $fileName,
    $storedPath
  );

  $stmtBatch->execute();

  $csvBatchId = $stmtBatch->insert_id;

  $stmtBatch->close();

  // ------------------------------------------------------------
  // START DATABASE TRANSACTION
  // ------------------------------------------------------------

 $conn->begin_transaction();

try {

  $importedCount = 0;
  $skippedCount  = 0;
  $errors = [];
  $validRows = [];
  $rowNumber = 1; // header row

  // ------------------------------------------------------------
  // READ CSV
  // ------------------------------------------------------------
  if ($extension === 'csv') {

    $handle = fopen($targetPath, 'r');

    if (!$handle) {
      throw new Exception("Unable to open CSV");
    }

    // ----------------------------------------------------------
    // READ HEADER ROW
    // ----------------------------------------------------------
    $headers = fgetcsv($handle);

    if (!$headers) {
      throw new Exception("CSV header missing");
    }

    $headers = array_map(function($h) {
      return strtolower(trim($h));
    }, $headers);

    while (($row = fgetcsv($handle)) !== false) {

      $rowNumber++;

      $csv = array_combine($headers, $row);

      if (!$csv) {
        $skippedCount++;
        continue;
      }

      // --------------------------------------------------------
      // CSV COLUMNS
      // --------------------------------------------------------

$transactionDateRaw = trim($csv['transaction_date'] ?? '');
$amount             = trim($csv['amount'] ?? '');
$cardSuffix         = trim($csv['card_suffix'] ?? '');
$transactionType    = trim($csv['transaction_type'] ?? '');
$description        = trim($csv['description'] ?? '');

$currencyCode = 'SAR';

// --------------------------------------------------------
// DATE VALIDATION
// Accept:
// YYYY-MM-DD
// DD/MM/YYYY
// D/M/YYYY
// --------------------------------------------------------
$isValidDate = false;
$dt = null;

/* YYYY-MM-DD */
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $transactionDateRaw)) {

    $dt = DateTime::createFromFormat(
        'Y-m-d',
        $transactionDateRaw
    );

    $isValidDate =
        $dt &&
        $dt->format('Y-m-d') === $transactionDateRaw;
}

/* DD/MM/YYYY OR D/M/YYYY */
elseif (
    preg_match(
        '/^\d{1,2}\/\d{1,2}\/\d{4}$/',
        $transactionDateRaw
    )
) {

    $dt = DateTime::createFromFormat(
        'j/n/Y',
        $transactionDateRaw
    );

    $isValidDate =
        $dt &&
        $dt->format('j/n/Y') === $transactionDateRaw;
}

if (!$isValidDate) {

    $errors[] = [
        'row' => $rowNumber,
        'type' => 'invalid_date',
        'message' =>
            'Transaction date must be YYYY-MM-DD or DD/MM/YYYY'
    ];

    $skippedCount++;
    continue;
}

/* Convert to DB format */
$transactionDate = $dt->format('Y-m-d');

// --------------------------------------------------------
// AMOUNT VALIDATION
// --------------------------------------------------------
if (
    !is_numeric($amount) ||
    (float)$amount <= 0
) {

    $errors[] = [
        'row' => $rowNumber,
        'type' => 'invalid_amount',
        'message' =>
            'Amount must be a positive number greater than 0.'
    ];

    $skippedCount++;
    continue;
}

$amount = (float)$amount;

// --------------------------------------------------------
// CARD SUFFIX VALIDATION
// Must be exactly 4 digits
// --------------------------------------------------------
$cardSuffix = trim($cardSuffix);

if (!preg_match('/^\d{4}$/', $cardSuffix)) {

    $errors[] = [
        'row' => $rowNumber,
        'type' => 'invalid_card_suffix',
        'message' =>
            'Card suffix must be exactly 4 digits.'
    ];

    $skippedCount++;
    continue;
}

// --------------------------------------------------------
// TRANSACTION TYPE VALIDATION
// --------------------------------------------------------
if (empty($transactionType)) {

    $errors[] = [
        'row' => $rowNumber,
        'type' => 'invalid_transaction_type',
        'message' =>
            'Transaction type cannot be empty.'
    ];

    $skippedCount++;
    continue;
}

// --------------------------------------------------------
// DESCRIPTION VALIDATION
// --------------------------------------------------------
if (empty($description)) {

    $errors[] = [
        'row' => $rowNumber,
        'type' => 'missing_description',
        'message' =>
            'Description cannot be empty.'
    ];

    $skippedCount++;
    continue;
}

if (mb_strlen($description) > 255) {

    $errors[] = [
        'row' => $rowNumber,
        'type' => 'description_too_long',
        'message' =>
            'Description cannot exceed 255 characters.'
    ];

    $skippedCount++;
    continue;
}
      // --------------------------------------------------------
      // FIND CARD
      // --------------------------------------------------------
      $stmtCard = $conn->prepare("
          SELECT card_id, user_id, card_status
          FROM employee_cards
          WHERE card_suffix = ?
          LIMIT 1
      ");

      $stmtCard->bind_param("s", $cardSuffix);
      $stmtCard->execute();
      $card = $stmtCard->get_result()->fetch_assoc();
      $stmtCard->close();

      if (!$card) {
        $errors[] = [
          'row' => $rowNumber,
          'type' => 'missing_card',
          'message' => "Card ending {$cardSuffix} not found."
        ];
        $skippedCount++;
        continue;
      }

      if ($card['card_status'] !== 'ACTIVE') {
        $errors[] = [
          'row' => $rowNumber,
          'type' => 'inactive_card',
          'message' => "Card ending {$cardSuffix} is not ACTIVE"
        ];
        $skippedCount++;
        continue;
      }

      $cardId = $card['card_id'];
      $userId = $card['user_id'];

      // --------------------------------------------------------
      // FIND FUND REQUEST
      // --------------------------------------------------------
      $stmtFund = $conn->prepare("
          SELECT fund_request_id, (amount_requested - amount_spent) AS remaining_amount
          FROM fund_requests
          WHERE employee_id = ?
          AND status IN ('APPROVED', 'ACTIVE')
          ORDER BY fund_request_id DESC
          LIMIT 1
      ");

      $stmtFund->bind_param("i", $userId);
      $stmtFund->execute();
      $fund = $stmtFund->get_result()->fetch_assoc();
      $stmtFund->close();

      if (!$fund) {
        $errors[] = [
          'row' => $rowNumber,
          'type' => 'no_fund_request',
          'message' => "No APPROVED or ACTIVE fund request found"
        ];
        $skippedCount++;
        continue;
      }

      $fundRequestId = $fund['fund_request_id'];

      // --------------------------------------------------------
      // CHECK AMOUNT
      // --------------------------------------------------------
      $remainingAmount = (float)$fund['remaining_amount'];

      if ((float)$amount > $remainingAmount) {
        $errors[] = [
          'row' => $rowNumber,
          'type' => 'limit_exceeded',
          'message' => "Amount exceeds remaining balance ({$remainingAmount})"
        ];
        $skippedCount++;
        continue;
      }

      // --------------------------------------------------------
      // SET DUE DATE
      // --------------------------------------------------------
      $dueDate = date('Y-m-d', strtotime($transactionDate . ' +7 days'));

      // --------------------------------------------------------
      // ONLY CHANGE: STORE VALID ROW (NO INSERT HERE)
      // --------------------------------------------------------
      $validRows[] = [
        'cardId' => $cardId,
        'fundRequestId' => $fundRequestId,
        'transactionDate' => $transactionDate,
        'amount' => $amount,
        'transactionType' => $transactionType,
        'description' => $description,
        'dueDate' => $dueDate
      ];
    }

    fclose($handle);
  }

  // ------------------------------------------------------------
  // ❗ STOP EVERYTHING IF ANY ERRORS EXIST (NEW REQUIRED STEP)
  // ------------------------------------------------------------
  if (!empty($errors)) {

    $conn->rollback();

    echo json_encode([
      'success' => false,
      'message' => 'Import failed. Fix all errors first.',
      'errors' => $errors
    ]);

    exit;
  }

  // ------------------------------------------------------------
  // ONLY NOW START REAL INSERT TRANSACTION
  // ------------------------------------------------------------
  foreach ($validRows as $row) {

    $stmtTxn = $conn->prepare("
      INSERT IGNORE INTO transactions
      (
        csv_batch_id,
        card_id,
        fund_request_id,
        transaction_date,
        amount,
        currency_code,
        transaction_type,
        description,
        due_date,
        created_at
      )
      VALUES
      (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW()
      )
    ");

    $stmtTxn->bind_param(
      "iiisdssss",
      $csvBatchId,
      $row['cardId'],
      $row['fundRequestId'],
      $row['transactionDate'],
      $row['amount'],
      $currencyCode,
      $row['transactionType'],
      $row['description'],
      $row['dueDate']
    );

    $stmtTxn->execute();
    $stmtTxn->close();

    $conn->query("
      UPDATE fund_requests fr
      SET amount_spent = COALESCE((
          SELECT SUM(t.amount)
          FROM transactions t
          WHERE t.fund_request_id = fr.fund_request_id
        ), 0),
        remaining_amount = fr.amount_requested - COALESCE((
          SELECT SUM(t.amount)
          FROM transactions t
          WHERE t.fund_request_id = fr.fund_request_id
        ), 0)
      WHERE fr.fund_request_id = {$row['fundRequestId']}
    ");

    $importedCount++;
  }

  // ------------------------------------------------------------
  // COMMIT ONLY AFTER SUCCESS
  // ------------------------------------------------------------
  $conn->commit();

  refreshFundStatus($conn);
  sendAccountantNotifications($conn);

  echo json_encode([
    'success' => true,
    'message' => 'Transactions imported successfully',
    'csv_batch_id' => $csvBatchId,
    'imported_count' => $importedCount,
    'skipped_count' => 0,
    'errors' => []
  ]);

  exit;

} catch (Exception $e) {

  $conn->rollback();

  echo json_encode([
    'success' => false,
    'error' => $e->getMessage()
  ]);

  exit;
}
  // ------------------------------------------------------------------
// 10. FETCH NOTIFICATIONS (ACCOUNTANT)
// ------------------------------------------------------------------
case 'fetch_notifications':

  session_start();

  $userId = $_SESSION['user_id'] ?? null;

  if (!$userId) {
    echo json_encode([
      'success' => false,
      'message' => 'Not logged in'
    ]);
    exit;
  }

  $stmt = $conn->prepare("
    SELECT 
      notification_id,
      type,
      message,
      is_read,
      created_at
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 20
  ");

  $stmt->bind_param("i", $userId);
  $stmt->execute();

  $result = $stmt->get_result();

  $rows = [];

  while ($r = $result->fetch_assoc()) {
    $rows[] = $r;
  }

  $stmt->close();

  echo json_encode($rows);
  exit;
  
  
  //------------
  
 case 'mark_all_read':

  session_start();

  $userId = $_SESSION['user_id'] ?? null;

  if (!$userId) {
    echo json_encode(['success' => false]);
    exit;
  }

  $stmt = $conn->prepare("
    UPDATE notifications
    SET is_read = 1
    WHERE user_id = ?
  ");

  $stmt->bind_param("i", $userId);
  $stmt->execute();
  $stmt->close();

  echo json_encode(['success' => true]);
  exit;
  
  
  
  // ------------------------------------------------------------------
// MARK SINGLE NOTIFICATION READ
// ------------------------------------------------------------------
case 'mark_notification_read':

  session_start();

  $userId = $_SESSION['user_id'] ?? null;

  if (!$userId) {

    echo json_encode([
      'success' => false
    ]);

    exit;
  }

  $data = json_decode(
    file_get_contents("php://input"),
    true
  );

  $notificationId = intval(
    $data['notification_id'] ?? 0
  );

  if ($notificationId <= 0) {

    echo json_encode([
      'success' => false
    ]);

    exit;
  }

  $stmt = $conn->prepare("
    UPDATE notifications
    SET is_read = 1
    WHERE notification_id = ?
      AND user_id = ?
  ");

  $stmt->bind_param(
    "ii",
    $notificationId,
    $userId
  );

  $stmt->execute();

  $stmt->close();

  echo json_encode([
    'success' => true
  ]);

  exit;
  
// ------------------------------------------------------------------
// CLEAR ALL NOTIFICATION READ
// ------------------------------------------------------------------
  case 'clear_all_notifs':

  session_start();

  $userId = $_SESSION['user_id'] ?? null;

  if (!$userId) {
    echo json_encode([
      'success' => false,
      'message' => 'Not logged in'
    ]);
    exit;
  }

  $stmt = $conn->prepare("
    DELETE FROM notifications
    WHERE user_id = ?
  ");

  $stmt->bind_param("i", $userId);
  $stmt->execute();
  $stmt->close();

  echo json_encode([
    'success' => true
  ]);

  exit;
  

  
  // ------------------------------------------------------------------
  // DEFAULT
  // ------------------------------------------------------------------
  default:

    echo json_encode([
      'error' => 'Unknown action'
    ]);

    exit;
}

$conn->close();

  