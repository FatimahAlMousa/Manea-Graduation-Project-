<?php
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$currentUser = require_employee($pdo);
$currentUser['employee_code'] = employee_code((int)$currentUser['user_id']);
$currentUser['position_title'] = $currentUser['department'] ? $currentUser['department'] . ' Employee' : 'Employee';
$currentUser['avatar_initials'] = initials($currentUser['full_name']);

$requestStmt = $pdo->prepare("\n    SELECT fr.*,\n           EXISTS (SELECT 1 FROM flags f WHERE f.fund_request_id = fr.fund_request_id AND f.status = 'OPEN') AS has_open_flags\n    FROM fund_requests fr\n    WHERE fr.employee_id = ?\n    ORDER BY\n      CASE WHEN fr.status IN ('PENDING','APPROVED','ACTIVE','READY_TO_CLOSE') THEN 0 ELSE 1 END,\n      fr.created_at DESC,\n      fr.fund_request_id DESC\n");
$requestStmt->execute([$currentUser['user_id']]);
$requestsDb = $requestStmt->fetchAll();

$requestsForJs = [];
foreach ($requestsDb as $request) {
    $txnStmt = $pdo->prepare("\n        SELECT t.*,\n               inv.invoice_id, inv.invoice_number, inv.invoice_date, inv.invoice_amount,\n               inv.file_path AS invoice_file, inv.uploaded_at AS invoice_uploaded_at,\n               inv.verification_status AS invoice_verification_status,\n               f.flag_id, f.flag_reason, f.details AS flag_details, f.status AS flag_status\n        FROM transactions t\n        LEFT JOIN invoice_transactions it ON it.id = (\n            SELECT id FROM invoice_transactions\n            WHERE transaction_id = t.transaction_id\n            ORDER BY id DESC LIMIT 1\n        )\n        LEFT JOIN invoices inv ON inv.invoice_id = it.invoice_id\n        LEFT JOIN flags f ON f.flag_id = (\n            SELECT flag_id FROM flags\n            WHERE transaction_id = t.transaction_id AND status = 'OPEN'\n            ORDER BY FIELD(flag_reason,'DUPLICATE_INVOICE','AI_AMOUNT_MISMATCH','OVERDUE_TRANSACTION'), flag_id DESC LIMIT 1\n        )\n        WHERE t.fund_request_id = ?\n        ORDER BY t.transaction_date DESC, t.transaction_id DESC\n    ");
    $txnStmt->execute([$request['fund_request_id']]);
    $txnsDb = $txnStmt->fetchAll();

    $transactions = [];
    $spentAmount = 0;
    foreach ($txnsDb as $txn) {
        $spentAmount += (float)$txn['amount'];

        $flagStatus = flag_reason_to_invoice_status($txn['flag_reason'] ?? null);
        if ($flagStatus) {
            $invoiceStatus = $flagStatus;
        } elseif (!empty($txn['invoice_id'])) {
            $invoiceStatus = 'Uploaded';
        } elseif (in_array($txn['verification_status'] ?? '', ['MATCHED','FLAGGED'])) {
            $invoiceStatus = 'Uploaded';
        } else {
            // Auto-detect overdue: if due_date has passed and no invoice uploaded
            $dueDate = $txn['due_date'] ?? null;
            $txnDate = $txn['transaction_date'] ?? null;
            $due = $dueDate ? strtotime($dueDate) : ($txnDate ? strtotime($txnDate . ' +7 days') : null);
            if ($due && $due < time()) {
                $invoiceStatus = 'Overdue';
            } else {
                $invoiceStatus = 'Not Uploaded';
            }
        }

        $invoiceDueText = invoice_due_text($txn['transaction_date'] ?? null, $invoiceStatus, $txn['due_date'] ?? null);

        $transactions[] = [
            'id' => 'TXN-' . str_pad((string)$txn['transaction_id'], 4, '0', STR_PAD_LEFT),
            'dbTxnId' => (int)$txn['transaction_id'],
            'date' => $txn['transaction_date'] ?? '',
            'vendor' => $txn['description'] ?: '—',
            'amount' => (float)($txn['amount'] ?? 0),
            'invoiceStatus' => $invoiceStatus,
            'invoiceDueText' => $invoiceDueText,
            'invoiceFile' => $txn['invoice_file'] ?? '',
            'invoiceUploadedAt' => $txn['invoice_uploaded_at'] ?? '',
            'verificationStatus' => $txn['invoice_verification_status'] ?? '',
            'flagReason' => $txn['flag_reason'] ?? '',
            'flagDetails' => $txn['flag_details'] ?? ''
        ];
    }

    $displayStatus = map_request_status($request['status'], (bool)$request['has_open_flags']);
    $requestsForJs[] = [
        'id' => 'REQ-' . str_pad((string)$request['fund_request_id'], 3, '0', STR_PAD_LEFT),
        'dbId' => (int)$request['fund_request_id'],
        'project' => $request['request_title'] ?? '',
        'requester' => $currentUser['full_name'] ?? '',
        'employeeId' => $currentUser['employee_code'],
        'status' => $displayStatus,
        'requestDate' => substr((string)($request['created_at'] ?? ''), 0, 10),
        'dueDate' => $request['project_due_date'] ?? '',
        'amount' => format_sar($request['amount_requested'] ?? 0),
        'amountNumber' => (float)($request['amount_requested'] ?? 0),
        'category' => $request['request_type'] ?? '',
        'purpose' => $request['purpose'] ?? '',
        'description' => $request['description'] ?? '',
        'priority' => ucfirst(strtolower($request['priority'] ?? 'MEDIUM')),
        'invoiceStatus' => $displayStatus,
        'spentAmount' => $spentAmount,
        'transactions' => $transactions
    ];
}

$notificationStmt = $pdo->prepare("\n    SELECT notification_id, type, message, is_read, created_at\n    FROM notifications\n    WHERE user_id = ?\n    ORDER BY created_at DESC, notification_id DESC\n    LIMIT 30\n");
$notificationStmt->execute([$currentUser['user_id']]);
$notificationsDb = $notificationStmt->fetchAll();

$notificationsForJs = [];
foreach ($notificationsDb as $notification) {
    $message = (string)($notification['message'] ?? '');
    $dbType = (string)($notification['type'] ?? 'REQUEST_APPROVED');
    $uiType = match ($dbType) {
        'FLAGGED_TRANSACTION' => 'flagged',
        'ACCOUNT_CLEARED' => 'cleared',
        'REQUEST_REJECTED' => 'rejected',
        default => 'approved',
    };
    if (stripos($message, 'submitted successfully') !== false || stripos($message, 'sent for review') !== false) {
        $uiType = 'submitted';
    } elseif (stripos($message, 'invoice uploaded') !== false || stripos($message, 'sent for verification') !== false) {
        $uiType = 'submitted';
    }

    $createdAt = new DateTime((string)$notification['created_at']);
    $today = new DateTime('today');
    $createdDay = new DateTime($createdAt->format('Y-m-d'));
    $dateLabel = ($createdDay == $today) ? 'Today' : $createdAt->format('Y-m-d');

    $notificationsForJs[] = [
        'id' => (int)$notification['notification_id'],
        'type' => $uiType,
        'msg' => $message,
        'time' => $createdAt->format('H:i'),
        'dateLabel' => $dateLabel,
        'read' => ((int)$notification['is_read'] === 1),
    ];
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manea — Employee Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --teal:       #0097B2;
      --teal-dim:   rgba(0,151,178,0.12);
      --teal-mid:   rgba(0,151,178,0.22);
      --navy:       #1F2247;
      --navy-faint: rgba(31,34,71,0.06);
      --navy-dim:   rgba(31,34,71,0.45);
      --ivory:      #F1F0EC;
      --green:      #059669;
      --green-dim:  rgba(5,150,105,0.10);
      --red:        #DC2626;
      --red-dim:    rgba(220,38,38,0.10);
      --amber:      #D97706;
      --amber-dim:  rgba(217,119,6,0.10);
      --purple:     #7C3AED;
      --purple-dim: rgba(124,58,237,0.10);
      --sidebar-w:  260px;
      --sidebar-col:66px;
    }
    html, body { height:100%; background:var(--ivory); font-family:'DM Sans',sans-serif; color:var(--navy); overflow:hidden; }
    .app { display:flex; height:100vh; overflow:hidden; }

    /* ── Sidebar ── */
    .sidebar { width:var(--sidebar-w); background:var(--navy); display:flex; flex-direction:column; transition:width .25s cubic-bezier(.4,0,.2,1); flex-shrink:0; overflow:hidden; z-index:30; }
    .sidebar.collapsed { width:var(--sidebar-col); }
    .sb-head { display:flex; align-items:center; justify-content:space-between; padding:18px 14px; border-bottom:1px solid rgba(255,255,255,.07); min-height:76px; gap:8px; }
    .sidebar.collapsed .sb-head { justify-content:center; }
    .sb-wordmark-wrap { flex:1; display:flex; align-items:center; justify-content:center; }
    .sb-wordmark-svg { width:120px; height:auto; display:block; }
    .sidebar.collapsed .sb-wordmark-wrap { display:none; }
    .sb-toggle { width:30px; height:30px; border-radius:7px; background:rgba(255,255,255,.08); border:none; color:rgba(255,255,255,.55); cursor:pointer; display:flex; align-items:center; justify-content:center; transition:background .2s; flex-shrink:0; }
    .sb-toggle:hover { background:rgba(255,255,255,.15); }
    .sb-role { margin:12px 14px 4px; font-size:10px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; color:var(--teal); background:rgba(0,151,178,.12); padding:4px 10px; border-radius:6px; display:inline-block; transition:opacity .2s; }
    .sidebar.collapsed .sb-role { opacity:0; pointer-events:none; }
    .sb-nav { flex:1; padding:8px 10px; display:flex; flex-direction:column; gap:2px; overflow-y:auto; }
    .nav-item { display:flex; align-items:center; gap:11px; padding:10px 12px; border-radius:10px; color:rgba(255,255,255,.45); border:1px solid transparent; cursor:pointer; transition:all .17s; font-size:13.5px; font-weight:400; white-space:nowrap; background:none; width:100%; text-align:left; font-family:'DM Sans',sans-serif; }
    .nav-item:hover { color:rgba(255,255,255,.8); background:rgba(255,255,255,.07); }
    .nav-item.active { color:#fff; background:rgba(0,151,178,.18); border-color:rgba(0,151,178,.32); font-weight:600; }
    .nav-icon { flex-shrink:0; width:18px; height:18px; display:flex; align-items:center; justify-content:center; }
    .nav-label { flex:1; }
    .sidebar.collapsed .nav-label,.sidebar.collapsed .nav-badge { display:none; }
    .sidebar.collapsed .nav-item { justify-content:center; padding:11px 0; }
    .nav-badge { font-size:10.5px; font-weight:700; background:var(--teal); color:#fff; border-radius:20px; padding:1px 7px; min-width:20px; text-align:center; }

    /* ── Main ── */
    .main { flex:1; display:flex; flex-direction:column; overflow:hidden; }
    .topbar { height:64px; background:rgba(255,255,255,.88); backdrop-filter:blur(14px); border-bottom:1px solid rgba(31,34,71,.07); display:flex; align-items:center; justify-content:space-between; padding:0 28px; flex-shrink:0; gap:16px; }
    .page-title { font-family:'DM Serif Display',serif; font-size:20px; font-weight:400; color:var(--navy); letter-spacing:-.015em; }
    .topbar-right { display:flex; align-items:center; gap:10px; position:relative; }
    .icon-btn { width:36px; height:36px; border-radius:10px; background:var(--navy-faint); border:1px solid rgba(31,34,71,.08); display:flex; align-items:center; justify-content:center; color:var(--navy-dim); cursor:pointer; transition:all .2s; position:relative; }
    .icon-btn:hover { background:var(--teal-dim); color:var(--teal); }
    .notif-dot { position:absolute; top:7px; right:7px; width:7px; height:7px; border-radius:50%; background:var(--red); border:2px solid #fff; }
    .user-pill { display:flex; align-items:center; gap:9px; padding:5px 14px 5px 6px; background:var(--navy-faint); border-radius:100px; border:1px solid rgba(31,34,71,.08); }
    .avatar { width:28px; height:28px; border-radius:50%; background:var(--teal); display:flex; align-items:center; justify-content:center; color:#fff; font-size:11px; font-weight:700; }
    .user-name { font-size:13px; font-weight:500; color:var(--navy); }
    .logout-btn { display:flex; align-items:center; gap:7px; font-size:13px; font-weight:500; color:var(--navy-dim); background:transparent; border:1.5px solid rgba(31,34,71,.10); border-radius:100px; padding:7px 14px; cursor:pointer; transition:all .2s; font-family:'DM Sans',sans-serif; }
    .logout-btn:hover { color:var(--red); border-color:rgba(220,38,38,.25); }

    /* ── Content / Views ── */
    .content { flex:1; overflow-y:auto; padding:28px; }
    .view { display:none; }
    .view.active { display:block; animation:fadeUp .35s ease; }
    @keyframes fadeUp { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }

    /* ── Page intro ── */
    .page-intro { margin-bottom:18px; }
    .page-intro h2 { font-family:'DM Serif Display',serif; font-size:28px; font-weight:400; color:var(--navy); letter-spacing:-.02em; }
    .page-intro p { margin-top:7px; color:var(--navy-dim); font-size:14px; }

    /* ── Stats ── */
    .stats-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:16px; margin-bottom:18px; }
    .stats-grid.overview-grid { grid-template-columns:repeat(2,minmax(0,1fr)); }
    .overview-table-wrap { margin-top:18px; }
    .header-row-between { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:18px; }
    .header-actions { display:flex; align-items:center; gap:10px; margin-left:auto; }
    .btn-pill-round { border-radius:999px !important; padding:9px 18px !important; }
    .panel-flat-header { padding-top:20px; }
    .compact-panel { max-width:720px; margin:0 auto; }
    .compact-state { max-width:640px; padding:54px 32px; }
    .submit-disabled { background:rgba(31,34,71,.08) !important; color:rgba(31,34,71,.35) !important; border-color:rgba(31,34,71,.08) !important; box-shadow:none !important; cursor:not-allowed !important; }
    .field-error { display:none; align-items:center; gap:5px; font-size:12px; font-weight:500; color:#c94040; margin-top:4px; }
    .field-error.visible { display:flex; }
    .field-error svg { width:13px; height:13px; flex-shrink:0; stroke:#c94040; fill:none; stroke-width:2.2; stroke-linecap:round; stroke-linejoin:round; }
    .input.input-error, .textarea.input-error { border-color:#e05252; background:rgba(224,82,82,0.05); box-shadow:0 0 0 3.5px rgba(224,82,82,0.10); }
    @keyframes shake { 0%,100%{transform:translateX(0)} 20%,60%{transform:translateX(-5px)} 40%,80%{transform:translateX(5px)} }
    .btn-upload { display:inline-flex; align-items:center; gap:5px; padding:5px 11px; border-radius:7px; font-size:11.5px; font-weight:600; cursor:pointer; border:1.5px solid rgba(0,151,178,.22); background:var(--teal-dim); color:var(--teal); font-family:'DM Sans',sans-serif; transition:all .15s; }
    .btn-upload:hover:not(:disabled) { background:var(--teal); color:#fff; }
    .btn-upload.submit-disabled, .btn-upload:disabled { background:rgba(31,34,71,.08) !important; color:rgba(31,34,71,.30) !important; border-color:rgba(31,34,71,.08) !important; cursor:not-allowed !important; }
    .invoice-processing { display:inline-flex; align-items:center; gap:6px; font-size:11.5px; font-weight:600; color:var(--amber); background:var(--amber-dim); padding:4px 10px; border-radius:6px; }
    .invoice-processing-dot { width:6px; height:6px; border-radius:50%; background:var(--amber); display:inline-block; animation:ivpulse 1.4s ease infinite; }
    @keyframes ivpulse { 0%,100%{opacity:1} 50%{opacity:.3} }
    .inline-action-group { display:flex; gap:10px; align-items:center; }

    .stat-card { background:rgba(255,255,255,.88); backdrop-filter:blur(10px); border:1.5px solid rgba(31,34,71,.08); border-radius:16px; padding:20px 22px; display:flex; flex-direction:column; gap:10px; transition:transform .2s,box-shadow .2s; animation:fadeUp .4s ease both; }
    .stat-card:hover { transform:translateY(-2px); box-shadow:0 10px 30px rgba(31,34,71,.09); }
    .stat-label { font-size:11.5px; font-weight:600; color:var(--navy-dim); letter-spacing:.04em; text-transform:uppercase; }
    .stat-value { font-family:'DM Serif Display',serif; font-size:32px; font-weight:400; line-height:1; color:var(--navy); letter-spacing:-.02em; }
    .stat-value.teal { color:var(--teal); }
    .stat-value.green { color:var(--green); }
    .stat-value.red { color:var(--red); }
    .stat-value.amber { color:var(--amber); }
    .stat-value.navy { color:var(--navy); }
    .overview-card-icon { width:38px; height:38px; border-radius:10px; display:flex; align-items:center; justify-content:center; }
    .overview-card-icon.teal { background:var(--teal-dim); color:var(--teal); }
    .overview-card-icon.green { background:var(--green-dim); color:var(--green); }
    .overview-card-icon.red { background:var(--red-dim); color:var(--red); }
    .overview-card-icon.amber { background:var(--amber-dim); color:var(--amber); }
    .overview-card-icon.navy { background:var(--navy-faint); color:var(--navy); }
    .overview-status-wrap { margin-top:2px; }
    .overview-status-text { font-family:'DM Serif Display',serif; font-size:32px; font-weight:400; line-height:1.05; letter-spacing:-.02em; color:var(--navy); }
    .overview-status-text.green { color:var(--green); }
    .overview-status-text.amber { color:var(--amber); }
    .overview-status-text.red { color:var(--red); }
    .overview-status-text.navy { color:var(--navy); }
    .overview-status-text.teal { color:var(--teal); }
    .funds-meta { display:flex; align-items:center; justify-content:space-between; gap:12px; margin-top:2px; }
    .funds-note { font-size:12px; color:var(--navy-dim); }
    .funds-progress { margin-top:12px; width:100%; height:8px; border-radius:999px; background:rgba(31,34,71,.08); overflow:hidden; }
    .funds-progress-bar { height:100%; width:0; border-radius:999px; background:var(--teal); transition:width .25s ease; }

    .overview-bottom-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:16px; margin-bottom:20px; }
    .activity-list { padding:18px 22px 22px; display:flex; flex-direction:column; gap:14px; }
    .activity-item { display:grid; grid-template-columns:46px 1fr auto; gap:14px; align-items:start; }
    .activity-dot { width:46px; height:46px; border-radius:14px; background:var(--teal-dim); color:var(--teal); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .activity-main { min-width:0; padding-top:2px; }
    .activity-title { font-size:14px; font-weight:700; color:var(--navy); line-height:1.35; margin-bottom:3px; }
    .activity-sub { font-size:13px; color:var(--navy-dim); line-height:1.55; }
    .activity-time { font-size:11px; color:rgba(31,34,71,.42); font-family:'IBM Plex Mono',monospace; white-space:nowrap; padding-top:4px; }
    .next-action-box { padding:22px; display:flex; flex-direction:column; gap:16px; }
    .next-action-card { display:flex; flex-direction:column; gap:16px; padding:18px; border:1.5px solid rgba(31,34,71,.08); border-radius:16px; background:rgba(31,34,71,.02); }
    .next-action-head { display:flex; align-items:flex-start; gap:14px; }
    .next-action-icon { width:46px; height:46px; border-radius:14px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .next-action-icon.teal { background:var(--teal-dim); color:var(--teal); }
    .next-action-icon.green { background:var(--green-dim); color:var(--green); }
    .next-action-icon.red { background:var(--red-dim); color:var(--red); }
    .next-action-icon.amber { background:var(--amber-dim); color:var(--amber); }
    .next-action-icon.navy { background:var(--navy-faint); color:var(--navy); }
    .next-action-copy { min-width:0; }
    .next-action-title { font-family:'DM Serif Display',serif; font-size:22px; font-weight:400; color:var(--navy); line-height:1.15; margin-bottom:6px; }
    .next-action-text { font-size:14px; color:var(--navy-dim); line-height:1.65; }
    .next-action-meta { display:flex; flex-wrap:wrap; gap:8px; }
    @media(max-width:980px){ .overview-bottom-grid { grid-template-columns:1fr; } .activity-item { grid-template-columns:46px 1fr; } .activity-time { grid-column:2; padding-top:0; } }

    /* ── Panel ── */
    .panel { background:rgba(255,255,255,.88); backdrop-filter:blur(10px); border:1.5px solid rgba(31,34,71,.08); border-radius:16px; overflow:hidden; margin-bottom:20px; }
    .panel-header { padding:18px 22px 14px; border-bottom:1px solid rgba(31,34,71,.06); display:flex; align-items:center; justify-content:space-between; gap:12px; }
    .panel-title { font-family:'DM Serif Display',serif; font-size:18px; font-weight:400; color:var(--navy); }
    .panel-sub { font-size:13px; color:var(--navy-dim); margin-top:2px; }
    .panel-body { padding:22px; }
    .action-area { padding:22px; }

    /* ── Toolbar / Search ── */
    .toolbar { display:flex; gap:12px; align-items:center; padding:14px 22px; border-bottom:1px solid rgba(31,34,71,.05); flex-wrap:wrap; }
    .search-box,.date-box { display:flex; align-items:center; gap:8px; padding:10px 14px; background:var(--navy-faint); border:1.5px solid rgba(31,34,71,.08); border-radius:10px; color:var(--navy-dim); }
    .search-box { flex:1; min-width:280px; }
    .date-box { min-width:180px; justify-content:flex-start; }
    .search-box input,.date-box select { border:none; background:transparent; font-family:'DM Sans',sans-serif; font-size:13px; color:var(--navy); outline:none; width:100%; }
    .date-box select { cursor:pointer; }
    .search-box input::placeholder { color:rgba(31,34,71,.3); }

    /* ── Tabs ── */
    .tabs { display:flex; gap:28px; padding:0 22px; border-bottom:1px solid rgba(31,34,71,.06); }
    .tab-btn { position:relative; padding:14px 0; background:none; border:none; color:var(--navy-dim); cursor:pointer; font-size:14px; font-weight:500; font-family:'DM Sans',sans-serif; }
    .tab-btn.active { color:var(--teal); font-weight:700; }
    .tab-btn.active::after { content:''; position:absolute; left:0; right:0; bottom:-1px; height:2px; background:var(--teal); border-radius:10px; }

    /* ── Table ── */
    .tbl-head,.tbl-row { display:grid; align-items:center; }
    .tbl-head { padding:12px 22px; border-bottom:1px solid rgba(31,34,71,.06); background:rgba(31,34,71,.02); }
    .tbl-row { padding:16px 22px; border-bottom:1px solid rgba(31,34,71,.045); transition:background .13s; }
    .tbl-row:last-child { border-bottom:none; }
    .tbl-row:hover { background:rgba(0,151,178,.03); }
    .th { font-size:10.5px; font-weight:700; color:rgba(31,34,71,.38); text-transform:uppercase; letter-spacing:.07em; }
    .cell { font-size:13.5px; color:var(--navy); overflow:hidden; text-overflow:ellipsis; }
    .cell.mono { font-family:'IBM Plex Mono',monospace; font-size:12px; font-weight:600; color:var(--teal); }
    .cell.muted { color:var(--navy-dim); }

    /* ── Badges ── */
    .badge { display:inline-flex; align-items:center; gap:5px; padding:3px 10px; border-radius:6px; font-size:11.5px; font-weight:600; white-space:nowrap; }
    .badge-amber { background:var(--amber-dim); color:var(--amber); }
    .badge-green { background:var(--green-dim); color:var(--green); }
    .badge-red { background:var(--red-dim); color:var(--red); }
    .badge-teal { background:var(--teal-dim); color:var(--teal); }
    .badge-navy { background:var(--navy-faint); color:var(--navy); }
    .badge-purple { background:var(--purple-dim); color:var(--purple); }
    .badge-dot { width:5px; height:5px; border-radius:50%; background:currentColor; display:inline-block; }
    .btn-review { background:var(--teal-dim); color:var(--teal); border-color:rgba(0,151,178,.18); }
    .btn-review:hover { background:var(--teal); color:#fff; }

    /* ── Buttons ── */
    .btn { display:inline-flex; align-items:center; justify-content:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:12px; font-weight:600; cursor:pointer; border:1px solid transparent; transition:all .15s; font-family:'DM Sans',sans-serif; white-space:nowrap; }
    .btn-primary { background:var(--navy); color:#fff; }
    .btn-primary:hover { background:var(--teal); box-shadow:0 6px 18px rgba(0,151,178,.25); }
    .btn-secondary { background:var(--teal-dim); color:var(--teal); border-color:rgba(0,151,178,.2); }
    .btn-secondary:hover { background:var(--teal); color:#fff; }
    .btn-ghost { background:transparent; color:var(--navy-dim); border:1.5px solid rgba(31,34,71,.12); }
    .btn-ghost:hover { color:var(--teal); border-color:rgba(0,151,178,.3); }
    .btn-danger-soft { background:rgba(31,34,71,.08); color:rgba(31,34,71,.25); border-color:rgba(31,34,71,.08); }
    .btn-danger-soft.enabled { background:rgba(220,38,38,.08); color:var(--red); border-color:rgba(220,38,38,.18); }

    /* ── Form ── */
    .form-wrap { padding:22px; }
    .form-grid { display:grid; grid-template-columns:160px 1fr; gap:18px 16px; }
    .form-label { font-size:13px; font-weight:600; color:var(--navy-dim); align-self:start; padding-top:12px; }
    .input,.textarea,.select { width:100%; border:1.5px solid rgba(31,34,71,.08); border-radius:10px; padding:12px 14px; background:#fff; color:var(--navy); font-family:'DM Sans',sans-serif; font-size:14px; outline:none; }
    .textarea { min-height:80px; resize:vertical; }
    .input:focus,.textarea:focus,.select:focus,.action-note:focus { border-color:rgba(0,151,178,.42); box-shadow:0 0 0 4px rgba(0,151,178,.08); }
    .priority-group { display:flex; gap:30px; align-items:center; flex-wrap:wrap; padding-top:14px; }
    .radio-item { display:flex; align-items:center; gap:8px; color:var(--navy); font-size:14px; }
    .radio-item input { accent-color:var(--teal); }
    .form-actions { display:flex; justify-content:flex-end; gap:12px; margin-top:22px; }

    /* ── Action stack (flagged reupload) ── */
    .action-stack { display:flex; flex-direction:column; gap:8px; align-items:flex-start; }
    .action-note { width:100%; min-height:64px; resize:vertical; border:1.5px solid rgba(31,34,71,.08); border-radius:10px; padding:12px; font-family:'DM Sans',sans-serif; font-size:13px; color:var(--navy); background:#fff; outline:none; }
    .action-note::placeholder { color:rgba(31,34,71,.35); }
    .hidden-input { display:none; }
    .upload-label { display:inline-flex; align-items:center; gap:6px; color:var(--teal); font-size:12.5px; font-weight:600; cursor:pointer; }
    .upload-label:hover { text-decoration:underline; }
    .mini-file { font-size:12px; color:var(--navy-dim); }
    .flag-reason-badge { white-space:normal; line-height:1.25; max-width:100%; }

    /* ── Flagged detail view extras ── */
    .checklist { display:flex; gap:18px; flex-wrap:wrap; padding:0 22px 22px; color:var(--navy); font-size:14px; }
    .checklist label { display:flex; align-items:center; gap:8px; cursor:pointer; }
    .checklist input { accent-color:var(--teal); }

    /* ── Request detail / Expense tracking ── */
    .detail-grid { display:grid; grid-template-columns:200px 1fr; gap:20px; margin:0; padding:22px; }
    .detail-label { font-size:13px; font-weight:600; color:var(--navy-dim); align-self:start; }
    .detail-value { font-size:14px; line-height:1.7; color:var(--navy); }
    .detail-value strong { font-weight:700; }
    .section-space { margin-top:20px; }
    .summary-row { display:flex; align-items:center; gap:20px; flex-wrap:wrap; padding:22px 22px 0; }
    .summary-pill { display:inline-flex; align-items:center; justify-content:center; padding:14px 22px; border-radius:999px; font-size:16px; font-weight:700; background:var(--teal-dim); color:var(--teal); }
    .summary-meta { font-size:13px; color:var(--navy-dim); line-height:1.7; }

    /* ── Blocked page ── */
    .center-state { background:#fff; padding:80px 40px; text-align:center; border-radius:24px; box-shadow:0 4px 20px rgba(31,34,71,.05); max-width:900px; margin:40px auto; }
    .state-icon { font-size:80px; margin-bottom:24px; display:block; }
    .state-title { font-family:'DM Serif Display',serif; font-size:42px; font-weight:400; color:var(--navy); margin-bottom:16px; }
    .state-sub { max-width:600px; margin:0 auto 32px; color:#8a8b9a; font-size:16px; line-height:1.6; }

    /* ── Toast ── */
    .toast { position:fixed; bottom:28px; left:50%; transform:translateX(-50%) translateY(20px); background:var(--navy); color:#fff; padding:12px 22px; border-radius:10px; font-size:13.5px; font-weight:500; box-shadow:0 8px 24px rgba(31,34,71,.25); opacity:0; transition:opacity .3s,transform .3s; z-index:300; pointer-events:none; }
    .toast.show { opacity:1; transform:translateX(-50%) translateY(0); }
    .empty { padding:48px; text-align:center; color:var(--navy-dim); font-size:14px; }

    /* ── Logout modal ── */
    .logout-modal-overlay {
      display:none;
      position:fixed;
      inset:0;
      z-index:20000;
      background:rgba(31,34,71,.50);
      backdrop-filter:blur(4px);
      align-items:center;
      justify-content:center;
      padding:24px;
    }
    .logout-modal-overlay.open {
      display:flex;
      animation:fadeIn .18s ease;
    }
    .logout-modal {
      background:#fff;
      border-radius:18px;
      width:100%;
      max-width:440px;
      overflow:hidden;
      box-shadow:0 28px 70px rgba(31,34,71,.22);
      animation:slideUp .22s cubic-bezier(.22,1,.36,1);
      text-align:center;
      padding:0 0 22px;
    }
    .logout-modal-icon-wrap {
      width:56px;
      height:56px;
      border-radius:50%;
      display:flex;
      align-items:center;
      justify-content:center;
      background:rgba(31,34,71,.06);
      color:var(--navy);
      margin:32px auto 16px;
    }
    .logout-modal h3 {
      font-family:'DM Serif Display',serif;
      font-size:19px;
      font-weight:400;
      color:var(--navy);
      text-align:center;
      padding:0 24px 8px;
      line-height:1.3;
      margin:0;
      letter-spacing:0;
    }
    .logout-modal p {
      font-size:13px;
      color:var(--navy-dim);
      text-align:center;
      padding:0 28px 24px;
      line-height:1.6;
      margin:0;
    }
    .logout-modal-actions {
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:10px;
      padding:0 20px;
    }
    .logout-modal-btn {
      padding:13px 20px;
      border-radius:10px;
      font-family:'DM Sans',sans-serif;
      font-size:14px;
      font-weight:600;
      cursor:pointer;
      border:none;
      transition:all .15s;
      min-height:auto;
      width:100%;
    }
    .logout-modal-btn.primary {background:var(--navy);color:#fff;border:0;}
    .logout-modal-btn.primary:hover {background:#14173a; box-shadow:none; transform:none;}
    .logout-modal-btn.secondary {background:rgba(31,34,71,.07);color:var(--navy);border:1.5px solid rgba(31,34,71,.12);}
    .logout-modal-btn.secondary:hover {background:rgba(31,34,71,.12);}

    /* ── Confirm modal ── */
    .modal { position:fixed; inset:0; background:rgba(31,34,71,.18); backdrop-filter:blur(7px); -webkit-backdrop-filter:blur(7px); display:none; align-items:center; justify-content:center; z-index:500; padding:24px; }
    .modal.open { display:flex; }
    .modal-box { width:min(820px,100%); background:rgba(255,255,255,.96); border:1px solid rgba(255,255,255,.55); border-radius:30px; box-shadow:0 30px 80px rgba(31,34,71,.28); padding:34px 34px 40px; text-align:center; }
    .modal-box h3 { font-family:'DM Serif Display',serif; font-size:34px; font-weight:400; color:var(--navy); letter-spacing:-.02em; margin-bottom:12px; }
    .modal-box p { font-size:18px; color:rgba(31,34,71,.42); margin-bottom:28px; }
    .modal-actions { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
    .modal-btn { min-height:78px; border-radius:18px; font-family:'DM Sans',sans-serif; font-size:20px; font-weight:700; cursor:pointer; transition:all .18s; border:1px solid transparent; }
    .modal-btn.primary { background:var(--navy); color:#fff; border-color:var(--navy); }
    .modal-btn.primary:hover { transform:translateY(-1px); box-shadow:0 12px 28px rgba(31,34,71,.18); }
    .modal-btn.secondary { background:#fff; color:var(--navy); border:1.5px solid rgba(31,34,71,.12); }
    .modal-btn.secondary:hover { background:rgba(31,34,71,.03); }

    /* ── Review modal (details only) ── */
    .review-modal-overlay { position:fixed; inset:0; background:rgba(31,34,71,.18); backdrop-filter:blur(7px); display:none; align-items:center; justify-content:center; z-index:500; padding:24px; }
    .review-modal-overlay.open { display:flex; }
    .review-modal { width:min(520px,100%); background:#fff; border-radius:24px; box-shadow:0 30px 80px rgba(31,34,71,.22); padding:30px; }
    .review-modal-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:22px; }
    .review-modal-title { font-family:'DM Serif Display',serif; font-size:20px; font-weight:400; color:var(--navy); }
    .review-modal-close { width:30px; height:30px; border-radius:8px; background:var(--navy-faint); border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; color:var(--navy-dim); font-size:16px; }
    .review-modal-close:hover { background:var(--red-dim); color:var(--red); }
    .review-detail-grid { display:grid; grid-template-columns:140px 1fr; gap:14px 12px; margin-bottom:24px; }
    .review-label { font-size:12.5px; font-weight:600; color:var(--navy-dim); align-self:center; }
    .review-value { font-size:14px; color:var(--navy); line-height:1.5; }
    .review-divider { border:none; border-top:1px solid rgba(31,34,71,.07); margin:0 0 20px; }
    .review-modal-actions { display:flex; gap:12px; justify-content:flex-end; }

    /* ── Upload modal ── */
    .upload-modal-overlay { position:fixed; inset:0; background:rgba(31,34,71,.18); backdrop-filter:blur(7px); display:none; align-items:center; justify-content:center; z-index:500; padding:24px; }
    .upload-modal-overlay.open { display:flex; }
    .upload-modal { width:min(520px,100%); background:#fff; border-radius:24px; box-shadow:0 30px 80px rgba(31,34,71,.22); padding:30px; }
    .upload-modal-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
    .upload-modal-title { font-family:'DM Serif Display',serif; font-size:20px; font-weight:400; color:var(--navy); }
    .upload-modal-close { width:30px; height:30px; border-radius:8px; background:var(--navy-faint); border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; color:var(--navy-dim); font-size:16px; }
    .upload-modal-close:hover { background:var(--red-dim); color:var(--red); }
    .upload-drop-area { border:2px dashed rgba(31,34,71,.14); border-radius:12px; padding:28px; text-align:center; cursor:pointer; transition:border-color .2s, background .2s; margin-bottom:18px; }
    .upload-drop-area:hover { border-color:rgba(0,151,178,.4); background:rgba(0,151,178,.03); }
    .upload-drop-area input { display:none; }
    .upload-drop-icon { font-size:34px; margin-bottom:10px; }
    .upload-drop-text { font-size:13px; color:var(--navy-dim); }
    .upload-drop-text strong { color:var(--teal); }
    .upload-file-name { font-size:12.5px; color:var(--green); font-weight:600; margin-top:8px; }
    .upload-modal-actions { display:flex; gap:12px; justify-content:flex-end; }

    /* ── Notification panel (auditor style — fixed on body) ── */
    .notif-panel {
      display: none; position: fixed; top: 72px; right: 28px;
      width: 340px; background: #fff; border-radius: 16px;
      box-shadow: 0 20px 60px rgba(31,34,71,0.22), 0 4px 16px rgba(31,34,71,0.10);
      border: 1.5px solid rgba(31,34,71,0.08); z-index: 9999; overflow: hidden;
      animation: slideDown .2s cubic-bezier(.22,1,.36,1);
    }
    .notif-panel.open { display: block; }
    @keyframes slideDown { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }
    .notif-panel-header { display:flex; align-items:center; justify-content:space-between; padding:16px 18px 12px; border-bottom:1px solid rgba(31,34,71,0.07); }
    .notif-panel-title { font-family:'DM Serif Display',serif; font-size:16px; font-weight:400; color:var(--navy); }
    .notif-actions { display:flex; gap:8px; align-items:center; }
    .notif-count { font-size:11px; font-weight:700; background:var(--teal); color:#fff; border-radius:20px; padding:2px 8px; }
    .notif-mark-all { font-size:11.5px; font-weight:600; color:var(--teal); background:none; border:none; cursor:pointer; font-family:'DM Sans',sans-serif; padding:0; }
    .notif-mark-all:hover { text-decoration:underline; }
    .notif-list { max-height:360px; overflow-y:auto; }
    .notif-item { display:flex; align-items:flex-start; gap:12px; padding:13px 18px; border-bottom:1px solid rgba(31,34,71,0.05); cursor:pointer; transition:background .13s; position:relative; }
    .notif-item:last-child { border-bottom:none; }
    .notif-item:hover { background:rgba(0,151,178,0.04); }
    .notif-item.unread { background:rgba(0,151,178,0.05); }
    .notif-item.unread:hover { background:rgba(0,151,178,0.09); }
    .notif-icon { width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; margin-top:1px; }
    .notif-body { flex:1; min-width:0; }
    .notif-msg { font-size:13px; font-weight:500; color:var(--navy); line-height:1.45; margin-bottom:4px; }
    .notif-item.unread .notif-msg { font-weight:600; }
    .notif-time { font-size:11px; color:rgba(31,34,71,0.38); font-family:'IBM Plex Mono',monospace; }
    .notif-unread-dot { width:7px; height:7px; border-radius:50%; background:var(--teal); flex-shrink:0; margin-top:6px; }
    .notif-empty { padding:36px 18px; text-align:center; color:var(--navy-dim); font-size:13px; }
    .notif-footer { padding:12px 18px; border-top:1px solid rgba(31,34,71,0.07); text-align:center; }
    .notif-footer-btn { font-size:12.5px; font-weight:600; color:var(--teal); background:none; border:none; cursor:pointer; font-family:'DM Sans',sans-serif; display:inline-flex; align-items:center; gap:5px; }
    .notif-footer-btn:hover { text-decoration:underline; }

    /* ── Approved / Rejected status banner ── */
    .status-banner { display:flex; align-items:center; gap:14px; padding:18px 22px; border-radius:14px; margin-bottom:20px; }
    .status-banner.approved { background:var(--green-dim); border:1.5px solid rgba(5,150,105,.18); }
    .status-banner.rejected { background:var(--red-dim); border:1.5px solid rgba(220,38,38,.18); }
    .status-banner-icon { font-size:28px; }
    .status-banner-text { flex:1; }
    .status-banner-label { font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; }
    .status-banner.approved .status-banner-label { color:var(--green); }
    .status-banner.rejected .status-banner-label { color:var(--red); }
    .status-banner-msg { font-size:13px; color:var(--navy-dim); margin-top:2px; }

    /* ── Scrollbar ── */
    ::-webkit-scrollbar { width:5px; } ::-webkit-scrollbar-track { background:transparent; } ::-webkit-scrollbar-thumb { background:rgba(31,34,71,.12); border-radius:3px; }

    /* ── Responsive ── */
    @media (max-width: 1100px) {
      .stats-grid { grid-template-columns:1fr; }
      .form-grid { grid-template-columns:1fr; }
      .form-label { align-self:end; }
      .detail-grid { grid-template-columns:1fr; }
      .review-detail-grid { grid-template-columns:1fr; }
    }
    @media (max-width: 700px) {
      .logout-modal { max-width:440px; padding:0 0 22px; border-radius:18px; }
      .logout-modal h3 { font-size:19px; }
      .logout-modal p { font-size:13px; }
      .logout-modal-actions { grid-template-columns:1fr 1fr; }
      .logout-modal-btn { font-size:14px; }
      .modal-actions { grid-template-columns:1fr; }
      .modal-btn { min-height:60px; font-size:17px; }
    }
      .logout-modal h3 { font-family:'DM Serif Display',serif; font-size:19px; font-weight:400; color:var(--navy); text-align:center; padding:0 24px 8px; line-height:1.3; margin:0; letter-spacing:0; }
      .logout-modal p { font-size:13px; color:var(--navy-dim); text-align:center; padding:0 28px 24px; line-height:1.6; margin:0; }
      .logout-modal-actions { display:grid; grid-template-columns:1fr 1fr; gap:10px; padding:0 20px; }
      .logout-modal-btn { padding:13px 20px; border-radius:10px; font-family:'DM Sans',sans-serif; font-size:14px; font-weight:600; cursor:pointer; border:none; transition:all .15s; min-height:auto; width:100%; }
    
  </style>
</head>
<body>
<div class="app">

  <!-- ════════════════════════════════════
       SIDEBAR
  ════════════════════════════════════ -->
  <aside class="sidebar" id="sidebar">
    <div class="sb-head">
      <div class="sb-wordmark-wrap"><div class="sb-wordmark-svg"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  zoomAndPan="magnify" viewBox="0 0 337.5 187.499995"  preserveAspectRatio="xMidYMid meet" version="1.0"><defs><g/><clipPath id="69d8563f3b"><rect x="0" width="265" y="0" height="158"/></clipPath><clipPath id="4a4d1c3cce"><path d="M 4.804688 4.765625 L 22.65625 4.765625 L 22.65625 22.617188 L 4.804688 22.617188 Z M 4.804688 4.765625 " clip-rule="nonzero"/></clipPath><clipPath id="4d2650adb0"><path d="M 13.730469 4.765625 C 8.800781 4.765625 4.804688 8.761719 4.804688 13.691406 C 4.804688 18.621094 8.800781 22.617188 13.730469 22.617188 C 18.660156 22.617188 22.65625 18.621094 22.65625 13.691406 C 22.65625 8.761719 18.660156 4.765625 13.730469 4.765625 Z M 13.730469 4.765625 " clip-rule="nonzero"/></clipPath><clipPath id="b9bbec4bb1"><path d="M 0.804688 0.765625 L 18.65625 0.765625 L 18.65625 18.617188 L 0.804688 18.617188 Z M 0.804688 0.765625 " clip-rule="nonzero"/></clipPath><clipPath id="b545ad424a"><path d="M 9.730469 0.765625 C 4.800781 0.765625 0.804688 4.761719 0.804688 9.691406 C 0.804688 14.621094 4.800781 18.617188 9.730469 18.617188 C 14.660156 18.617188 18.65625 14.621094 18.65625 9.691406 C 18.65625 4.761719 14.660156 0.765625 9.730469 0.765625 Z M 9.730469 0.765625 " clip-rule="nonzero"/></clipPath><clipPath id="2f86d00c01"><rect x="0" width="19" y="0" height="19"/></clipPath><clipPath id="de643e8a4e"><path d="M 7 6.960938 L 20.457031 6.960938 L 20.457031 20.421875 L 7 20.421875 Z M 7 6.960938 " clip-rule="nonzero"/></clipPath><clipPath id="9040a17bd3"><path d="M 13.730469 6.960938 C 10.011719 6.960938 7 9.976562 7 13.691406 C 7 17.40625 10.011719 20.421875 13.730469 20.421875 C 17.445312 20.421875 20.457031 17.40625 20.457031 13.691406 C 20.457031 9.976562 17.445312 6.960938 13.730469 6.960938 Z M 13.730469 6.960938 " clip-rule="nonzero"/></clipPath><clipPath id="ba2eb6533a"><path d="M 8.050781 8.011719 L 19.730469 8.011719 L 19.730469 19.691406 L 8.050781 19.691406 Z M 8.050781 8.011719 " clip-rule="nonzero"/></clipPath><clipPath id="85b099582b"><rect x="0" width="27" y="0" height="27"/></clipPath><clipPath id="fea0f96916"><path d="M 21.511719 3.914062 L 40.574219 3.914062 L 40.574219 22.976562 L 21.511719 22.976562 Z M 21.511719 3.914062 " clip-rule="nonzero"/></clipPath><clipPath id="12d611a9d9"><path d="M 31.042969 3.914062 C 25.777344 3.914062 21.511719 8.183594 21.511719 13.445312 C 21.511719 18.710938 25.777344 22.976562 31.042969 22.976562 C 36.304688 22.976562 40.574219 18.710938 40.574219 13.445312 C 40.574219 8.183594 36.304688 3.914062 31.042969 3.914062 Z M 31.042969 3.914062 " clip-rule="nonzero"/></clipPath><clipPath id="285a6d3d53"><path d="M 0.511719 0.914062 L 19.574219 0.914062 L 19.574219 19.976562 L 0.511719 19.976562 Z M 0.511719 0.914062 " clip-rule="nonzero"/></clipPath><clipPath id="020bad4bb2"><path d="M 10.042969 0.914062 C 4.777344 0.914062 0.511719 5.183594 0.511719 10.445312 C 0.511719 15.710938 4.777344 19.976562 10.042969 19.976562 C 15.304688 19.976562 19.574219 15.710938 19.574219 10.445312 C 19.574219 5.183594 15.304688 0.914062 10.042969 0.914062 Z M 10.042969 0.914062 " clip-rule="nonzero"/></clipPath><clipPath id="956c204d63"><rect x="0" width="20" y="0" height="20"/></clipPath><clipPath id="245db32a48"><path d="M 23.855469 6.261719 L 38.226562 6.261719 L 38.226562 20.628906 L 23.855469 20.628906 Z M 23.855469 6.261719 " clip-rule="nonzero"/></clipPath><clipPath id="bcb1073d7a"><path d="M 31.042969 6.261719 C 27.074219 6.261719 23.855469 9.476562 23.855469 13.445312 C 23.855469 17.414062 27.074219 20.628906 31.042969 20.628906 C 35.007812 20.628906 38.226562 17.414062 38.226562 13.445312 C 38.226562 9.476562 35.007812 6.261719 31.042969 6.261719 Z M 31.042969 6.261719 " clip-rule="nonzero"/></clipPath><clipPath id="7e98c60055"><path d="M 24.976562 7.378906 L 37.449219 7.378906 L 37.449219 19.855469 L 24.976562 19.855469 Z M 24.976562 7.378906 " clip-rule="nonzero"/></clipPath><clipPath id="ce8093f24c"><path d="M 4.617188 3.914062 L 23.683594 3.914062 L 23.683594 22.976562 L 4.617188 22.976562 Z M 4.617188 3.914062 " clip-rule="nonzero"/></clipPath><clipPath id="ea71ee7392"><path d="M 14.148438 3.914062 C 8.886719 3.914062 4.617188 8.183594 4.617188 13.445312 C 4.617188 18.710938 8.886719 22.976562 14.148438 22.976562 C 19.414062 22.976562 23.683594 18.710938 23.683594 13.445312 C 23.683594 8.183594 19.414062 3.914062 14.148438 3.914062 Z M 14.148438 3.914062 " clip-rule="nonzero"/></clipPath><clipPath id="ad3dec466e"><path d="M 0.617188 0.914062 L 19.683594 0.914062 L 19.683594 19.976562 L 0.617188 19.976562 Z M 0.617188 0.914062 " clip-rule="nonzero"/></clipPath><clipPath id="d0bbcc6f66"><path d="M 10.148438 0.914062 C 4.886719 0.914062 0.617188 5.183594 0.617188 10.445312 C 0.617188 15.710938 4.886719 19.976562 10.148438 19.976562 C 15.414062 19.976562 19.683594 15.710938 19.683594 10.445312 C 19.683594 5.183594 15.414062 0.914062 10.148438 0.914062 Z M 10.148438 0.914062 " clip-rule="nonzero"/></clipPath><clipPath id="b68ff58271"><rect x="0" width="20" y="0" height="20"/></clipPath><clipPath id="90844f80c6"><path d="M 6.964844 6.261719 L 21.335938 6.261719 L 21.335938 20.628906 L 6.964844 20.628906 Z M 6.964844 6.261719 " clip-rule="nonzero"/></clipPath><clipPath id="96ccdf60a7"><path d="M 14.148438 6.261719 C 10.179688 6.261719 6.964844 9.476562 6.964844 13.445312 C 6.964844 17.414062 10.179688 20.628906 14.148438 20.628906 C 18.117188 20.628906 21.335938 17.414062 21.335938 13.445312 C 21.335938 9.476562 18.117188 6.261719 14.148438 6.261719 Z M 14.148438 6.261719 " clip-rule="nonzero"/></clipPath><clipPath id="72b62c73a7"><path d="M 8.082031 7.378906 L 20.558594 7.378906 L 20.558594 19.855469 L 8.082031 19.855469 Z M 8.082031 7.378906 " clip-rule="nonzero"/></clipPath><clipPath id="2ed8797546"><rect x="0" width="45" y="0" height="27"/></clipPath></defs><g transform="matrix(1, 0, 0, 1, 36, 17)"><g clip-path="url(#69d8563f3b)"><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(1.366805, 123.791473)"><g><path d="M 65.71875 -25.9375 L 65.71875 0 L 16.75 0 L 16.75 1.890625 C 16.75 2.722656 17.019531 3.410156 17.5625 3.953125 C 18.101562 4.503906 18.796875 4.78125 19.640625 4.78125 L 42.296875 4.78125 L 42.296875 26.5625 L 23.046875 26.5625 C 18.171875 26.5625 14.160156 24.988281 11.015625 21.84375 C 7.867188 18.695312 6.296875 14.691406 6.296875 9.828125 L 6.296875 -9.1875 C 6.296875 -13.976562 7.828125 -17.945312 10.890625 -21.09375 C 13.953125 -24.238281 17.832031 -25.851562 22.53125 -25.9375 L 12.34375 -39.40625 L 12.34375 -65.71875 L 51.375 -65.71875 C 53.46875 -65.71875 55.3125 -64.941406 56.90625 -63.390625 C 58.5 -61.835938 59.296875 -59.84375 59.296875 -57.40625 L 59.296875 -39.40625 L 49.234375 -25.9375 Z M 43.8125 -33.109375 L 27.703125 -33.109375 L 32.984375 -25.9375 L 38.53125 -25.9375 Z M 43.8125 -33.109375 "/></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(65.825457, 123.791473)"><g><path d="M -1.265625 0 L -1.265625 -25.9375 L 24.421875 -25.9375 L 24.421875 0 Z M -1.265625 0 "/></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(88.990287, 123.791473)"><g><path d="M 33.609375 -25.9375 L 33.609375 0 L -1.265625 0 L -1.265625 -25.9375 L 10.328125 -25.9375 L 10.328125 -65.71875 L 20.78125 -65.71875 L 20.78125 -25.9375 Z M 14.984375 12.96875 L 21.78125 6.296875 L 29.96875 14.484375 L 21.78125 22.78125 L 14.984375 15.984375 L 8.3125 22.78125 L 0 14.484375 L 8.3125 6.296875 Z M 14.984375 12.96875 "/></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(121.34551, 123.791473)"><g><path d="M -1.265625 0 L -1.265625 -25.9375 L 24.421875 -25.9375 L 24.421875 0 Z M -1.265625 0 "/></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(144.51034, 123.791473)"><g><path d="M 23.671875 -80.328125 L 15.484375 -72.015625 L 7.171875 -80.328125 L 15.484375 -88.515625 Z M 33.609375 -25.9375 L 33.609375 0 L -1.265625 0 L -1.265625 -25.9375 L 10.328125 -25.9375 L 10.328125 -65.71875 L 20.78125 -65.71875 L 20.78125 -25.9375 Z M 33.609375 -25.9375 "/></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(176.865563, 123.791473)"><g><path d="M -1.265625 0 L -1.265625 -25.9375 L 24.421875 -25.9375 L 24.421875 0 Z M -1.265625 0 "/></g></g></g><g fill="#f1f0ec" fill-opacity="1"><g transform="translate(200.030393, 123.791473)"><g><path d="M 40.546875 -65.71875 C 45.410156 -65.71875 49.414062 -64.144531 52.5625 -61 C 55.707031 -57.851562 57.28125 -53.847656 57.28125 -48.984375 L 57.28125 0 L -1.265625 0 L -1.265625 -25.9375 L 5.15625 -25.9375 L 5.15625 -65.71875 Z M 15.609375 -25.9375 L 46.84375 -25.9375 L 46.84375 -30.21875 C 46.84375 -31.050781 46.566406 -31.738281 46.015625 -32.28125 C 45.472656 -32.832031 44.78125 -33.109375 43.9375 -33.109375 L 15.609375 -33.109375 Z M 15.609375 -25.9375 "/></g></g></g></g></g><path stroke-linecap="butt" transform="matrix(0.70424, -0.252106, 0.252106, 0.70424, 240.525223, 59.282541)" fill="none" stroke-linejoin="miter" d="M 0.00210982 2.001302 L 63.961941 2.000846 " stroke="#f1f0ec" stroke-width="4" stroke-opacity="1" stroke-miterlimit="4"/><g transform="matrix(1, 0, 0, 1, 182, 47)"><g clip-path="url(#85b099582b)"><g clip-path="url(#4a4d1c3cce)"><g clip-path="url(#4d2650adb0)"><g transform="matrix(1, 0, 0, 1, 4, 4)"><g clip-path="url(#2f86d00c01)"><g clip-path="url(#b9bbec4bb1)"><g clip-path="url(#b545ad424a)"><path fill="#f1f0ec" d="M 0.804688 0.765625 L 18.65625 0.765625 L 18.65625 18.617188 L 0.804688 18.617188 Z M 0.804688 0.765625 " fill-opacity="1" fill-rule="nonzero"/></g></g></g></g></g></g><g clip-path="url(#de643e8a4e)"><g clip-path="url(#9040a17bd3)"><path stroke-linecap="butt" transform="matrix(1.062015, 0, 0, 1.062015, 7.000809, 6.96228)" fill="none" stroke-linejoin="miter" d="M 6.336692 -0.00126388 C 2.835093 -0.00126388 -0.000761592 2.838269 -0.000761592 6.33619 C -0.000761592 9.834111 2.835093 12.673644 6.336692 12.673644 C 9.834614 12.673644 12.670468 9.834111 12.670468 6.33619 C 12.670468 2.838269 9.834614 -0.00126388 6.336692 -0.00126388 Z M 6.336692 -0.00126388 " stroke="#0097b2" stroke-width="2.817307" stroke-opacity="1" stroke-miterlimit="4"/></g></g><g clip-path="url(#ba2eb6533a)"><path fill="#1f2247" d="M 19.398438 13.683594 C 15.144531 14.46875 14.507812 15.105469 13.722656 19.359375 C 12.941406 15.105469 12.304688 14.46875 8.050781 13.683594 C 12.304688 12.902344 12.941406 12.265625 13.722656 8.011719 C 14.507812 12.265625 15.144531 12.902344 19.398438 13.683594 Z M 19.398438 13.683594 " fill-opacity="1" fill-rule="nonzero"/></g></g></g><g transform="matrix(1, 0, 0, 1, 117, 142)"><g clip-path="url(#2ed8797546)"><g clip-path="url(#fea0f96916)"><g clip-path="url(#12d611a9d9)"><g transform="matrix(1, 0, 0, 1, 21, 3)"><g clip-path="url(#956c204d63)"><g clip-path="url(#285a6d3d53)"><g clip-path="url(#020bad4bb2)"><path fill="#f1f0ec" d="M 0.511719 0.914062 L 19.574219 0.914062 L 19.574219 19.976562 L 0.511719 19.976562 Z M 0.511719 0.914062 " fill-opacity="1" fill-rule="nonzero"/></g></g></g></g></g></g><g clip-path="url(#245db32a48)"><g clip-path="url(#bcb1073d7a)"><path stroke-linecap="butt" transform="matrix(1.133988, 0, 0, 1.133988, 23.856151, 6.260488)" fill="none" stroke-linejoin="miter" d="M 6.33765 0.00108563 C 2.837833 0.00108563 -0.00060156 2.836075 -0.00060156 6.335893 C -0.00060156 9.83571 2.837833 12.6707 6.33765 12.6707 C 9.834023 12.6707 12.672457 9.83571 12.672457 6.335893 C 12.672457 2.836075 9.834023 0.00108563 6.33765 0.00108563 Z M 6.33765 0.00108563 " stroke="#0097b2" stroke-width="2.638495" stroke-opacity="1" stroke-miterlimit="4"/></g></g><g clip-path="url(#7e98c60055)"><path fill="#1f2247" d="M 37.09375 13.4375 C 32.550781 14.277344 31.871094 14.953125 31.035156 19.5 C 30.199219 14.953125 29.519531 14.277344 24.976562 13.4375 C 29.519531 12.601562 30.199219 11.925781 31.035156 7.378906 C 31.871094 11.925781 32.550781 12.601562 37.09375 13.4375 Z M 37.09375 13.4375 " fill-opacity="1" fill-rule="nonzero"/></g><g clip-path="url(#ce8093f24c)"><g clip-path="url(#ea71ee7392)"><g transform="matrix(1, 0, 0, 1, 4, 3)"><g clip-path="url(#b68ff58271)"><g clip-path="url(#ad3dec466e)"><g clip-path="url(#d0bbcc6f66)"><path fill="#f1f0ec" d="M 0.617188 0.914062 L 19.683594 0.914062 L 19.683594 19.976562 L 0.617188 19.976562 Z M 0.617188 0.914062 " fill-opacity="1" fill-rule="nonzero"/></g></g></g></g></g></g><g clip-path="url(#90844f80c6)"><g clip-path="url(#96ccdf60a7)"><path stroke-linecap="butt" transform="matrix(1.133988, 0, 0, 1.133988, 6.96438, 6.260488)" fill="none" stroke-linejoin="miter" d="M 6.335216 0.00108563 C 2.835398 0.00108563 0.000408516 2.836075 0.000408516 6.335893 C 0.000408516 9.83571 2.835398 12.6707 6.335216 12.6707 C 9.835033 12.6707 12.673467 9.83571 12.673467 6.335893 C 12.673467 2.836075 9.835033 0.00108563 6.335216 0.00108563 Z M 6.335216 0.00108563 " stroke="#0097b2" stroke-width="2.638495" stroke-opacity="1" stroke-miterlimit="4"/></g></g><g clip-path="url(#72b62c73a7)"><path fill="#1f2247" d="M 20.203125 13.4375 C 15.65625 14.277344 14.980469 14.953125 14.144531 19.5 C 13.304688 14.953125 12.628906 14.277344 8.082031 13.4375 C 12.628906 12.601562 13.304688 11.925781 14.144531 7.378906 C 14.980469 11.925781 15.65625 12.601562 20.203125 13.4375 Z M 20.203125 13.4375 " fill-opacity="1" fill-rule="nonzero"/></g></g></g></svg></div></div>
      <button class="sb-toggle" onclick="toggleSidebar()">
        <svg id="toggle-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15,18 9,12 15,6"/></svg>
      </button>
    </div>
    <div class="sb-role">Employee</div>
    <nav class="sb-nav">
      <button class="nav-item active" id="nav-overview" onclick="navigate('overview',this)">
        <span class="nav-icon"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg></span>
        <span class="nav-label">Overview</span>
      </button>
      <button class="nav-item" id="nav-requests" onclick="navigate('requests',this)">
        <span class="nav-icon"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9"/><path d="M9 3v6h6"/><path d="M9 3l6 6"/></svg></span>
        <span class="nav-label">View Fund Requests</span>
      </button>
      <button class="nav-item" id="nav-new-request" onclick="navigate('new-request',this)">
        <span class="nav-icon"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg></span>
        <span class="nav-label">New Fund Request</span>
      </button>
    </nav>
  </aside>

  <!-- ════════════════════════════════════
       MAIN
  ════════════════════════════════════ -->
  <div class="main">
    <header class="topbar">
      <h1 class="page-title" id="page-title">Overview</h1>
      <div class="topbar-right">
        <div class="icon-btn" id="notif-btn" title="Notifications" onclick="toggleNotifPanel()">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          <span class="notif-dot" id="notif-dot"></span>
        </div>
        <div class="user-pill">
          <div class="avatar"><?= htmlspecialchars($currentUser['avatar_initials']) ?></div>
          <span class="user-name"><?= htmlspecialchars($currentUser['full_name']) ?></span>
        </div>
        <button class="logout-btn" onclick="openLogoutModal()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          Logout
        </button>
      </div>
    </header>

    <div class="content">

      <!-- ══════════════════════════════
           VIEW 1 — Overview
      ══════════════════════════════ -->
      <div class="view active" id="view-overview">
        <div class="stats-grid overview-grid">
          <div class="stat-card">
            <div class="overview-card-icon teal" id="overview-request-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>
            </div>
            <div class="stat-label">Current Request Status</div>
            <div class="overview-status-wrap">
              <span class="overview-status-text teal" id="overview-request-status">Pending</span>
            </div>
          </div>
          <div class="stat-card">
            <div class="overview-card-icon green">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7h18"/><path d="M6 11h12"/><path d="M7 15h3"/><path d="M14 15h3"/><rect x="3" y="5" width="18" height="14" rx="2"/></svg>
            </div>
            <div class="stat-label">Remaining Funds Status</div>
            <div class="funds-meta">
              <div class="stat-value teal" id="overview-funds-status">SAR 21,500</div>
              <div class="funds-note" id="overview-funds-note">Left from SAR 30,000</div>
            </div>
            <div class="funds-progress"><div class="funds-progress-bar" id="overview-funds-progress"></div></div>
          </div>
        </div>
        <div class="panel overview-table-wrap">
          <div class="panel-header">
            <div>
              <div class="panel-title">Current Request</div>
              <div class="panel-sub">A quick summary of your latest fund request.</div>
            </div>
          </div>
          <div class="tbl-head" style="grid-template-columns:110px 1.4fr 140px 130px 120px 100px;">
            <span class="th">Request ID</span>
            <span class="th">Project Name</span>
            <span class="th">Amount</span>
            <span class="th">Status</span>
            <span class="th">Deadline</span>
            <span class="th">Action</span>
          </div>
          <div id="overview-table-rows"></div>
        </div>

      </div>

      <!-- ══════════════════════════════
           VIEW 1 — My Fund Requests
      ══════════════════════════════ -->
      <div class="view" id="view-requests">
        <div class="panel overview-table-wrap">
          <div class="panel-header">
            <div>
              <div class="panel-title">My Fund Requests</div>
              <div class="panel-sub">View all your fund requests.</div>
            </div>
          </div>
          <div class="tbl-head" style="grid-template-columns:110px 1.4fr 140px 130px 120px 100px;">
            <span class="th">Request ID</span>
            <span class="th">Project Name</span>
            <span class="th">Amount</span>
            <span class="th">Status</span>
            <span class="th">Deadline</span>
            <span class="th">Action</span>
          </div>
          <div id="request-table-wrap"></div>
        </div>
      </div>

      <!-- ══════════════════════════════
           VIEW 3 — New Fund Request (form)
      ══════════════════════════════ -->
      <div class="view" id="view-new-request">
        <div class="panel" style="max-width:100%;margin:0;">
          <div class="form-wrap">
            <form id="request-form" onsubmit="submitRequest(event)" novalidate>
              <div class="form-grid">

                <label class="form-label" for="projectName">Project Name</label>
                <div>
                  <input class="input" id="projectName" placeholder="e.g. Marketing Campaign Q3" />
                  <div class="field-error" id="err-projectName">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <span id="err-projectName-text"></span>
                  </div>
                </div>

                <label class="form-label" for="requestedAmount">Requested Amount</label>
                <div>
                  <input class="input" id="requestedAmount" placeholder="SAR" inputmode="numeric" />
                  <div class="field-error" id="err-requestedAmount">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <span id="err-requestedAmount-text"></span>
                  </div>
                </div>

                <label class="form-label" for="purpose">Purpose</label>
                <div>
                  <input class="input" id="purpose" placeholder="Brief purpose of this request" />
                  <div class="field-error" id="err-purpose">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <span id="err-purpose-text"></span>
                  </div>
                </div>

                <label class="form-label" for="description">Description</label>
                <div>
                  <textarea class="textarea" id="description" placeholder="Provide additional details about the fund usage"></textarea>
                  <div class="field-error" id="err-description">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <span id="err-description-text"></span>
                  </div>
                </div>

                <label class="form-label" for="category">Category</label>
                <div>
                  <input class="input" id="category" placeholder="e.g. Operations, Marketing, IT" />
                  <div class="field-error" id="err-category">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <span id="err-category-text"></span>
                  </div>
                </div>

                <label class="form-label" for="deadline">Deadline</label>
                <div>
                  <input class="input" type="date" id="deadline" style="color-scheme:light;" />
                  <div class="field-error" id="err-deadline">
                    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <span id="err-deadline-text"></span>
                  </div>
                </div>

                <span class="form-label">Priority</span>
                <div class="priority-group">
                  <label class="radio-item"><input type="radio" name="priority" value="High" checked /> High</label>
                  <label class="radio-item"><input type="radio" name="priority" value="Medium" /> Medium</label>
                  <label class="radio-item"><input type="radio" name="priority" value="Low" /> Low</label>
                </div>

              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-primary" id="submit-request-btn">Submit Request</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- ══════════════════════════════
           VIEW 4 — Blocked Page
      ══════════════════════════════ -->
      <div class="view" id="blockedPage">
        <div class="panel" style="max-width:100%;margin:0;">
          <div style="display:flex;flex-direction:column;align-items:center;text-align:center;padding:52px 40px 44px;">
            <div style="width:56px;height:56px;border-radius:50%;background:var(--red-dim);color:var(--red);display:flex;align-items:center;justify-content:center;margin-bottom:22px;">
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            </div>
            <h2 style="font-family:'DM Serif Display',serif;font-size:22px;font-weight:400;color:var(--navy);margin-bottom:10px;">New Fund Request Blocked</h2>
            <p id="blocked-request-message" style="max-width:480px;color:var(--navy-dim);font-size:14px;line-height:1.65;margin-bottom:28px;">You currently have an active fund request pending review. The system allows only one active request per employee. Please review your existing request before submitting a new one.</p>
            <button class="btn btn-primary" onclick="navigate('requests', document.getElementById('nav-requests'))">Go to View Fund Requests</button>
          </div>
        </div>
      </div>

      <!-- ══════════════════════════════
           VIEW 5 — Fund Request Detail + Expense Tracking
      ══════════════════════════════ -->
      <div class="view" id="view-request-detail">

        <!-- Request Details Panel -->
        <div class="panel" style="margin-bottom:20px;">
          <div class="panel-header">
            <div>
              <div class="panel-title">Request Details</div>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
              <div class="inline-action-group" id="pending-detail-actions">
                <button class="btn btn-secondary btn-pill-round" id="edit-request-btn" onclick="editRequest(editingRequestId || currentViewedRequestId)">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>
                  Edit
                </button>
                <button class="btn btn-ghost btn-pill-round" id="delete-request-btn" onclick="deleteViewedRequest()">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3,6 5,6 21,6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
                  Delete
                </button>
              </div>
              <button class="btn btn-ghost btn-pill-round" onclick="navigate('requests', document.getElementById('nav-requests'))">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15,18 9,12 15,6"/></svg>
                Back
              </button>
            </div>
          </div>
          <div class="detail-grid" id="detail-grid-content">
            <!-- populated by JS -->
          </div>
        </div>

        <!-- Expense Tracking Panel -->
        <div class="panel">
          <div class="panel-header panel-flat-header">
            <div>
              <div class="panel-title">Expense Tracking</div>
            </div>
          </div>
          <div class="summary-row" id="expense-summary-row">
            <div class="summary-pill" id="expense-total-spent">0 SAR</div>
            <div class="summary-meta">
              <div><strong>Total Spent</strong></div>
              <div id="expense-requested-budget">Requested Budget: —</div>
              <div id="expense-remaining-budget">Remaining Budget: —</div>
            </div>
          </div>
          <div class="panel-header" style="border-bottom:none; padding-top:18px;" id="expense-txn-header">
            <div><div class="panel-title">Card Transactions</div></div>
          </div>
          <div class="tbl-head" style="grid-template-columns:110px 110px 1.2fr 110px 120px 170px 130px;">
            <span class="th">Transaction ID</span>
            <span class="th">Date</span>
            <span class="th">Vendor</span>
            <span class="th">Amount</span>
            <span class="th">Invoice Due</span>
            <span class="th">Invoice Status</span>
            <span class="th">Action</span>
          </div>
          <div id="expense-txn-body"><div class="empty" style="padding:28px 22px;">No transactions available yet.</div></div>
        </div>

      </div>


      <!-- ══════════════════════════════
           VIEW — Approved Request Detail
      ══════════════════════════════ -->
      <div class="view" id="view-approved-detail">
        <button class="btn btn-ghost" onclick="navigate('requests', document.getElementById('nav-requests'))" style="margin-bottom:18px; padding:8px 16px;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15,18 9,12 15,6"/></svg>
          Back to View Fund Requests
        </button>
        <div class="page-intro">
          <h2>View Fund Request</h2>
          <p>Review the approved request summary.</p>
        </div>
        <div class="status-banner approved">
          <div class="status-banner-icon">✅</div>
          <div class="status-banner-text">
            <div class="status-banner-label">Approved</div>
            <div class="status-banner-msg">Your request has been approved. Funds are available for use.</div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-header">
            <div>
              <div class="panel-title">Request Details</div>
              <div class="panel-sub">Approved request information.</div>
            </div>
          </div>
          <div class="detail-grid">
            <div class="detail-label">Project Name</div><div class="detail-value">Branch Network Switch Upgrade</div>
            <div class="detail-label">Requested Amount</div><div class="detail-value">18,000 SAR</div>
            <div class="detail-label">Remaining Amount</div><div class="detail-value"><strong>11,200 SAR</strong></div>
            <div class="detail-label">Purpose</div><div class="detail-value">Replace outdated network switches for the administration floor.</div>
            <div class="detail-label">Description</div><div class="detail-value">The approved amount covers hardware purchase, structured cabling accessories, and installation support for the branch network refresh.</div>
            <div class="detail-label">Category</div><div class="detail-value">IT Equipment</div>
            <div class="detail-label">Priority</div><div class="detail-value">Medium</div>
          </div>
        </div>
      </div>

      <!-- ══════════════════════════════
           VIEW — Rejected Request Detail
      ══════════════════════════════ -->
      <div class="view" id="view-rejected-detail">
        <button class="btn btn-ghost" onclick="navigate('requests', document.getElementById('nav-requests'))" style="margin-bottom:18px; padding:8px 16px;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15,18 9,12 15,6"/></svg>
          Back to View Fund Requests
        </button>
        <div class="page-intro">
          <h2>View Fund Request</h2>
          <p>Review the rejected request and its feedback.</p>
        </div>
        <div class="status-banner rejected">
          <div class="status-banner-icon">❌</div>
          <div class="status-banner-text">
            <div class="status-banner-label">Rejected</div>
            <div class="status-banner-msg">This request was not approved. Please review the rejection reason below.</div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-header">
            <div>
              <div class="panel-title">Request Details</div>
              <div class="panel-sub">Rejected request information.</div>
            </div>
          </div>
          <div class="detail-grid">
            <div class="detail-label">Project Name</div><div class="detail-value">Additional Digital Ad Channels</div>
            <div class="detail-label">Requested Amount</div><div class="detail-value">28,000 SAR</div>
            <div class="detail-label">Purpose</div><div class="detail-value">Expand the campaign to two extra paid media platforms.</div>
            <div class="detail-label">Description</div><div class="detail-value">The request was submitted to broaden paid reach beyond the approved media plan, but the extra allocation could not be accommodated within the current quarter ceiling.</div>
            <div class="detail-label">Category</div><div class="detail-value">Marketing</div>
            <div class="detail-label">Priority</div><div class="detail-value">Medium</div>
            <div class="detail-label">Rejection Reason</div><div class="detail-value"><strong>Budget Limit Reached:</strong> The approved quarterly digital marketing allocation was already committed to higher-priority launch activities.</div>
          </div>
        </div>
      </div>

    </div><!-- /.content -->
  </div><!-- /.main -->
</div><!-- /.app -->

<!-- ════════════════════════════════════
     TOAST
════════════════════════════════════ -->
<div class="toast" id="toast"></div>

<!-- ════════════════════════════════════
     LOGOUT MODAL
════════════════════════════════════ -->
<div class="logout-modal-overlay" id="logout-modal" onclick="closeLogoutModal(event)">
  <div class="logout-modal">
    <div class="logout-modal-icon-wrap">
      <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16,17 21,12 16,7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
    </div>
    <h3>Log out?</h3>
    <p>You will be returned to the Manea landing page.</p>
    <div class="logout-modal-actions">
      <button class="logout-modal-btn primary" onclick="confirmLogout()">Log Out</button>
      <button class="logout-modal-btn secondary" onclick="closeLogoutModalDirect()">Cancel</button>
    </div>
  </div>
</div>

<!-- ════════════════════════════════════
     CONFIRM CLOSE REQUEST MODAL
════════════════════════════════════ -->
<div class="modal" id="confirmModal">
  <div class="modal-box">
    <h3>Confirm Close Request</h3>
    <p>Are you sure you want to close this request? This action cannot be undone.</p>
    <div class="modal-actions">
      <button class="modal-btn secondary" onclick="closeConfirmModal()">No, Cancel</button>
      <button class="modal-btn primary" onclick="confirmCloseRequest()">Yes, Close It</button>
    </div>
  </div>
</div>

<!-- ════════════════════════════════════
     REVIEW MODAL — details only
════════════════════════════════════ -->
<div class="review-modal-overlay" id="reviewModal" onclick="if(event.target===this)closeReviewModal()">
  <div class="review-modal">
    <div class="review-modal-header">
      <div class="review-modal-title" id="review-modal-title">Invoice Details</div>
      <button class="review-modal-close" onclick="closeReviewModal()">✕</button>
    </div>
    <div class="review-detail-grid" id="review-detail-grid"></div>
    <hr class="review-divider" />
    <div class="review-modal-actions">
      <button class="btn btn-primary" onclick="closeReviewModal()">Close</button>
    </div>
  </div>
</div>

<!-- ════════════════════════════════════
     UPLOAD MODAL — file upload
════════════════════════════════════ -->
<div class="upload-modal-overlay" id="uploadModal" onclick="if(event.target===this)closeUploadModal()">
  <div class="upload-modal">
    <div class="upload-modal-header">
      <div class="upload-modal-title" id="upload-modal-title">Upload Invoice</div>
      <button class="upload-modal-close" onclick="closeUploadModal()">✕</button>
    </div>
    <div class="upload-drop-area" onclick="document.getElementById('upload-file-input').click()">
      <input type="file" id="upload-file-input" accept=".pdf,.png,.jpg,.jpeg" onchange="handleUploadFile(this)" />
      <div class="upload-drop-icon">📎</div>
      <div class="upload-drop-text">Drop your invoice here or <strong>browse files</strong></div>
      <div class="upload-file-name" id="upload-file-name" style="display:none;"></div>
    </div>
    <div class="upload-modal-actions">
      <button class="btn btn-ghost" onclick="closeUploadModal()">Cancel</button>
      <button class="btn btn-primary" onclick="submitUploadModal()">Submit Invoice</button>
    </div>
  </div>
</div>

<!-- ════════════════════════════════════
     NOTIFICATION PANEL — on body, auditor-style
════════════════════════════════════ -->
<div class="notif-panel" id="notif-panel">
  <div class="notif-panel-header">
    <span class="notif-panel-title">Notifications</span>
    <div class="notif-actions">
      <span class="notif-count" id="notif-count">2</span>
      <button class="notif-mark-all" onclick="markAllRead()">Mark all read</button>
    </div>
  </div>
  <div class="notif-list" id="notif-list"></div>
  <div class="notif-footer">
    <button class="notif-footer-btn" onclick="clearAllNotifs()">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3,6 5,6 21,6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>
      Clear all
    </button>
  </div>
</div>

<!-- ════════════════════════════════════
     FLAGGED ITEM EDIT MODAL
════════════════════════════════════ -->
<div class="modal" id="flaggedEditModal">
  <div class="modal-box" style="text-align:left; max-width:520px;">
    <h3 style="margin-bottom:8px;">Resolve Flagged Item</h3>
    <p style="font-size:14px; color:var(--navy-dim); margin-bottom:20px;">Transaction <span id="flagged-edit-txid" style="font-weight:700; color:var(--teal);"></span> — <span id="flagged-edit-reason"></span></p>
    <textarea class="textarea" id="flagged-edit-note" placeholder="Explain the resolution for this flagged item..." style="margin-bottom:18px; min-height:100px;"></textarea>
    <div style="display:flex; gap:12px; justify-content:flex-end;">
      <button class="btn btn-ghost" onclick="closeFlaggedEditModal()">Cancel</button>
      <button class="btn btn-primary" onclick="submitFlaggedResolution()">Mark as Resolved</button>
    </div>
  </div>
</div>

<!-- ════════════════════════════════════
     JAVASCRIPT
════════════════════════════════════ -->
<script>
  /* ── Logo ── */

  /* ══════════════════════════════════
     STATE
  ══════════════════════════════════ */
  let activeTab = 'active';
  let requestSearch = '';
  let editingRequestId = null;
  let currentFlaggedTxId = null;
  let currentViewedRequestId = null;
  let nextRequestCounter = 5;

  let requests = <?= json_encode($requestsForJs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
  let employeeNotifications = <?= json_encode($notificationsForJs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;

  let flaggedTransactions = [];

  /* ══════════════════════════════════
     SIDEBAR
  ══════════════════════════════════ */
  function toggleSidebar() {
    const s = document.getElementById('sidebar');
    const icon = document.getElementById('toggle-icon');
    s.classList.toggle('collapsed');
    icon.innerHTML = s.classList.contains('collapsed')
      ? '<polyline points="9,18 15,12 9,6"/>'
      : '<polyline points="15,18 9,12 15,6"/>';
  }

  /* ══════════════════════════════════
     NAVIGATION
  ══════════════════════════════════ */
  function navigate(section, btn) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    const idMap = { 'overview': 'view-overview', 'requests': 'view-requests', 'blockedPage': 'blockedPage', 'request-detail': 'view-request-detail', 'approved-detail': 'view-approved-detail', 'rejected-detail': 'view-rejected-detail' };
    const targetId = idMap[section] || ('view-' + section);
    const targetView = document.getElementById(targetId);
    if (targetView) targetView.classList.add('active');

    if (btn) btn.classList.add('active');

    const titles = {
      'overview':         'Overview',
      'requests':         'View Fund Request',
      'new-request':      'New Fund Request',
      'blockedPage':      'New Fund Request',
      'request-detail':   'View Fund Request',
      'approved-detail':  'View Fund Request',
      'rejected-detail':  'View Fund Request'
    };
    document.getElementById('page-title').textContent = titles[section] || section;

    if (section === 'overview')      renderOverview();
    if (section === 'requests') {
      renderRequestTables();
    }
    if (section === 'new-request') {
      const activeRequest = requests.find(r => ['Pending', 'Approved', 'Spending', 'Flagged'].includes(r.status) && r.id !== editingRequestId);
      if (activeRequest && !editingRequestId) {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        const blocked = document.getElementById('blockedPage');
        if (blocked) blocked.classList.add('active');
        const blockedMsg = document.getElementById('blocked-request-message');
        if (blockedMsg) {
          if (activeRequest.status === 'Flagged') {
            blockedMsg.textContent = `You currently have a flagged fund request (${activeRequest.project}). The system allows only one active request per employee. Please resolve your flagged request before submitting a new one.`;
          } else {
            blockedMsg.textContent = `You currently have an active fund request (${activeRequest.project}). The system allows only one active request per employee. Please review your existing request before submitting a new one.`;
          }
        }
        document.getElementById('page-title').textContent = 'New Fund Request';
        return;
      }
      if (!editingRequestId) resetForm();

    }
  }

  /* ══════════════════════════════════
     TOAST
  ══════════════════════════════════ */
  function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 5000);
  }

  /* ══════════════════════════════════
     DATE RANGE HELPERS
  ══════════════════════════════════ */
  function getDateRangeValue(id) { return document.getElementById(id).value; }
  function withinRange(dateText, rangeValue) {
    if (rangeValue === 'all') return true;
    const diffDays = Math.floor((new Date() - new Date(dateText)) / 86400000);
    return diffDays <= Number(rangeValue);
  }

  /* ══════════════════════════════════
     BADGE HELPER
  ══════════════════════════════════ */
  function getRequestBadge(status) {
    const map = {
      'Approved':  { cls:'badge-green',  label:'Approved'  },
      'Spending':  { cls:'badge-teal',   label:'Spending'  },
      'Pending':   { cls:'badge-amber',  label:'Pending'   },
      'Cleared':   { cls:'badge-navy',   label:'Cleared'   },
      'Rejected':  { cls:'badge-red',    label:'Rejected'  },
      'Flagged':   { cls:'badge-red',    label:'Flagged'   }
    };
    const s = map[status] || { cls:'badge-navy', label: status };
    return `<span class="badge ${s.cls}"><span class="badge-dot"></span>${s.label}</span>`;
  }

  function getPlainStatus(status) {
    return (status || '').trim();
  }

  function getLatestRequest() {
    if (!Array.isArray(requests) || requests.length === 0) return null;
    return [...requests].sort((a, b) => new Date(b.requestDate) - new Date(a.requestDate))[0];
  }

  function getRequestDeadline(request) {
    if (!request || !request.requestDate) return '—';
    const base = new Date(request.requestDate);
    if (Number.isNaN(base.getTime())) return '—';
    const deadline = new Date(base);
    deadline.setDate(deadline.getDate() + 12);
    return deadline.toISOString().slice(0, 10);
  }

  function renderRequestsPageStatusCard() {
    const statusEl = document.getElementById('requests-page-status-text');
    const statusIconEl = document.getElementById('requests-page-status-icon');
    if (!statusEl || !statusIconEl) return;

    const latest = getLatestRequest();
    if (!latest) {
      statusEl.textContent = 'No Request';
      statusEl.className = 'overview-status-text navy';
      statusIconEl.className = 'overview-card-icon navy';
      return;
    }

    const plainStatus = latest.status === 'Pending' ? 'Pending' : getPlainStatus(latest.status);
    let statusColor = 'navy';
    if (plainStatus === 'Approved') statusColor = 'green';
    else if (plainStatus === 'Spending') statusColor = 'teal';
    else if (plainStatus === 'Pending') statusColor = 'amber';
    else if (plainStatus === 'Flagged') statusColor = 'red';
    else if (plainStatus === 'Cleared') statusColor = 'navy';
    else if (plainStatus === 'Spending / Invoice Pending') statusColor = 'teal';

    statusEl.textContent = plainStatus;
    statusEl.className = 'overview-status-text ' + statusColor;
    statusIconEl.className = 'overview-card-icon ' + statusColor;
  }

  function getOverviewActivity(status, request) {
    const plainStatus = status === 'Pending' ? 'Pending' : getPlainStatus(status);
    const submitted = request.requestDate || '';
    // Derive approximate review and approval dates from the submission date
    function addDays(dateStr, days) {
      if (!dateStr) return '';
      const d = new Date(dateStr);
      d.setDate(d.getDate() + days);
      return d.toISOString().slice(0, 10);
    }
    const reviewDate  = addDays(submitted, 2);
    const approvedDate = addDays(submitted, 5);

    const base = [
      { title: 'Request submitted',       sub: `Your request ${request.id} was submitted successfully.`,         time: submitted   },
      { title: 'Under accountant review', sub: 'The accountant is currently reviewing your request details.',    time: reviewDate  }
    ];
    if (plainStatus === 'Pending') {
      base.push({ title: 'Waiting for approval', sub: 'No action is needed from you until the request is reviewed.', time: 'Pending' });
    } else if (plainStatus === 'Approved') {
      base.push({ title: 'Request approved', sub: 'Your request was approved and is ready for spending and invoice tracking.', time: approvedDate });
    } else if (plainStatus === 'Spending') {
      base.push({ title: 'Request approved', sub: 'Your request was approved and funds are ready for use.', time: approvedDate });
      base.push({ title: 'Spending in progress', sub: 'Card transactions are being recorded against this request.', time: addDays(submitted, 8) });
    } else if (plainStatus === 'Flagged') {
      base.push({ title: 'Transaction flagged', sub: 'A mismatch was detected and you may need to re-upload supporting information.', time: addDays(submitted, 7) });
    } else if (plainStatus === 'Cleared') {
      base.push({ title: 'Issue cleared', sub: 'The previously flagged transaction was reviewed and cleared.', time: addDays(submitted, 10) });
    } else if (plainStatus === 'Spending / Invoice Pending') {
      base.push({ title: 'Invoice pending', sub: 'Your request is active and the system is waiting for invoice upload or validation.', time: approvedDate });
    }
    return base;
  }

  function getNextAction(status) {
    const plainStatus = status === 'Pending' ? 'Pending' : getPlainStatus(status);
    if (plainStatus === 'Pending') {
      return {
        iconClass: 'amber',
        title: 'Wait for approval',
        text: 'Your request is still under review. You do not need to upload anything yet.',
        tags: ['Current status: Pending', 'Deadline visible in request overview']
      };
    }
    if (plainStatus === 'Approved') {
      return {
        iconClass: 'green',
        title: 'Start expense tracking',
        text: 'Use the approved budget carefully and upload the invoice once spending is completed.',
        tags: ['Approved budget ready', 'Invoice will be required']
      };
    }
    if (plainStatus === 'Flagged') {
      return {
        iconClass: 'red',
        title: 'Resolve flagged issue',
        text: 'Review the flagged transaction details and re-upload the correct invoice or explanation.',
        tags: ['Action required', 'Check flagged reason']
      };
    }
    if (plainStatus === 'Cleared') {
      return {
        iconClass: 'navy',
        title: 'Monitor request progress',
        text: 'The issue has been cleared. Keep following the request until it is fully completed.',
        tags: ['No urgent action', 'Stay updated']
      };
    }
    return {
      iconClass: 'amber',
      title: 'Upload invoice',
      text: 'Your request is active. The next expected step is to upload the spending invoice for validation.',
      tags: ['Invoice pending', 'Keep documents ready']
    };
  }

  function renderOverview() {
    const latest = getLatestRequest();
    const statusEl = document.getElementById('overview-request-status');
    const statusIconEl = document.getElementById('overview-request-icon');
    const fundsEl = document.getElementById('overview-funds-status');
    const rowsEl = document.getElementById('overview-table-rows');
    if (!statusEl || !fundsEl || !rowsEl) return;

    const fundsNoteEl = document.getElementById('overview-funds-note');
    const fundsProgressEl = document.getElementById('overview-funds-progress');

    if (!latest) {
      statusEl.textContent = 'No Request';
      statusEl.className = 'overview-status-text navy';
      if (statusIconEl) statusIconEl.className = 'overview-card-icon navy';
      fundsEl.textContent = 'SAR 0';
      if (fundsNoteEl) fundsNoteEl.textContent = 'Left from SAR 0';
      if (fundsProgressEl) fundsProgressEl.style.width = '0%';
      rowsEl.innerHTML = '<div class="empty">No requests available.</div>';

      const activityEl = document.getElementById('recent-activity-list');
      const nextActionEl = document.getElementById('next-action-box');
      if (activityEl) {
        activityEl.innerHTML = `
          <div class="activity-item">
            <div class="activity-dot">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
            </div>
            <div class="activity-main">
              <div class="activity-title">No current request</div>
              <div class="activity-sub">There is no active request in the system right now.</div>
            </div>
            <div class="activity-time">Now</div>
          </div>
        `;
      }
      if (nextActionEl) {
        nextActionEl.innerHTML = `
          <div class="next-action-card">
            <div class="next-action-head">
              <div class="next-action-icon navy">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg>
              </div>
              <div class="next-action-copy">
                <div class="next-action-title">Create a new request</div>
                <div class="next-action-text">Your previous request is no longer in the system. The next appropriate step is to submit a new fund request when needed.</div>
              </div>
            </div>
            <div class="next-action-meta"><span class="badge badge-navy">No active request</span><span class="badge badge-navy">Ready for new submission</span></div>
          </div>
        `;
      }
      return;
    }

    const plainStatus = latest.status === 'Pending' ? 'Pending' : getPlainStatus(latest.status);
    statusEl.textContent = plainStatus;
    statusEl.className = 'overview-status-text';
    let statusColor = 'navy';
    if (plainStatus === 'Approved') statusColor = 'green';
    else if (plainStatus === 'Spending') statusColor = 'teal';
    else if (plainStatus === 'Pending') statusColor = 'amber';
    else if (plainStatus === 'Flagged') statusColor = 'red';
    else if (plainStatus === 'Cleared') statusColor = 'navy';
    else if (plainStatus === 'Spending / Invoice Pending') statusColor = 'teal';
    statusEl.classList.add(statusColor);
    if (statusIconEl) statusIconEl.className = `overview-card-icon ${statusColor}`;

    const totalBudget    = Number(String(latest.amount).replace(/[^\d.]/g, '')) || 0;
    const spentAmount    = latest.spentAmount || 0;
    const remainingFunds = totalBudget - spentAmount;
    const usedPercent    = totalBudget > 0 ? (spentAmount / totalBudget) * 100 : 0;
    fundsEl.textContent = `SAR ${remainingFunds.toLocaleString()}`;
    if (fundsNoteEl) fundsNoteEl.textContent = `Left from SAR ${totalBudget.toLocaleString()}`;
    if (fundsProgressEl) fundsProgressEl.style.width = `${Math.max(0, Math.min(100, usedPercent))}%`;

    rowsEl.innerHTML = `<div class="tbl-row" style="grid-template-columns:110px 1.4fr 140px 130px 120px 100px;">
      <span class="cell mono">${latest.id}</span>
      <span class="cell">${latest.project}</span>
      <span class="cell">${latest.amount}</span>
      <span class="cell">${getRequestBadge(latest.status)}</span>
      <span class="cell muted">${getRequestDeadline(latest)}</span>
      <span class="cell"><button class="btn btn-review" onclick="viewRequestDetail('${latest.id}')">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg> View
      </button></span>
    </div>`;

    const activityEl = document.getElementById('recent-activity-list');
    const nextActionEl = document.getElementById('next-action-box');
    if (activityEl) {
      const activity = getOverviewActivity(latest.status, latest);
      activityEl.innerHTML = activity.map(item => `
        <div class="activity-item">
          <div class="activity-dot">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
          </div>
          <div class="activity-main">
            <div class="activity-title">${item.title}</div>
            <div class="activity-sub">${item.sub}</div>
          </div>
          <div class="activity-time">${item.time}</div>
        </div>
      `).join('');
    }
    if (nextActionEl) {
      const action = getNextAction(latest.status);
      const iconMap = {
        teal: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>',
        green: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="m9 15 2 2 4-4"/></svg>',
        red: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
        navy: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m9 12 2 2 4-4"/></svg>',
        amber: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>'
      };
      nextActionEl.innerHTML = `
        <div class="next-action-card">
          <div class="next-action-head">
            <div class="next-action-icon ${action.iconClass}">${iconMap[action.iconClass] || iconMap.teal}</div>
            <div class="next-action-copy">
              <div class="next-action-title">${action.title}</div>
              <div class="next-action-text">${action.text}</div>
            </div>
          </div>
          <div class="next-action-meta">${action.tags.map(tag => `<span class="badge badge-${action.iconClass === 'navy' ? 'navy' : action.iconClass}">${tag}</span>`).join('')}</div>
        </div>
      `;
    }
  }

  /* ══════════════════════════════════
     COUNTS
  ══════════════════════════════════ */
  function updateCounts() {
    const activeCount  = requests.filter(r => r.status === 'Pending' || r.status === 'Pending').length;
    const invoiceCount = requests.filter(r => r.status === 'Approved' && r.invoiceStatus === 'Pending').length;
    const flaggedCount = flaggedTransactions.filter(f => f.status === 'Flagged').length;
    const activeEl = document.getElementById('active-count');
    const invoiceEl = document.getElementById('invoice-count');
    const flaggedEl = document.getElementById('flagged-count');
    if (activeEl) activeEl.textContent  = activeCount;
    if (invoiceEl) invoiceEl.textContent = invoiceCount;
    if (flaggedEl) flaggedEl.textContent = flaggedCount;
  }

  /* ══════════════════════════════════
     REQUEST TABLES
  ══════════════════════════════════ */
  function switchRequestTab(tab) {
    activeTab = tab;
    document.getElementById('tab-active-btn').classList.toggle('active', tab === 'active');
    document.getElementById('tab-invoice-btn').classList.toggle('active', tab === 'invoice');
    renderRequestTables();
  }

  function searchRequests(value) { requestSearch = value.toLowerCase(); renderRequestTables(); }

  function filterRequests() {
    const range = getDateRangeValue('date-range');
    return requests.filter(r => {
      const matchesRange  = withinRange(r.requestDate, range);
      const target        = [r.id, r.project, r.requester, r.employeeId, r.status].join(' ').toLowerCase();
      const matchesSearch = !requestSearch || target.includes(requestSearch);
      return matchesRange && matchesSearch;
    });
  }

  function renderRequestTables() {
    const wrap = document.getElementById('request-table-wrap');
    renderRequestsPageStatusCard();
    if (!wrap) return;
    if (!requests.length) {
      wrap.innerHTML = '<div class="empty">No fund requests found.</div>';
      return;
    }
    let html = '';
    requests.forEach(function(r) {
      html += `<div class="tbl-row" style="grid-template-columns:110px 1.4fr 140px 130px 120px 100px;">
        <span class="cell mono">${r.id}</span>
        <span class="cell">${r.project}</span>
        <span class="cell">${r.amount}</span>
        <span class="cell">${getRequestBadge(r.status)}</span>
        <span class="cell muted">${getRequestDeadline(r)}</span>
        <span class="cell"><button class="btn btn-review" onclick="viewRequestDetail('${r.id}')">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg> View
        </button></span>
      </div>`;
    });
    wrap.innerHTML = html;
  }

  /* ══════════════════════════════════
     VIEW REQUEST DETAIL
  ══════════════════════════════════ */
  function viewRequestDetail(id) {
    const r = requests.find(x => x.id === id);
    if (!r) return;
    currentViewedRequestId = id;

    const purposeText     = r.purpose || '';
    const descriptionText = r.description || '';

    const grid = document.getElementById('detail-grid-content');
    grid.innerHTML = `
      <div class="detail-label">Project Name</div><div class="detail-value">${r.project}</div>
      <div class="detail-label">Requested Amount</div><div class="detail-value">${r.amount}</div>
      <div class="detail-label">Purpose</div><div class="detail-value">${purposeText}</div>
      <div class="detail-label">Description</div><div class="detail-value">${descriptionText || '—'}</div>
      <div class="detail-label">Category</div><div class="detail-value">${r.category}</div>
      <div class="detail-label">Deadline</div><div class="detail-value">${r.dueDate || '—'}</div>
      <div class="detail-label">Priority</div><div class="detail-value">${r.priority}</div>
      <div class="detail-label">Status</div><div class="detail-value">${getRequestBadge(r.status)}</div>
      <div class="detail-label">Request Date</div><div class="detail-value">${r.requestDate}</div>
    `;

    const budgetNum = Number(String(r.amount).replace(/[^\d.]/g, '')) || 0;
    const spentNum  = r.spentAmount || 0;
    const remaining = budgetNum - spentNum;

    document.getElementById('expense-total-spent').textContent      = `SAR ${spentNum.toLocaleString()}`;
    document.getElementById('expense-requested-budget').textContent  = `Requested Budget: SAR ${budgetNum.toLocaleString()}`;
    document.getElementById('expense-remaining-budget').textContent  = `Remaining Budget: SAR ${remaining.toLocaleString()}`;

    // Render transactions
    const txnHeader = document.getElementById('expense-txn-header');
    const txnBody   = document.getElementById('expense-txn-body');
    const txns = r.transactions || [];
    if (txnHeader) txnHeader.style.display = '';
    if (txnBody) {
      if (txns.length > 0) {
        let txHtml = '';
        // Sort newest transaction date first
        var sorted = txns.slice().sort(function(a, b) { return new Date(b.date) - new Date(a.date); });
        sorted.forEach(function(t) {
          const rawStatus = t.invoiceStatus || 'Not Uploaded';
          const isUploaded = rawStatus === 'Uploaded';
          const isAmountMismatch = rawStatus === 'Mismatch' || rawStatus === 'Amount Mismatch';
          const isOcrInconsistency = rawStatus === 'OCR Inconsistency';
          const isLateInvoice = rawStatus === 'Overdue' || rawStatus === 'Late Invoice Submission';
          const isDuplicateInvoice = rawStatus === 'Duplicate' || rawStatus === 'Duplicate Invoice';
          const isCorrectedInvoiceNeeded = isAmountMismatch || isOcrInconsistency || isDuplicateInvoice;
          var dueText = (isUploaded || isCorrectedInvoiceNeeded) ? 'Submitted' : (t.invoiceDueText || '—');

          var statusCell;
          if (isUploaded) {
            statusCell = '<span class="badge badge-green"><span class="badge-dot"></span>Uploaded</span>';
          } else if (isAmountMismatch) {
            statusCell = '<span class="badge badge-red"><span class="badge-dot"></span>Mismatch</span>';
          } else if (isOcrInconsistency) {
            statusCell = '<span class="badge badge-red"><span class="badge-dot"></span>OCR Inconsistency</span>';
          } else if (isLateInvoice) {
            statusCell = '<span class="badge badge-amber"><span class="badge-dot"></span>Overdue</span>';
          } else if (isDuplicateInvoice) {
            statusCell = '<span class="badge badge-purple" title="' + (t.flagDetails || 'Duplicate invoice detected. Please re-upload the correct invoice.') + '"><span class="badge-dot"></span>Duplicate</span>';
          } else {
            statusCell = '<span class="badge badge-amber"><span class="badge-dot"></span>Not Uploaded</span>';
          }

          var actionCell;
          if (isUploaded) {
            actionCell = '<button class="btn-upload submit-disabled" disabled>' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>' +
              ' Upload</button>';
          } else if (isCorrectedInvoiceNeeded) {
            actionCell = '<button class="btn-upload" onclick="openInvoiceModal(\'' + t.id + '\')">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>' +
              ' Re-upload</button>';
          } else {
            actionCell = '<button class="btn-upload" onclick="openInvoiceModal(\'' + t.id + '\')">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>' +
              ' Upload</button>';
          }

          txHtml += '<div class="tbl-row" style="grid-template-columns:110px 110px 1.2fr 110px 120px 170px 130px;">' +
            '<span class="cell mono">' + t.id + '</span>' +
            '<span class="cell muted">' + t.date + '</span>' +
            '<span class="cell">' + (t.vendor || '—') + '</span>' +
            '<span class="cell">SAR ' + t.amount.toLocaleString() + '</span>' +
            '<span class="cell muted">' + dueText + '</span>' +
            '<span class="cell" style="overflow:visible;">' + statusCell + '</span>' +
            '<span class="cell" style="overflow:visible;">' + actionCell + '</span>' +
            '</div>';
        });
        txnBody.innerHTML = txHtml;
      } else {
        txnBody.innerHTML = '<div class="empty" style="padding:28px 22px;">No transactions available yet. Card transactions will appear once spending begins.</div>';
      }
    }

    // Action buttons
    const actions   = document.getElementById('pending-detail-actions');
    const editBtn   = document.getElementById('edit-request-btn');
    const deleteBtn = document.getElementById('delete-request-btn');
    const isEditable = r.status === 'Pending';
    const isLocked   = r.status === 'Approved' || r.status === 'Spending' || r.status === 'Flagged';
    if (actions) actions.style.display = (isEditable || isLocked) ? 'flex' : 'none';
    if (editBtn)   { editBtn.disabled   = isLocked; editBtn.classList.toggle('submit-disabled',   isLocked); }
    if (deleteBtn) { deleteBtn.disabled = isLocked; deleteBtn.classList.toggle('submit-disabled', isLocked); }
    navigate('request-detail', document.getElementById('nav-requests'));
  }

  /* ══════════════════════════════════
     FORM — SUBMIT / EDIT / DELETE
  ══════════════════════════════════ */
  function updateSubmitButtonState() {
    // no-op: button is always enabled, validation fires on submit
  }

  function setFieldError(inputId, message) {
    var input   = document.getElementById(inputId);
    var errDiv  = document.getElementById('err-' + inputId);
    var errSpan = document.getElementById('err-' + inputId + '-text');
    if (input)   { input.classList.add('input-error'); input.style.animation='none'; input.offsetHeight; input.style.animation='shake .35s ease'; }
    if (errSpan) errSpan.textContent = message;
    if (errDiv)  errDiv.classList.add('visible');
  }

  function clearFieldError(inputId) {
    var input  = document.getElementById(inputId);
    var errDiv = document.getElementById('err-' + inputId);
    if (input)  input.classList.remove('input-error');
    if (errDiv) errDiv.classList.remove('visible');
  }

  function clearFormErrors() {
    ['projectName','requestedAmount','purpose','description','category','deadline'].forEach(clearFieldError);
  }

  // Clear error on input — mirrors login behaviour
  ['projectName','requestedAmount','purpose','description','category','deadline'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('input', function() { clearFieldError(id); });
  });

  function submitRequest(event) {
    event.preventDefault();
    clearFormErrors();

    const activeRequest = requests.find(r => ['Pending','Approved','Spending','Flagged','Ready to Close'].includes(r.status) && r.id !== editingRequestId);
    if (!editingRequestId && activeRequest) {
      const blockedMsg = document.getElementById('blocked-request-message');
      if (blockedMsg) {
        if (activeRequest.status === 'Flagged') {
          blockedMsg.textContent = `You currently have a flagged fund request (${activeRequest.project}). The system allows only one active request per employee. Please resolve your flagged request before submitting a new one.`;
        } else {
          blockedMsg.textContent = `You currently have an active fund request (${activeRequest.project}). The system allows only one active request per employee. Please review your existing request before submitting a new one.`;
        }
      }
      navigate('blockedPage', null);
      return;
    }

    const project     = document.getElementById('projectName').value.trim();
    const amountRaw   = document.getElementById('requestedAmount').value.trim();
    const purpose     = document.getElementById('purpose').value.trim();
    const description = document.getElementById('description').value.trim();
    const category    = document.getElementById('category').value.trim();
    const deadline    = document.getElementById('deadline').value;
    const priority    = document.querySelector('input[name="priority"]:checked').value;

    let hasError = false;
    if (!project)    { setFieldError('projectName',     'Project name is required.'); hasError = true; }
    if (!amountRaw)  { setFieldError('requestedAmount', 'Requested amount is required.'); hasError = true; }
    else if (!/^\d+(\.\d+)?$/.test(amountRaw)) { setFieldError('requestedAmount', 'Amount must be numbers only (e.g. 5000 or 5000.50).'); hasError = true; }
    if (!purpose)    { setFieldError('purpose',         'Purpose is required.'); hasError = true; }
    if (!description){ setFieldError('description',     'Description is required.'); hasError = true; }
    if (!category)   { setFieldError('category',        'Category is required.'); hasError = true; }
    if (!deadline)   { setFieldError('deadline',        'Please select a deadline date.'); hasError = true; }
    if (hasError) return;

    const fd = new FormData();
    fd.append('action', editingRequestId ? 'update_request' : 'create_request');
    if (editingRequestId) fd.append('request_code', editingRequestId);
    fd.append('project_name', project);
    fd.append('requested_amount', amountRaw);
    fd.append('purpose', purpose);
    fd.append('description', description);
    fd.append('category', category);
    fd.append('deadline', deadline);
    fd.append('priority', priority);

    fetch('action.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(data => {
        if (!data.ok) { showToast(data.message || 'Request could not be saved.'); return; }
        showToast(data.message || 'Request saved successfully.');
        editingRequestId = null;
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      })
      .catch(() => showToast('Server error while saving request'));
  }

  function editRequest(id) {
    const target = requests.find(r => r.id === id);
    if (!target) return;
    editingRequestId = id;
    document.getElementById('projectName').value = target.project;
    document.getElementById('requestedAmount').value = target.amount ? target.amount.replace(/[^0-9.]/g,'') : '';
    document.getElementById('purpose').value = target.purpose || '';
    document.getElementById('description').value = target.description || '';
    document.getElementById('category').value = target.category;
    document.getElementById('deadline').value = target.dueDate || '';
    document.querySelectorAll('input[name="priority"]').forEach(r => { r.checked = r.value === target.priority; });
    clearFormErrors();
    navigate('new-request', document.getElementById('nav-new-request'));
  }

  function deleteRequestById(id) {
    requests = requests.filter(r => r.id !== id);
    if (currentViewedRequestId === id) currentViewedRequestId = null;
    if (editingRequestId === id) { editingRequestId = null; resetForm(); }
    renderOverview();
    updateCounts();
    renderRequestTables();
    showToast('Request deleted successfully');
  }

  function deleteViewedRequest() {
    if (!currentViewedRequestId) return;
    const fd = new FormData();
    fd.append('action', 'delete_request');
    fd.append('request_code', currentViewedRequestId);
    fetch('action.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(data => {
        if (!data.ok) { showToast(data.message || 'Delete failed'); return; }
        showToast(data.message || 'Request deleted successfully');
        window.location.reload();
      })
      .catch(() => showToast('Server error while deleting request'));
    return;
    const id = currentViewedRequestId;
    requests = requests.filter(r => r.id !== id);
    currentViewedRequestId = null;
    if (editingRequestId === id) { editingRequestId = null; resetForm(); }
    renderOverview();
    updateCounts();
    renderRequestTables();
    showToast('Request deleted successfully');
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const navRequests = document.getElementById('nav-requests');
    if (navRequests) navRequests.classList.add('active');
    document.getElementById('page-title').textContent = 'View Fund Request';
    const view = document.getElementById('view-requests');
    if (view) view.classList.add('active');
  }

  function resetForm() {
    editingRequestId = null;
    document.getElementById('request-form').reset();
    document.querySelector('input[name="priority"][value="High"]').checked = true;
    if (typeof clearFormErrors === 'function') clearFormErrors();
  }

  /* ══════════════════════════════════
     LOGOUT MODAL
  ══════════════════════════════════ */
  /* ══════════════════════════════════
     INVOICE UPLOAD MODAL
  ══════════════════════════════════ */
  var currentUploadTxnId = null;

  function openInvoiceModal(txnId) {
    currentUploadTxnId = txnId;
    document.getElementById('upload-modal-txn-id').textContent = txnId;
    var fn = document.getElementById('invoice-file-name');
    if (fn) { fn.style.display = 'none'; fn.textContent = ''; }
    document.getElementById('invoice-file-input').value = '';
    document.getElementById('invoice-upload-modal').style.display = 'flex';
  }

  function closeInvoiceModal() {
    document.getElementById('invoice-upload-modal').style.display = 'none';
    currentUploadTxnId = null;
  }

  function handleInvoiceFileSelect(input) {
    if (input.files && input.files[0]) {
      var nameEl = document.getElementById('invoice-file-name');
      if (!nameEl) nameEl = document.getElementById('upload-file-name');
      if (nameEl) {
        nameEl.textContent = '📄 ' + input.files[0].name;
        nameEl.style.display = 'block';
      }
    }
  }

  function handleInvoiceDrop(event) {
    event.preventDefault();
    var zone = document.getElementById('upload-drop-zone');
    zone.style.borderColor = 'rgba(31,34,71,.15)';
    zone.style.background = 'rgba(241,240,236,.4)';
    var files = event.dataTransfer.files;
    if (files && files[0]) {
      var nameEl = document.getElementById('upload-file-name');
      nameEl.textContent = '📄 ' + files[0].name;
      nameEl.style.display = 'block';
      // Assign to file input for consistency
      var dt = new DataTransfer();
      dt.items.add(files[0]);
      document.getElementById('invoice-file-input').files = dt.files;
    }
  }

  function submitInvoiceUpload() {
    var fileInput = document.getElementById('invoice-file-input');
    console.log('submitInvoiceUpload called, files:', fileInput ? fileInput.files.length : 'no input', 'txnId:', currentUploadTxnId);
    if (!fileInput || !fileInput.files || !fileInput.files[0]) {
      alert('Please select an invoice file first.');
      return;
    }
    var fd = new FormData();
    fd.append('action', 'upload_invoice');
    fd.append('transaction_code', currentUploadTxnId);
    fd.append('invoice_file', fileInput.files[0]);
    // Prevent multiple submissions
    var submitBtn = document.querySelector('#invoice-upload-modal .btn-primary');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = '⏳ Processing OCR... please wait';
    }
    console.log('Sending to employee_action.php, txn:', currentUploadTxnId);
    fetch('action.php', { method: 'POST', body: fd })
      .then(r => { console.log('HTTP status:', r.status); return r.text(); })
      .then(text => {
        console.log('Response:', text);
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Submit Invoice'; }
        try {
          var data = JSON.parse(text);
          if (!data.success) { showToast(data.message || 'Upload failed'); return; }
          showToast(data.message || 'Invoice uploaded successfully');
          closeUploadModal();
          closeInvoiceModal();
          setTimeout(() => { window.location.reload(); }, 1200);
        } catch(e) {
          showToast('Upload processed - refreshing...');
          closeUploadModal();
          closeInvoiceModal();
          setTimeout(() => { window.location.reload(); }, 1200);
        }
      })
      .catch(err => {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Submit Invoice'; }
        showToast('Error: ' + err);
      });
  }

  function openLogoutModal()        { document.getElementById('logout-modal').classList.add('open'); }
  function closeLogoutModal(event)  { if (event.target.id === 'logout-modal') closeLogoutModalDirect(); }
  function closeLogoutModalDirect() { document.getElementById('logout-modal').classList.remove('open'); }
  function confirmLogout()          { window.location.href = '../logout.php'; }

  /* ══════════════════════════════════
     CONFIRM CLOSE REQUEST MODAL
  ══════════════════════════════════ */
  function tryCloseRequest() {
    const chk1 = document.getElementById('chk1').checked;
    const chk2 = document.getElementById('chk2').checked;
    const chk3 = document.getElementById('chk3').checked;
    if (!chk1 || !chk2 || !chk3) {
      showToast('Please confirm all closure requirements first');
      return;
    }
    document.getElementById('confirmModal').classList.add('open');
  }
  function closeConfirmModal() { document.getElementById('confirmModal').classList.remove('open'); }
  function confirmCloseRequest() {
    closeConfirmModal();
    showToast('Request has been successfully closed');
    document.getElementById('chk1').checked = false;
    document.getElementById('chk2').checked = false;
    document.getElementById('chk3').checked = false;
    document.getElementById('accountant-comment').value = '';
    navigate('requests', document.getElementById('nav-requests'));
  }

  /* ══════════════════════════════════
     REVIEW MODAL — details only
  ══════════════════════════════════ */
  function openReviewModal(invId, txId, amount, status, description) {
    document.getElementById('review-modal-title').textContent = 'Invoice ' + invId;
    document.getElementById('review-detail-grid').innerHTML = `
      <div class="review-label">Invoice ID</div><div class="review-value" style="font-family:'IBM Plex Mono',monospace;font-size:13px;font-weight:600;color:var(--teal);">${invId}</div>
      <div class="review-label">Transaction ID</div><div class="review-value" style="font-family:'IBM Plex Mono',monospace;font-size:13px;font-weight:600;color:var(--teal);">${txId}</div>
      <div class="review-label">Amount</div><div class="review-value"><strong>${amount}</strong></div>
      <div class="review-label">Description</div><div class="review-value">${description}</div>
      <div class="review-label">Status</div><div class="review-value"><span class="badge ${status === 'Submitting' ? 'badge-green' : 'badge-amber'}">${status}</span></div>
    `;
    document.getElementById('reviewModal').classList.add('open');
  }
  function closeReviewModal() { document.getElementById('reviewModal').classList.remove('open'); }

  /* ══════════════════════════════════
     UPLOAD MODAL
  ══════════════════════════════════ */
  function viewUploadedInvoice(txnId) {
    const r = requests.find(function(x) { return x.id === currentViewedRequestId; });
    const t = r && r.transactions ? r.transactions.find(function(item) { return item.id === txnId; }) : null;
    if (t && t.invoiceFile) { window.open(t.invoiceFile, '_blank'); }
    else { showToast('Invoice is marked as uploaded. File preview is not available.'); }
  }

  function openUploadModal(invId, txId, amount, description) {
    document.getElementById('upload-modal-title').textContent = 'Upload Invoice — ' + invId;
    document.getElementById('upload-file-input').value = '';
    const fn = document.getElementById('upload-file-name');
    fn.style.display = 'none'; fn.textContent = '';
    document.getElementById('uploadModal').classList.add('open');
  }
  function closeUploadModal() { document.getElementById('uploadModal').classList.remove('open'); }
  function handleUploadFile(input) {
    if (input.files && input.files[0]) {
      const el = document.getElementById('upload-file-name');
      el.textContent = '✓ ' + input.files[0].name;
      el.style.display = 'block';
    }
  }
  function submitUploadModal() {
    const f = document.getElementById('upload-file-input');
    if (!f.files || !f.files[0]) { showToast('Please select a file to upload'); return; }
    if (!currentUploadTxnId) { showToast('No transaction selected'); return; }
    var fd = new FormData();
    fd.append('action', 'upload_invoice');
    fd.append('transaction_code', currentUploadTxnId);
    fd.append('invoice_file', f.files[0]);
    var btn = document.querySelector('#uploadModal .btn-primary');
    if (btn) { btn.disabled = true; btn.textContent = '⏳ Processing...'; }
    fetch('action.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(data => {
        if (btn) { btn.disabled = false; btn.textContent = 'Submit Invoice'; }
        if (!data.success) { showToast(data.message || 'Upload failed'); return; }
        closeUploadModal();
        showToast(data.message || 'Invoice uploaded successfully');
        setTimeout(() => { window.location.reload(); }, 1200);
      })
      .catch(() => {
        if (btn) { btn.disabled = false; btn.textContent = 'Submit Invoice'; }
        closeUploadModal();
        showToast('Upload processed - refreshing...');
        setTimeout(() => { window.location.reload(); }, 1200);
      });
  }

  /* ══════════════════════════════════
     NOTIFICATION PANEL — database-driven
  ══════════════════════════════════ */
  var notifIconMap = {
    submitted: { bg:'var(--teal-dim)',  color:'var(--teal)',  path:'<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>' },
    deadline:  { bg:'var(--amber-dim)', color:'var(--amber)', path:'<circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/>' },
    approved:  { bg:'var(--green-dim)', color:'var(--green)', path:'<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/>' },
    flagged:   { bg:'var(--red-dim)',   color:'var(--red)',   path:'<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>' },
    rejected:  { bg:'var(--red-dim)',   color:'var(--red)',   path:'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>' },
    cleared:   { bg:'var(--navy-faint)', color:'var(--navy)', path:'<path d="M20 6 9 17l-5-5"/><path d="M21 12a9 9 0 1 1-9-9"/>' }
  };

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>"']/g, function(ch) {
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
    });
  }

  function postNotifAction(action, extra) {
    var fd = new FormData();
    fd.append('action', action);
    if (extra) Object.keys(extra).forEach(function(k){ fd.append(k, extra[k]); });
    return fetch('action.php', { method:'POST', body:fd }).then(function(r){ return r.json(); });
  }

  function renderNotifications() {
    var unread = employeeNotifications.filter(function(n){ return !n.read; });
    var dot = document.getElementById('notif-dot');
    var cnt = document.getElementById('notif-count');
    if (dot) dot.style.display = unread.length ? '' : 'none';
    if (cnt) { cnt.textContent = unread.length; cnt.style.display = unread.length ? '' : 'none'; }
    var list = document.getElementById('notif-list');
    if (!list) return;
    if (!employeeNotifications.length) { list.innerHTML = '<div class="notif-empty">No notifications</div>'; return; }
    var html = '';
    employeeNotifications.forEach(function(n) {
      var ic = notifIconMap[n.type] || notifIconMap.submitted;
      var uc = n.read ? '' : ' unread';
      var ud  = n.read ? '' : '<div class="notif-unread-dot"></div>';
      var timeLabel = (n.dateLabel || 'Today') + ', ' + (n.time || '');
      html += '<div class="notif-item'+uc+'" style="cursor:pointer;" onclick="readNotif('+n.id+')">';
      html += '<div class="notif-icon" style="background:'+ic.bg+';color:'+ic.color+'">';
      html += '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+ic.path+'</svg>';
      html += '</div>';
      html += '<div class="notif-body">';
      html += '<div class="notif-msg">'+escapeHtml(n.msg)+'</div>';
      html += '<div class="notif-time">'+escapeHtml(timeLabel)+'</div>';
      html += '</div>';
      html += ud;
      html += '</div>';
    });
    list.innerHTML = html;
  }
  function toggleNotifPanel() {
    var panel = document.getElementById('notif-panel');
    var btn   = document.getElementById('notif-btn');
    var rect  = btn.getBoundingClientRect();
    panel.style.top   = (rect.bottom + 10) + 'px';
    panel.style.right = '28px';
    panel.classList.toggle('open');
  }
  function readNotif(id) {
    employeeNotifications.forEach(function(n){ if(n.id===id) n.read=true; });
    renderNotifications();
    postNotifAction('mark_notification_read', {notification_id:id}).catch(function(){});
  }
  function markAllRead() {
    employeeNotifications.forEach(function(n){ n.read=true; });
    renderNotifications();
    postNotifAction('mark_all_notifications_read').catch(function(){});
  }
  function clearAllNotifs() {
    employeeNotifications = [];
    renderNotifications();
    document.getElementById('notif-panel').classList.remove('open');
    postNotifAction('clear_notifications').catch(function(){});
  }

  /* ══════════════════════════════════
     FLAGGED ITEM EDIT MODAL
  ══════════════════════════════════ */
  function openFlaggedEditModal(txId, reason) {
    currentFlaggedTxId = txId;
    document.getElementById('flagged-edit-txid').textContent = txId;
    document.getElementById('flagged-edit-reason').textContent = reason;
    document.getElementById('flagged-edit-note').value = '';
    document.getElementById('flaggedEditModal').classList.add('open');
  }
  function closeFlaggedEditModal() { document.getElementById('flaggedEditModal').classList.remove('open'); }
  function submitFlaggedResolution() {
    const note = document.getElementById('flagged-edit-note').value.trim();
    if (!note) { showToast('Please provide a resolution explanation'); return; }
    const statusEl = document.getElementById('flagged-status-' + currentFlaggedTxId);
    if (statusEl) {
      statusEl.className = 'badge badge-green';
      statusEl.textContent = 'Resolved';
    }
    closeFlaggedEditModal();
    showToast('Flagged item marked as resolved');
  }

  /* ══════════════════════════════════
     INIT
  ══════════════════════════════════ */
  updateCounts();
  renderOverview();
  renderRequestTables();
  renderNotifications();

  /* Close notif panel when clicking outside */
  document.addEventListener('click', function(e) {
    var panel = document.getElementById('notif-panel');
    var btn   = document.getElementById('notif-btn');
    if (panel && btn && !panel.contains(e.target) && !btn.contains(e.target)) {
      panel.classList.remove('open');
    }
  });
</script>

<!-- INVOICE UPLOAD MODAL -->
<div id="invoice-upload-modal" style="display:none;position:fixed;inset:0;z-index:10000;background:rgba(31,34,71,.5);backdrop-filter:blur(4px);align-items:center;justify-content:center;" onclick="if(event.target===this)closeInvoiceModal()">
  <div style="background:#fff;border-radius:16px;width:90%;max-width:480px;overflow:hidden;box-shadow:0 24px 64px rgba(31,34,71,.22);">
    <div style="background:var(--navy);padding:20px 24px;display:flex;align-items:center;justify-content:space-between;">
      <div>
        <div style="font-family:'DM Serif Display',serif;font-size:18px;color:#fff;">Upload Invoice</div>
        <div style="font-size:12px;color:rgba(255,255,255,.45);margin-top:3px;font-family:'IBM Plex Mono',monospace;" id="upload-modal-txn-id">TXN-0000</div>
      </div>
      <button onclick="closeInvoiceModal()" style="width:28px;height:28px;border-radius:7px;background:rgba(255,255,255,.10);border:none;color:rgba(255,255,255,.7);cursor:pointer;display:flex;align-items:center;justify-content:center;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div style="padding:24px;">
      <div style="border:2px dashed rgba(31,34,71,.15);border-radius:12px;padding:36px 24px;text-align:center;background:rgba(241,240,236,.4);cursor:pointer;transition:all .2s;" id="upload-drop-zone" onclick="document.getElementById('invoice-file-input').click()" ondragover="event.preventDefault();this.style.borderColor='var(--teal)';this.style.background='rgba(0,151,178,.04)'" ondragleave="this.style.borderColor='rgba(31,34,71,.15)';this.style.background='rgba(241,240,236,.4)'" ondrop="handleInvoiceDrop(event)">
        <div style="width:44px;height:44px;border-radius:12px;background:var(--teal-dim);color:var(--teal);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        </div>
        <div style="font-size:14px;font-weight:600;color:var(--navy);margin-bottom:4px;">Click to upload or drag & drop</div>
        <div style="font-size:12px;color:var(--navy-dim);">PDF, JPG, PNG — max 10MB</div>
        <div id="upload-file-name" style="margin-top:10px;font-size:12.5px;font-weight:600;color:var(--teal);display:none;"></div>
      </div>
      <div id="invoice-file-name" style="display:none;font-size:13px;color:#0097b2;font-weight:600;margin-top:8px;text-align:center;"></div>
      <input type="file" id="invoice-file-input" accept=".pdf,.jpg,.jpeg,.png" style="display:none;" onchange="handleInvoiceFileSelect(this)"/>
      <div style="display:flex;gap:10px;margin-top:18px;">
        <button type="button" onclick="submitInvoiceUpload()" class="btn btn-primary" style="flex:1;padding:11px;">Submit Invoice</button>
        <button type="button" onclick="closeInvoiceModal()" class="btn btn-ghost" style="padding:11px 18px;">Cancel</button>
      </div>
    </div>
  </div>
</div>
</body>
</html>
