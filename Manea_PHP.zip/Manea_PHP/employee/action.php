<?php
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$user = require_employee($pdo);
$action = $_POST['action'] ?? '';

function parse_request_id(string $code): int {
    if (preg_match('/(\d+)$/', $code, $m)) return (int)$m[1];
    return 0;
}
function parse_txn_id(string $code): int {
    if (preg_match('/(\d+)$/', $code, $m)) return (int)$m[1];
    return 0;
}

function add_employee_notification(PDO $pdo, int $userId, string $type, string $message): void {
    $allowed = ['REQUEST_APPROVED','REQUEST_REJECTED','FLAGGED_TRANSACTION','ACCOUNT_CLEARED'];
    if (!in_array($type, $allowed, true)) $type = 'REQUEST_APPROVED';
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, type, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
    $stmt->execute([$userId, $type, $message]);
}

try {
    if ($action === 'create_request') {
        $active = $pdo->prepare("\n            SELECT COUNT(*)\n            FROM fund_requests fr\n            WHERE fr.employee_id = ?\n              AND fr.status IN ('PENDING','APPROVED','ACTIVE','READY_TO_CLOSE')\n        ");
        $active->execute([$user['user_id']]);
        if ((int)$active->fetchColumn() > 0) json_response(false, 'You already have an active request.');

        $flagged = $pdo->prepare("\n            SELECT COUNT(*)\n            FROM flags f\n            JOIN fund_requests fr ON fr.fund_request_id = f.fund_request_id\n            WHERE fr.employee_id = ? AND f.status = 'OPEN'\n        ");
        $flagged->execute([$user['user_id']]);
        if ((int)$flagged->fetchColumn() > 0) json_response(false, 'You currently have a flagged fund request. Please resolve it before submitting a new one.');

        $project = trim($_POST['project_name'] ?? '');
        $amount = (float)($_POST['requested_amount'] ?? 0);
        $purpose = trim($_POST['purpose'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $deadline = $_POST['deadline'] ?? '';
        $priority = strtoupper($_POST['priority'] ?? 'MEDIUM');
        if (!in_array($priority, ['LOW','MEDIUM','HIGH'], true)) $priority = 'MEDIUM';

        if ($project === '' || $amount <= 0 || $purpose === '' || $description === '' || $category === '' || $deadline === '') {
            json_response(false, 'Please complete all required fields.');
        }

        $stmt = $pdo->prepare("\n            INSERT INTO fund_requests\n            (employee_id, request_title, request_type, priority, status, amount_requested, purpose, description, project_due_date)\n            VALUES (?, ?, ?, ?, 'PENDING', ?, ?, ?, ?)\n        ");
        $stmt->execute([$user['user_id'], $project, $category, $priority, $amount, $purpose, $description, $deadline]);

        add_employee_notification($pdo, (int)$user['user_id'], 'REQUEST_APPROVED', 'Request submitted successfully. Submission status: Sent for review.');
        json_response(true, 'Fund request submitted successfully.');
    }

    if ($action === 'update_request') {
        $requestId = parse_request_id($_POST['request_code'] ?? '');
        $stmt = $pdo->prepare("SELECT * FROM fund_requests WHERE fund_request_id = ? AND employee_id = ? LIMIT 1");
        $stmt->execute([$requestId, $user['user_id']]);
        $request = $stmt->fetch();
        if (!$request) json_response(false, 'Request not found.');
        if ($request['status'] !== 'PENDING') json_response(false, 'Only pending requests can be edited.');

        $project = trim($_POST['project_name'] ?? '');
        $amount = (float)($_POST['requested_amount'] ?? 0);
        $purpose = trim($_POST['purpose'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $deadline = $_POST['deadline'] ?? '';
        $priority = strtoupper($_POST['priority'] ?? 'MEDIUM');
        if (!in_array($priority, ['LOW','MEDIUM','HIGH'], true)) $priority = 'MEDIUM';

        if ($project === '' || $amount <= 0 || $purpose === '' || $description === '' || $category === '' || $deadline === '') {
            json_response(false, 'Please complete all required fields.');
        }

        $upd = $pdo->prepare("\n            UPDATE fund_requests\n            SET request_title = ?, request_type = ?, priority = ?, amount_requested = ?, purpose = ?, description = ?, project_due_date = ?\n            WHERE fund_request_id = ? AND employee_id = ?\n        ");
        $upd->execute([$project, $category, $priority, $amount, $purpose, $description, $deadline, $requestId, $user['user_id']]);
        add_employee_notification($pdo, (int)$user['user_id'], 'REQUEST_APPROVED', 'Request updated successfully. Submission status: Sent for review.');
        json_response(true, 'Request updated successfully.');
    }

    if ($action === 'delete_request') {
        $requestId = parse_request_id($_POST['request_code'] ?? '');
        $stmt = $pdo->prepare("SELECT * FROM fund_requests WHERE fund_request_id = ? AND employee_id = ? LIMIT 1");
        $stmt->execute([$requestId, $user['user_id']]);
        $request = $stmt->fetch();
        if (!$request) json_response(false, 'Request not found.');
        if ($request['status'] !== 'PENDING') json_response(false, 'Only pending requests can be deleted.');

        $upd = $pdo->prepare("UPDATE fund_requests SET status = 'CANCELED' WHERE fund_request_id = ? AND employee_id = ?");
        $upd->execute([$requestId, $user['user_id']]);
        add_employee_notification($pdo, (int)$user['user_id'], 'REQUEST_REJECTED', 'Request canceled successfully. Submission status: Canceled by employee.');
        json_response(true, 'Request canceled successfully.');
    }

    if ($action === 'upload_invoice') {
        set_time_limit(300); // Allow 5 minutes for OCR processing
        $txnId = parse_txn_id($_POST['transaction_code'] ?? '');
        if (!$txnId) json_response(false, 'Transaction not found.');
        if (!isset($_FILES['invoice_file']) || $_FILES['invoice_file']['error'] !== UPLOAD_ERR_OK)
            json_response(false, 'Please select a valid invoice file.');

        $stmt = $pdo->prepare("
            SELECT t.*, fr.employee_id, fr.fund_request_id
            FROM transactions t
            JOIN fund_requests fr ON fr.fund_request_id = t.fund_request_id
            WHERE t.transaction_id = ? AND fr.employee_id = ?
            LIMIT 1
        ");
        $stmt->execute([$txnId, $user['user_id']]);
        $txn = $stmt->fetch();
        if (!$txn) json_response(false, 'Transaction not found.');

        $allowed = ['pdf','png','jpg','jpeg'];
        $ext = strtolower(pathinfo($_FILES['invoice_file']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed, true))
            json_response(false, 'Only PDF, PNG, JPG, and JPEG invoices are allowed.');

        // Save file to disk
        $uploadDir = __DIR__ . '/../../uploads/invoices/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $safeName     = 'INV_TXN_' . $txnId . '_' . date('YmdHis') . '.' . $ext;
        $fullPath     = $uploadDir . $safeName;
        $relativePath = 'uploads/invoices/' . $safeName;
        if (!move_uploaded_file($_FILES['invoice_file']['tmp_name'], $fullPath))
            json_response(false, 'Could not save uploaded invoice.');

        // ── Call Flask OCR API ──────────────────────────────────────────────
        // Flask runs OCR → extracts fields → saves to invoices table
        // → runs matching → runs flagging → returns invoice_id + status
        $invoiceId  = null;
        $ocrSuccess = false;
        $ocrResult  = [];

        try {
            // Send to Flask OCR — use short timeout so employee gets instant response
            // Flask saves invoice + runs OCR + matching in background
            $ch = curl_init('http://localhost:5000/api/invoices/upload');
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, [
                'fund_request_id' => $txn['fund_request_id'],
                'transaction_id'  => $txnId,
                'employee_id'     => $user['user_id'],
                'file'            => new CURLFile(
                                        $fullPath,
                                        mime_content_type($fullPath),
                                        $_FILES['invoice_file']['name']
                                    ),
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 180); // Wait up to 3 minutes for OCR
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); // But fail fast if Flask is down
            $raw       = curl_exec($ch);
            $curlError = curl_error($ch);
            $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($curlError) throw new Exception('Flask connection failed: ' . $curlError);
            if ($httpCode !== 201) throw new Exception('Flask returned HTTP ' . $httpCode);

            $ocrResult = json_decode($raw, true) ?? [];
            if (!empty($ocrResult['invoice_id'])) {
                $invoiceId  = (int)$ocrResult['invoice_id'];
                $ocrSuccess = true;
            }
        } catch (Throwable $e) {
            error_log('OCR API error: ' . $e->getMessage());
        }

        // ── Fallback: save invoice manually if OCR failed ───────────────────
        if (!$ocrSuccess) {
            $ins = $pdo->prepare("
                INSERT INTO invoices
                    (fund_request_id, employee_id, invoice_number, invoice_date,
                     invoice_amount, invoice_currency, converted_amount_base,
                     base_currency, file_path, file_name, verification_status)
                VALUES (?, ?, ?, CURDATE(), ?, 'SAR', ?, 'SAR', ?, ?, 'PENDING')
            ");
            $ins->execute([
                $txn['fund_request_id'],
                $user['user_id'],
                'INV-' . $txnId . '-' . date('YmdHis'),
                (float)$txn['amount'],
                (float)$txn['amount'],
                $relativePath,
                $safeName,
            ]);
            $invoiceId = (int)$pdo->lastInsertId();

            $pdo->prepare("INSERT IGNORE INTO invoice_transactions (invoice_id, transaction_id) VALUES (?, ?)")
                ->execute([$invoiceId, $txnId]);
        }

        // ── Notify employee based on OCR result ─────────────────────────────
        $flagReason = $ocrResult['flag_reason'] ?? null;

        if ($flagReason === 'DUPLICATE_INVOICE') {
            add_employee_notification($pdo, (int)$user['user_id'], 'FLAGGED_TRANSACTION',
                'Invoice flagged as duplicate. The same invoice was already submitted. Please re-upload the correct invoice.');
            json_response(true, 'Invoice uploaded but flagged as duplicate.', ['duplicate' => true]);
        }

        if ($flagReason === 'AI_AMOUNT_MISMATCH') {
            add_employee_notification($pdo, (int)$user['user_id'], 'FLAGGED_TRANSACTION',
                'Invoice amount does not match the transaction amount. The auditor has been notified.');
            json_response(true, 'Invoice uploaded but amount mismatch detected.', ['mismatch' => true]);
        }

        // Success — resolve any existing overdue flags for this transaction
        $pdo->prepare("UPDATE flags SET status='RESOLVED', resolved_at=NOW() WHERE transaction_id=? AND flag_reason='OVERDUE_TRANSACTION' AND status='OPEN'")
            ->execute([$txnId]);

        add_employee_notification($pdo, (int)$user['user_id'], 'REQUEST_APPROVED',
            'Invoice uploaded successfully and sent for OCR verification.');
        json_response(true, 'Invoice uploaded successfully.', ['invoice_id' => $invoiceId]);
    }


    if ($action === 'mark_notification_read') {
        $notificationId = (int)($_POST['notification_id'] ?? 0);
        if ($notificationId > 0) {
            $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?");
            $stmt->execute([$notificationId, $user['user_id']]);
        }
        json_response(true, 'Notification marked as read.');
    }

    if ($action === 'mark_all_notifications_read') {
        $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->execute([$user['user_id']]);
        json_response(true, 'All notifications marked as read.');
    }

    if ($action === 'clear_notifications') {
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ?");
        $stmt->execute([$user['user_id']]);
        json_response(true, 'Notifications cleared.');
    }

    json_response(false, 'Unknown action.');
} catch (Throwable $e) {
    json_response(false, 'Server error: ' . $e->getMessage());
}
?>
