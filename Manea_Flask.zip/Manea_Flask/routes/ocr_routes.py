"""
OCR API Routes

Defines the single public endpoint consumed by the Manea frontend:

    POST /ocr
        Content-Type : multipart/form-data
        Field        : image  (the invoice image file)

        Returns 200  : { raw_text, extracted_data: { amount, date, currency, invoice_number } }
        Returns 400  : missing or empty file field / invalid image
        Returns 415  : unsupported file type
        Returns 500  : OCR engine error / unexpected failure

Design note:
    The server NEVER crashes — every exception is caught, logged with a full
    traceback, and returned as a structured JSON error so the Streamlit UI
    can display a clear message instead of a timeout.
"""

import logging
import traceback

from flask import Blueprint, current_app, jsonify, request

from services.extractor import extract_invoice_data
from services.ocr_service import run_ocr_with_details

logger = logging.getLogger(__name__)

# Blueprint with no url_prefix → endpoint lives at /ocr
ocr_bp = Blueprint("ocr", __name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _is_allowed_file(filename: str) -> bool:
    """Return True if the filename has an extension the service accepts."""
    allowed = current_app.config["ALLOWED_EXTENSIONS"]
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed


def _error(message: str, detail: str = "", status: int = 500):
    """Return a consistent JSON error response and log it."""
    logger.error("OCR route error [%d]: %s | %s", status, message, detail)
    body = {"error": message}
    if detail:
        body["detail"] = detail
    return jsonify(body), status


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@ocr_bp.route("/ocr", methods=["POST"])
def ocr_invoice():
    """
    POST /ocr — process an uploaded invoice image or PDF.

    Workflow:
        1. Validate the uploaded file (presence, name, extension).
        2. Run OCR to extract raw text.
        3. Run extractor to identify structured fields.
        4. Return a structured JSON payload.

    The entire handler is wrapped in a broad try/except so the Flask server
    NEVER crashes — all failures return JSON with a clear error message.
    """
    try:

        # ------------------------------------------------------------------
        # Step 1 — Validate input
        # ------------------------------------------------------------------

        if "image" not in request.files:
            return _error("Missing 'image' field in form-data.", status=400)

        file = request.files["image"]

        if not file or file.filename == "":
            return _error("No file selected — 'image' field is empty.", status=400)

        if not _is_allowed_file(file.filename):
            allowed = sorted(current_app.config["ALLOWED_EXTENSIONS"])
            return jsonify({
                "error": "Unsupported file type.",
                "accepted_types": allowed,
            }), 415

        logger.info("Processing file: %s", file.filename)

        # ------------------------------------------------------------------
        # Step 2 — Run OCR
        # ------------------------------------------------------------------

        try:
            raw_text, ocr_details = run_ocr_with_details(file)
            logger.info("OCR complete — %d characters extracted.", len(raw_text))

        except ValueError as exc:
            # File could not be opened as an image/PDF (corrupted, wrong format)
            logger.warning("Invalid file uploaded (%s): %s", file.filename, exc)
            return _error(str(exc), status=400)

        except RuntimeError as exc:
            # EasyOCR internal error
            tb = traceback.format_exc()
            logger.error("OCR engine error:\n%s", tb)
            return _error("OCR processing failed.", detail=str(exc), status=500)

        except MemoryError:
            # Out of RAM (large PDF / high-res image)
            logger.error("MemoryError during OCR — file may be too large.")
            return _error(
                "Not enough memory to process this file. "
                "Try a smaller or lower-resolution file.",
                status=500,
            )

        # ------------------------------------------------------------------
        # Step 3 — Extract structured fields
        # ------------------------------------------------------------------

        try:
            extracted_data = extract_invoice_data(raw_text, ocr_details)
            logger.info("Extraction complete: %s", extracted_data)

        except Exception as exc:
            # Extractor should never raise, but catch it anyway
            tb = traceback.format_exc()
            logger.error("Extractor error:\n%s", tb)
            return _error(
                "Data extraction failed after OCR succeeded.",
                detail=str(exc),
                status=500,
            )

        # ------------------------------------------------------------------
        # Step 4 — Return response
        # ------------------------------------------------------------------

        return jsonify({
            "raw_text": raw_text,
            "extracted_data": extracted_data,
        }), 200

    except Exception as exc:
        # Catch-all — ensures the server never returns an unhandled 500 crash
        tb = traceback.format_exc()
        logger.critical("Unexpected error in /ocr route:\n%s", tb)
        return _error(
            "An unexpected server error occurred. Please try again.",
            detail=str(exc),
            status=500,
        )