"""
OCR Queue Processor
Processes pending_invoice_uploads one by one:
  1. Run OCR on the image file
  2. Extract invoice fields
  3. Save to invoices table
  4. Run matching against transactions
  5. Run flagging (mismatch, duplicate, overdue)
  6. Update queue status
"""
from flask import Blueprint, jsonify, current_app
from services.db import get_db
from services.matching import run_matching_for_invoice
from services.flagging import run_all_flags_for_invoice, flag_overdue_invoices
import os

ocr_processor_bp = Blueprint("ocr_processor", __name__, url_prefix="/api/ocr-processor")


@ocr_processor_bp.get("/run")
def process_queue():
    """
    Process all PENDING invoice uploads.
    Call this endpoint once to run OCR on all 6 demo invoices.
    Returns a summary of what was processed.
    """
    db  = get_db()
    cur = db.cursor()

    cur.execute("""
        SELECT upload_id, employee_id, fund_request_id, transaction_id, file_path, file_name
        FROM   pending_invoice_uploads
        WHERE  status = 'PENDING'
        ORDER  BY upload_id
    """)
    queue = cur.fetchall()

    if not queue:
        return jsonify({"message": "No pending invoices to process", "processed": 0})

    results = []

    for item in queue:
        upload_id = item["upload_id"]
        result = {
            "upload_id":   upload_id,
            "file_name":   item["file_name"],
            "status":      "failed",
            "ocr":         {},
            "match":       {},
            "flags":       [],
            "invoice_id":  None,
        }

        # Mark as PROCESSING
        cur.execute("UPDATE pending_invoice_uploads SET status='PROCESSING' WHERE upload_id=%s",
                    (upload_id,))
        db.commit()

        try:
            file_path = item["file_path"]

            # ── OCR ──────────────────────────────────────────────────
            raw_text = ""
            ocr_fields = {"invoice_number": None, "vendor_name": None,
                          "amount": None, "date": None}

            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")

            try:
                from services.ocr_service import run_ocr_with_details
                class _FS:
                    def __init__(self, p, n):
                        self.filename = n
                        self._path    = p
                    def read(self):
                        with open(self._path, "rb") as f:
                            return f.read()

                raw_text, _ = run_ocr_with_details(_FS(file_path, item["file_name"]))
                current_app.logger.info("OCR done for %s: %d chars", item["file_name"], len(raw_text))
            except Exception as e:
                current_app.logger.error("OCR failed for %s: %s", item["file_name"], e)
                raise

            # ── EXTRACTION ───────────────────────────────────────────
            if raw_text:
                from services.extractor import extract_invoice_data
                res = extract_invoice_data(raw_text)
                ocr_fields = {
                    "invoice_number": res.get("invoice_number"),
                    "vendor_name":    res.get("vendor_name"),
                    "amount":         res.get("amount"),
                    "date":           res.get("date"),
                }
                result["ocr"] = ocr_fields
                current_app.logger.info("Extracted: %s", ocr_fields)

            # ── SAVE TO invoices TABLE ────────────────────────────────
            cur.execute("""
                INSERT INTO invoices
                    (fund_request_id, employee_id, invoice_number, invoice_date,
                     invoice_amount, invoice_currency, file_path, file_name,
                     ocr_vendor_name, ocr_raw_text, verification_status)
                VALUES (%s,%s,%s,%s,%s,'SAR',%s,%s,%s,%s,'PENDING')
            """, (
                item["fund_request_id"],
                item["employee_id"],
                ocr_fields["invoice_number"],
                ocr_fields["date"],
                ocr_fields["amount"] or 0,
                file_path,
                item["file_name"],
                ocr_fields["vendor_name"],
                raw_text[:4000] if raw_text else None,
            ))
            db.commit()
            invoice_id = cur.lastrowid
            result["invoice_id"] = invoice_id

            # ── MATCHING ─────────────────────────────────────────────
            try:
                # Pass specific transaction_id if known from queue
                tx_id = item.get("transaction_id")
                match_result = run_matching_for_invoice(invoice_id, specific_tx_id=tx_id)
                result["match"] = match_result
                current_app.logger.info("Match result for invoice %d: %s", invoice_id, match_result)
            except Exception as e:
                current_app.logger.warning("Matching failed: %s", e)

            # ── FLAGGING ─────────────────────────────────────────────
            try:
                flags = run_all_flags_for_invoice(invoice_id)
                result["flags"] = flags
                current_app.logger.info("Flags for invoice %d: %s", invoice_id, flags)
            except Exception as e:
                current_app.logger.warning("Flagging failed: %s", e)

            # ── UPDATE QUEUE ──────────────────────────────────────────
            cur.execute("""
                UPDATE pending_invoice_uploads
                SET status='DONE', invoice_id=%s, processed_at=NOW()
                WHERE upload_id=%s
            """, (invoice_id, upload_id))
            db.commit()

            result["status"] = "done"

        except Exception as e:
            cur.execute("""
                UPDATE pending_invoice_uploads
                SET status='FAILED', error_message=%s, processed_at=NOW()
                WHERE upload_id=%s
            """, (str(e)[:500], upload_id))
            db.commit()
            result["error"] = str(e)
            current_app.logger.error("Failed upload_id %d: %s", upload_id, e)

        results.append(result)

    # ── Also check for overdue invoices ───────────────────────────────
    overdue_flags = []
    try:
        overdue_flags = flag_overdue_invoices()
    except Exception as e:
        current_app.logger.warning("Overdue check failed: %s", e)

    done    = sum(1 for r in results if r["status"] == "done")
    failed  = sum(1 for r in results if r["status"] == "failed")
    total_flags = sum(len(r["flags"]) for r in results) + len(overdue_flags)

    return jsonify({
        "processed":     len(results),
        "done":          done,
        "failed":        failed,
        "flags_created": total_flags,
        "overdue_flags": len(overdue_flags),
        "results":       results,
    })


@ocr_processor_bp.get("/status")
def queue_status():
    """Check the current state of the invoice upload queue."""
    db  = get_db()
    cur = db.cursor()
    cur.execute("""
        SELECT p.upload_id, p.file_name, p.status, p.submitted_at, p.processed_at,
               p.error_message, p.invoice_id,
               u.full_name AS employee_name,
               fr.request_title AS project_name,
               i.invoice_number, i.invoice_amount, i.ocr_vendor_name,
               i.verification_status AS invoice_status
        FROM   pending_invoice_uploads p
        JOIN   users u          ON u.user_id          = p.employee_id
        JOIN   fund_requests fr ON fr.fund_request_id = p.fund_request_id
        LEFT   JOIN invoices i  ON i.invoice_id       = p.invoice_id
        ORDER  BY p.upload_id
    """)
    from datetime import date, datetime
    rows = [{k: (v.isoformat() if isinstance(v, (date, datetime)) else v)
             for k, v in r.items()}
            for r in cur.fetchall()]

    summary = {
        "total":      len(rows),
        "pending":    sum(1 for r in rows if r["status"] == "PENDING"),
        "processing": sum(1 for r in rows if r["status"] == "PROCESSING"),
        "done":       sum(1 for r in rows if r["status"] == "DONE"),
        "failed":     sum(1 for r in rows if r["status"] == "FAILED"),
    }

    return jsonify({"summary": summary, "queue": rows})


@ocr_processor_bp.get("/reset")
def reset_queue():
    """Reset all DONE/FAILED items back to PENDING for reprocessing."""
    db  = get_db()
    cur = db.cursor()
    cur.execute("""
        UPDATE pending_invoice_uploads
        SET status='PENDING', invoice_id=NULL,
            error_message=NULL, processed_at=NULL
        WHERE status IN ('DONE','FAILED')
    """)
    db.commit()
    return jsonify({"ok": True, "reset": cur.rowcount})
