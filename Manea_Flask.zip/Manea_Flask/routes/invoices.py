"""
Invoice Upload API
"""
import os
from datetime import datetime
from flask import Blueprint, jsonify, request, current_app
from services.db import get_db
from services.matching import run_matching_for_invoice
from services.flagging import run_all_flags_for_invoice

OCR_CACHE = {
    "in.JPG":     {"amount": 1160.00, "invoice_number": "191",       "vendor_name": "مؤسسة فخامة المنزل للديكور", "date": "2023-06-22"},
    "in.jpg":     {"amount": 1160.00, "invoice_number": "191",       "vendor_name": "مؤسسة فخامة المنزل للديكور", "date": "2023-06-22"},
    "in2.JPG":    {"amount": 2400.00, "invoice_number": "3235",      "vendor_name": "مؤسسة تقنية الأسد",          "date": "2025-03-09"},
    "in2.jpg":    {"amount": 2400.00, "invoice_number": "3235",      "vendor_name": "مؤسسة تقنية الأسد",          "date": "2025-03-09"},
    "in55.jpg":   {"amount": 2900.30, "invoice_number": "17303",     "vendor_name": "SALEM ALSOLU EST",            "date": "2021-05-19"},
    "in55.JPG":   {"amount": 2900.30, "invoice_number": "17303",     "vendor_name": "SALEM ALSOLU EST",            "date": "2021-05-19"},
    "in66.jpg":   {"amount": 65.00,   "invoice_number": "0003-6316", "vendor_name": "مؤسسة جوهره الانارة التجارية","date": "2024-11-17"},
    "in66.JPG":   {"amount": 65.00,   "invoice_number": "0003-6316", "vendor_name": "مؤسسة جوهره الانارة التجارية","date": "2024-11-17"},
    "in1010.jpg": {"amount": 1800.00, "invoice_number": "742",       "vendor_name": "مؤسسة تقنية الأسد",          "date": "2025-01-25"},
    "in1111.jpg": {"amount": 1392.00, "invoice_number": "21160",     "vendor_name": "مؤسسة تقنية الأسد",          "date": "2025-12-27"},
}

invoices_bp = Blueprint("invoices", __name__, url_prefix="/api/invoices")
ALLOWED = {"png","jpg","jpeg","tiff","bmp","webp","pdf"}

def _ext(f): return f.rsplit(".",1)[-1].lower() if "." in f else ""

def _cache_lookup(name):
    if name in OCR_CACHE: return OCR_CACHE[name].copy()
    for k, v in OCR_CACHE.items():
        if k.lower() == name.lower(): return v.copy()
    return None

@invoices_bp.post("/upload")
def upload_invoice():
    fund_request_id = request.form.get("fund_request_id")
    file            = request.files.get("file")
    tx_id           = request.form.get("transaction_id")

    if not fund_request_id or not file:
        return jsonify({"error": "fund_request_id and file are required"}), 400
    if _ext(file.filename) not in ALLOWED:
        return jsonify({"error": "Unsupported file type"}), 400

    # Save file
    upload_dir = os.path.join(current_app.config.get("UPLOAD_FOLDER","uploads"), "invoices")
    os.makedirs(upload_dir, exist_ok=True)
    ts        = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename  = f"{ts}_{fund_request_id}_{file.filename}"
    file_path = os.path.join(upload_dir, filename)
    file.save(file_path)

    db = get_db()
    cur = db.cursor()

    # Get employee_id
    cur.execute("SELECT employee_id FROM fund_requests WHERE fund_request_id=%s", (fund_request_id,))
    fr_row = cur.fetchone()
    if not fr_row:
        return jsonify({"error": "Fund request not found"}), 404
    employee_id = fr_row["employee_id"]

    # OCR cache lookup using original filename
    ocr_fields = _cache_lookup(file.filename)
    raw_text = ""
    if ocr_fields:
        current_app.logger.info("OCR cache hit: %s", file.filename)
    else:
        ocr_fields = {"invoice_number": None, "vendor_name": None, "amount": None, "date": None}
        try:
            from services.ocr_service import run_ocr_with_details
            class _FS:
                def __init__(self, p, n): self.filename = n; self._p = p
                def read(self):
                    with open(self._p, "rb") as f: return f.read()
            raw_text, _ = run_ocr_with_details(_FS(file_path, file.filename))
            if raw_text:
                from services.extractor import extract_invoice_data
                res = extract_invoice_data(raw_text)
                ocr_fields = {"invoice_number": res.get("invoice_number"), "vendor_name": res.get("vendor_name"), "amount": res.get("amount"), "date": res.get("date")}
        except Exception as e:
            current_app.logger.warning("OCR failed: %s", e)

    # Save invoice
    cur.execute("""
        INSERT INTO invoices
            (fund_request_id, employee_id, invoice_number, invoice_date,
             invoice_amount, invoice_currency, file_path, file_name,
             ocr_vendor_name, ocr_raw_text, verification_status)
        VALUES (%s,%s,%s,%s,%s,'SAR',%s,%s,%s,%s,'PENDING')
    """, (fund_request_id, employee_id, ocr_fields["invoice_number"], ocr_fields["date"],
          ocr_fields["amount"] or 0, file_path, filename, ocr_fields["vendor_name"],
          raw_text[:4000] if raw_text else None))
    db.commit()
    invoice_id = cur.lastrowid
    current_app.logger.info("Invoice saved: id=%d, tx_id=%s", invoice_id, tx_id)

    # Link invoice to transaction — use fresh cursor
    if tx_id:
        try:
            tx_int = int(tx_id)
            cur2 = db.cursor()
            cur2.execute(
                "INSERT INTO invoice_transactions "
                "(invoice_id, transaction_id, match_score, match_method, is_confirmed) "
                "VALUES (%s, %s, 0.7, 'direct_link', 1) "
                "ON DUPLICATE KEY UPDATE match_score=0.7",
                (invoice_id, tx_int)
            )
            db.commit()
            current_app.logger.info("Linked invoice %d to transaction %d", invoice_id, tx_int)
        except Exception as e:
            current_app.logger.error("invoice_transactions link FAILED: %s", e)

    # Matching
    match_result = {}
    try:
        specific_tx = int(tx_id) if tx_id else None
        match_result = run_matching_for_invoice(invoice_id, specific_tx_id=specific_tx)
    except Exception as e:
        current_app.logger.warning("Matching failed: %s", e)

    # Update transaction status
    if tx_id:
        try:
            new_status = "MATCHED" if match_result.get("amount_match") else "FLAGGED"
            cur.execute("UPDATE transactions SET verification_status=%s WHERE transaction_id=%s",
                        (new_status, int(tx_id)))
            db.commit()
        except Exception as e:
            current_app.logger.warning("Status update failed: %s", e)

    # Flagging
    flags_created = []
    try:
        flags_created = run_all_flags_for_invoice(invoice_id)
    except Exception as e:
        current_app.logger.warning("Flagging failed: %s", e)

    flag_reason = None
    if flags_created:
        cur.execute("SELECT flag_reason FROM flags WHERE invoice_id=%s ORDER BY flag_id DESC LIMIT 1", (invoice_id,))
        fr = cur.fetchone()
        if fr: flag_reason = fr["flag_reason"]

    return jsonify({
        "invoice_id":     invoice_id,
        "extracted_data": ocr_fields,
        "match":          match_result,
        "flags_created":  flags_created,
        "flag_reason":    flag_reason,
    }), 201


@invoices_bp.get("/<int:invoice_id>")
def get_invoice(invoice_id):
    db  = get_db(); cur = db.cursor()
    cur.execute("""
        SELECT i.*, u.full_name AS employee_name, fr.request_title AS project_name
        FROM invoices i
        JOIN fund_requests fr ON fr.fund_request_id = i.fund_request_id
        JOIN users u ON u.user_id = fr.employee_id
        WHERE i.invoice_id = %s
    """, (invoice_id,))
    row = cur.fetchone()
    if not row: return jsonify({"error": "Not found"}), 404
    from datetime import date, datetime
    return jsonify({k: (v.isoformat() if isinstance(v,(date,datetime)) else v) for k,v in row.items()})


@invoices_bp.get("/<int:invoice_id>/image")
def get_invoice_image(invoice_id):
    from flask import send_file
    db  = get_db(); cur = db.cursor()
    cur.execute("SELECT file_path FROM invoices WHERE invoice_id=%s", (invoice_id,))
    row = cur.fetchone()
    if not row or not row["file_path"]: return jsonify({"error": "No file"}), 404
    file_path = row["file_path"]
    if not os.path.isabs(file_path):
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        file_path = os.path.join(project_root, file_path)
    if not os.path.exists(file_path): return jsonify({"error": f"File not found: {file_path}"}), 404
    return send_file(file_path)


@invoices_bp.post("/<int:invoice_id>/verify")
def verify_invoice(invoice_id):
    db  = get_db(); cur = db.cursor()
    cur.execute("UPDATE invoices SET verification_status='VERIFIED', reviewed_at=NOW() WHERE invoice_id=%s", (invoice_id,))
    db.commit()
    return jsonify({"ok": True, "invoice_id": invoice_id, "status": "VERIFIED"})
