"""
Auditor Dashboard API — correct column names for manea DB:
  flags: flag_id, flag_reason, flag_ref, priority, status, details
  notifications: notification_id, user_id, flag_id, type, message, is_read
  users: user_id, full_name
  fund_requests: fund_request_id, request_title
  invoices: invoice_id, invoice_number, invoice_amount, invoice_date, ocr_vendor_name
  transactions: transaction_id, amount, transaction_date, description
"""
from flask import Blueprint, jsonify, request
from services.db import get_db
from datetime import date, datetime

dashboard_bp = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")


def _serial(v):
    if isinstance(v, (date, datetime)): return v.isoformat()
    return v

def _rows(cur):
    return [{k: _serial(v) for k, v in r.items()} for r in cur.fetchall()]


@dashboard_bp.get("/stats")
def stats():
    db = get_db(); cur = db.cursor()

    cur.execute("SELECT COUNT(*) AS c FROM transactions")
    total_tx = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) AS c FROM invoices WHERE verification_status='VERIFIED'")
    verified = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) AS c FROM flags WHERE status='OPEN'")
    flagged = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) AS c FROM flags WHERE status='OPEN' AND flag_reason='AI_AMOUNT_MISMATCH'")
    mismatch = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) AS c FROM flags WHERE status='OPEN' AND flag_reason='OVERDUE_TRANSACTION'")
    overdue = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) AS c FROM flags WHERE status='OPEN' AND flag_reason='DUPLICATE_INVOICE'")
    duplicate = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) AS c FROM invoices WHERE verification_status='PENDING'")
    pending = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(*) AS c FROM invoices WHERE uploaded_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")
    recent = cur.fetchone()["c"]

    return jsonify({
        "total_transactions":  total_tx,
        "verified_invoices":   verified,
        "flagged_cases":       flagged,
        "mismatch_flags":      mismatch,
        "overdue_flags":       overdue,
        "duplicate_flags":     duplicate,
        "pending_reviews":     pending,
        "recent_uploads":      recent,
        "suspicious_activity": mismatch,
    })


@dashboard_bp.get("/flags")
def flags():
    # Auto-run overdue check every time flags are loaded
    try:
        from services.flagging import flag_overdue_invoices
        flag_overdue_invoices()
    except Exception:
        pass
    db     = get_db(); cur = db.cursor()
    status = request.args.get("status", "OPEN").upper()
    limit  = int(request.args.get("limit", 50))

    cur.execute("""
        SELECT
            f.flag_id, f.flag_ref, f.flag_reason, f.priority, f.status,
            f.details, f.created_at, f.resolved_at,
            f.invoice_id,
            f.transaction_id   AS flag_transaction_id,
            u.full_name        AS employee_name,
            fr.request_title   AS project_name,
            fr.fund_request_id,
            i.invoice_number   AS ocr_invoice_number,
            i.invoice_amount   AS inv_amount,
            i.ocr_vendor_name  AS inv_vendor,
            i.invoice_date     AS inv_date,
            i.file_path        AS inv_file_path,
            t.amount           AS tx_amount,
            t.transaction_date,
            t.due_date,
            t.description      AS merchant_name,
            t.transaction_type,
            t.transaction_id,
            ec.card_suffix,
            -- For DUPLICATE_INVOICE: find the original invoice's card and employee
            orig_ec.card_suffix  AS orig_card_suffix,
            orig_u.full_name     AS orig_employee_name
        FROM  flags f
        JOIN  users u          ON u.user_id          = f.employee_id
        LEFT  JOIN fund_requests fr ON fr.fund_request_id = f.fund_request_id
        LEFT  JOIN invoices      i  ON i.invoice_id       = f.invoice_id
        LEFT  JOIN transactions  t  ON t.transaction_id   = f.transaction_id
        LEFT JOIN employee_cards ec ON ec.user_id = f.employee_id
        -- Join original invoice (the one that was submitted first with same invoice_number)
        LEFT JOIN invoices orig_i ON orig_i.invoice_number = i.invoice_number
                                 AND orig_i.invoice_id != f.invoice_id
                                 AND f.flag_reason = 'DUPLICATE_INVOICE'
        LEFT JOIN fund_requests orig_fr ON orig_fr.fund_request_id = orig_i.fund_request_id
        LEFT JOIN employee_cards orig_ec ON orig_ec.user_id = orig_fr.employee_id
        LEFT JOIN users orig_u ON orig_u.user_id = orig_fr.employee_id
        WHERE f.status = %s
        ORDER BY FIELD(f.priority,'HIGH','MEDIUM','LOW'), f.created_at DESC
        LIMIT %s
    """, (status, limit))
    return jsonify(_rows(cur))


@dashboard_bp.post("/flags/<int:flag_id>/resolve")
def resolve_flag(flag_id):
    db = get_db(); cur = db.cursor()
    cur.execute("""
        UPDATE flags SET status='RESOLVED', resolved_at=NOW()
        WHERE flag_id=%s AND status='OPEN'
    """, (flag_id,))
    db.commit()
    return jsonify({"ok": True, "flag_id": flag_id, "status": "RESOLVED"})


@dashboard_bp.post("/flags/<int:flag_id>/dismiss")
def dismiss_flag(flag_id):
    db = get_db(); cur = db.cursor()
    cur.execute("UPDATE flags SET status='REVIEWED' WHERE flag_id=%s", (flag_id,))
    db.commit()
    return jsonify({"ok": True, "flag_id": flag_id, "status": "REVIEWED"})


@dashboard_bp.get("/transactions")
def transactions():
    db = get_db(); cur = db.cursor()
    limit = int(request.args.get("limit", 30))
    cur.execute("""
        SELECT t.transaction_id, t.transaction_date, t.amount, t.currency_code,
               t.description, t.verification_status, t.due_date,
               ec.card_suffix,
               u.full_name        AS employee_name,
               fr.request_title   AS project_name
        FROM   transactions t
        JOIN   employee_cards ec ON ec.card_id  = t.card_id
        JOIN   users u           ON u.user_id   = ec.user_id
        LEFT   JOIN fund_requests fr ON fr.fund_request_id = t.fund_request_id
        ORDER  BY t.transaction_date DESC
        LIMIT  %s
    """, (limit,))
    return jsonify(_rows(cur))


@dashboard_bp.get("/invoices")
def invoices():
    db = get_db(); cur = db.cursor()
    limit  = int(request.args.get("limit", 30))
    status = request.args.get("status")
    sql = """
        SELECT i.invoice_id, i.invoice_number, i.invoice_amount, i.invoice_currency,
               i.invoice_date, i.verification_status, i.uploaded_at, i.file_path,
               i.ocr_vendor_name,
               u.full_name      AS employee_name,
               fr.request_title AS project_name
        FROM   invoices i
        JOIN   fund_requests fr ON fr.fund_request_id = i.fund_request_id
        JOIN   users u          ON u.user_id = fr.employee_id
    """
    params = []
    if status:
        sql += " WHERE i.verification_status = %s"
        params.append(status)
    sql += " ORDER BY i.uploaded_at DESC LIMIT %s"
    params.append(limit)
    cur.execute(sql, params)
    return jsonify(_rows(cur))


@dashboard_bp.get("/notifications")
def notifications():
    db = get_db(); cur = db.cursor()
    user_id = int(request.args.get("user_id", 1))
    cur.execute("""
        SELECT n.notification_id, n.type, n.message, n.is_read, n.created_at
        FROM   notifications n
        WHERE  n.user_id = %s
        ORDER  BY n.created_at DESC
        LIMIT  20
    """, (user_id,))
    return jsonify(_rows(cur))


@dashboard_bp.post("/notifications/<int:notif_id>/read")
def mark_read(notif_id):
    db = get_db(); cur = db.cursor()
    cur.execute("UPDATE notifications SET is_read=1 WHERE notification_id=%s", (notif_id,))
    db.commit()
    return jsonify({"ok": True})


@dashboard_bp.post("/notifications/read-all")
def mark_all_read():
    db = get_db(); cur = db.cursor()
    uid = request.json.get("user_id", 1) if request.is_json else 1
    cur.execute("UPDATE notifications SET is_read=1 WHERE user_id=%s", (uid,))
    db.commit()
    return jsonify({"ok": True})


@dashboard_bp.get("/employees")
def employees():
    db = get_db(); cur = db.cursor()
    cur.execute("""
        SELECT u.user_id, u.full_name, u.email, u.department,
               COUNT(DISTINCT fr.fund_request_id) AS request_count,
               COUNT(DISTINCT i.invoice_id)        AS invoice_count,
               COUNT(DISTINCT f.flag_id)            AS open_flag_count
        FROM   users u
        LEFT   JOIN fund_requests fr ON fr.employee_id = u.user_id
        LEFT   JOIN invoices i       ON i.employee_id  = u.user_id
        LEFT   JOIN flags f          ON f.employee_id  = u.user_id AND f.status='OPEN'
        WHERE  u.role = 'EMPLOYEE'
        GROUP  BY u.user_id
        ORDER  BY u.full_name
    """)
    return jsonify(_rows(cur))
