"""
Bank Transaction CSV Upload API
Real bank CSV format: transaction_date, amount, card_suffix, description
Each card belongs to one employee who has one fund request.
All transactions from that card link to that employee's fund request automatically.
"""
import csv, io, os
from datetime import datetime
from flask import Blueprint, jsonify, request, current_app
from services.db import get_db

transactions_bp = Blueprint("transactions", __name__, url_prefix="/api/transactions")


@transactions_bp.post("/upload-csv")
def upload_csv():
    """
    Accountant uploads real bank CSV.

    Expected columns (case-insensitive, flexible naming):
      transaction_date  — YYYY-MM-DD  (also: date, tx_date)
      amount            — numeric SAR (also: debit, value, amount_sar)
      card_suffix       — last 4 digits of employee card (also: card_last4, suffix, card_no)
      description       — text description of purchase (also: desc, narration, merchant)

    System auto-links each row to the correct employee and their fund request via card_suffix.
    """
    accountant_id = request.form.get("accountant_id", 2)
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "file is required"}), 400

    content = file.read().decode("utf-8-sig", errors="replace")
    rows    = list(csv.DictReader(io.StringIO(content)))
    if not rows:
        return jsonify({"error": "CSV is empty"}), 400

    # Save CSV file
    upload_dir = os.path.join(current_app.config.get("UPLOAD_FOLDER", "uploads"), "csv")
    os.makedirs(upload_dir, exist_ok=True)
    csv_path = os.path.join(upload_dir, file.filename)
    file.seek(0)
    file.save(csv_path)

    db  = get_db()
    cur = db.cursor()

    # Create batch record
    cur.execute("""
        INSERT INTO csv_batches (accountant_id, file_name, file_path)
        VALUES (%s, %s, %s)
    """, (accountant_id, file.filename, csv_path))
    db.commit()
    batch_id = cur.lastrowid

    def _col(row, *keys):
        for k in keys:
            for rk, rv in row.items():
                if rk.strip().lower() == k.lower():
                    return rv
        return None

    def _parse_date(raw):
        """Accept DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD, YYYY/MM/DD."""
        if not raw:
            return None
        raw = raw.strip()
        for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%Y/%m/%d",
                    "%m/%d/%Y", "%d/%m/%y", "%d-%m-%y"):
            try:
                return datetime.strptime(raw, fmt).date()
            except ValueError:
                continue
        return None

    inserted = 0
    skipped  = 0
    errors   = []

    for i, row in enumerate(rows, 1):
        try:
            # Skip completely empty rows
            if not any(v and str(v).strip() for v in row.values()):
                skipped += 1
                continue

            raw_date = _col(row, "date", "transaction_date", "tx_date",
                            "transaction date", "تاريخ")
            amount   = float((_col(row, "amount", "debit", "value",
                                   "amount_sar", "المبلغ") or "0").strip().replace(",", "") or 0)
            card_sfx = str(_col(row, "card number", "card_number", "card_suffix",
                                 "card_last4", "card_no", "suffix",
                                 "رقم البطاقة") or "").strip()
            desc     = _col(row, "description", "desc", "narration",
                            "merchant", "البيان") or "PURCHASE"
            tx_type  = _col(row, "transaction_type", "type", "tx_type",
                            "trx_type") or "POS"
            tx_date  = _parse_date(raw_date)
            if tx_date is None:
                skipped += 1
                errors.append(f"Row {i}: invalid date format {raw_date!r}")
                continue

            if amount <= 0:
                skipped += 1
                errors.append(f"Row {i}: amount must be > 0")
                continue

            if not card_sfx:
                skipped += 1
                errors.append(f"Row {i}: card_suffix is required")
                continue

            # Find employee via card_suffix
            cur.execute("""
                SELECT ec.card_id, ec.user_id
                FROM   employee_cards ec
                WHERE  ec.card_suffix = %s AND ec.card_status = 'ACTIVE'
                LIMIT  1
            """, (card_sfx,))
            card_row = cur.fetchone()
            if not card_row:
                skipped += 1
                errors.append(f"Row {i}: card suffix {card_sfx!r} not found")
                continue

            # Get employee's ONE active fund request
            cur.execute("""
                SELECT fund_request_id
                FROM   fund_requests
                WHERE  employee_id = %s
                  AND  status IN ('ACTIVE', 'APPROVED', 'PENDING')
                ORDER  BY created_at DESC
                LIMIT  1
            """, (card_row["user_id"],))
            fr_row = cur.fetchone()
            fund_request_id = fr_row["fund_request_id"] if fr_row else None

            if not fund_request_id:
                skipped += 1
                errors.append(f"Row {i}: no fund request found for card {card_sfx}")
                continue

            # Insert transaction
            cur.execute("""
                INSERT INTO transactions
                    (csv_batch_id, card_id, fund_request_id, transaction_date,
                     amount, currency_code, description, transaction_type,
                     due_date, verification_status)
                VALUES (%s, %s, %s, %s, %s, 'SAR', %s, %s,
                        DATE_ADD(%s, INTERVAL 7 DAY), 'UNMATCHED')
            """, (batch_id, card_row["card_id"], fund_request_id,
                  tx_date, amount, desc, tx_type.upper(), tx_date))
            inserted += 1

        except Exception as e:
            skipped += 1
            errors.append(f"Row {i}: {e}")
            current_app.logger.warning("Skip CSV row %d: %s | row=%s", i, e, row)

    db.commit()

    # Auto-run overdue check after import
    try:
        from services.flagging import flag_overdue_invoices
        overdue = flag_overdue_invoices()
    except Exception as e:
        overdue = []
        current_app.logger.warning("Overdue check failed: %s", e)

    return jsonify({
        "batch_id":      batch_id,
        "inserted":      inserted,
        "skipped":       skipped,
        "overdue_flags": len(overdue),
        "errors":        errors[:10],
        "message":       f"{inserted} transactions imported, {skipped} skipped",
        "csv_format": {
            "required_columns": ["transaction_date (YYYY-MM-DD)", "amount", "card_suffix", "transaction_type", "description"],
            "transaction_types": ["POS", "DEBIT_TRANSFER", "ONLINE", "ATM", "DIRECT_DEBIT", "SADAD", "MADA"],
            "example_row":      {"transaction_date": "2025-03-09", "amount": "1850.00",
                                  "card_suffix": "4823", "transaction_type": "POS",
                                  "description": "Office supplies"}
        }
    }), 201


@transactions_bp.get("/")
def list_transactions():
    db    = get_db()
    cur   = db.cursor()
    status = request.args.get("status")
    limit  = int(request.args.get("limit", 50))

    sql = """
        SELECT t.transaction_id, t.transaction_date, t.amount, t.currency_code,
               t.description, t.verification_status, t.due_date,
               ec.card_suffix,
               u.full_name   AS employee_name,
               u.user_id     AS employee_id,
               fr.request_title AS project_name,
               fr.fund_request_id
        FROM   transactions t
        JOIN   employee_cards ec ON ec.card_id  = t.card_id
        JOIN   users u           ON u.user_id   = ec.user_id
        LEFT   JOIN fund_requests fr ON fr.fund_request_id = t.fund_request_id
    """
    params = []
    if status:
        sql += " WHERE t.verification_status = %s"
        params.append(status)
    sql += " ORDER BY t.transaction_date DESC LIMIT %s"
    params.append(limit)

    cur.execute(sql, params)
    from datetime import date, datetime
    return jsonify([
        {k: (v.isoformat() if isinstance(v, (date, datetime)) else v) for k, v in r.items()}
        for r in cur.fetchall()
    ])


@transactions_bp.route("/check-overdue", methods=["GET","POST"])
def check_overdue():
    """Manually trigger overdue invoice scan."""
    from services.flagging import flag_overdue_invoices
    created = flag_overdue_invoices()
    return jsonify({"created": len(created), "flags": created})
