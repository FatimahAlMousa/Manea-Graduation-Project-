"""Manea System Configuration."""
import os

class Config:
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    UPLOAD_FOLDER      = os.getenv("UPLOAD_FOLDER", "uploads")
    OCR_LANGUAGES      = ["ar", "en"]
    OCR_USE_GPU        = os.getenv("OCR_USE_GPU", "false").lower() == "true"
    SECRET_KEY         = os.getenv("SECRET_KEY", "manea-secret-2024")
    DB_HOST            = os.getenv("DB_HOST",     "localhost")
    DB_PORT = int(os.getenv("DB_PORT", "3306"))
    DB_USER            = os.getenv("DB_USER",     "root")
    DB_PASSWORD        = os.getenv("DB_PASSWORD", "Root@123")
    DB_NAME            = os.getenv("DB_NAME",     "manea")
