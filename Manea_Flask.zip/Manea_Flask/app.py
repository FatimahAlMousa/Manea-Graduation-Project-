"""Manea System — Flask Application Entry Point"""
import os
from dotenv import load_dotenv
load_dotenv()

from flask import Flask
from flask_cors import CORS
from config import Config
from services.db import init_app as init_db


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    init_db(app)

    from routes.ocr_routes     import ocr_bp
    from routes.dashboard      import dashboard_bp
    from routes.invoices       import invoices_bp
    from routes.transactions   import transactions_bp
    from routes.ocr_processor  import ocr_processor_bp

    app.register_blueprint(ocr_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(invoices_bp)
    app.register_blueprint(transactions_bp)
    app.register_blueprint(ocr_processor_bp)

    return app


app = create_app()

@app.route("/")
@app.route("/dashboard")
def serve_dashboard():
    import os
    from flask import send_from_directory
    base = os.path.dirname(os.path.abspath(__file__))
    return send_from_directory(base, "auditor-dashboard.html")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000, use_reloader=False)
