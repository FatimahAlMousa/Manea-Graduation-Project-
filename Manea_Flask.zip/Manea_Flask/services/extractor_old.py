"""
Invoice Data Extractor

Parses raw OCR text (Arabic or English) to pull out structured invoice fields.
No ML training is required — the module relies entirely on:
  - Arabic-to-Western numeral normalization
  - Keyword-anchored regex matching for amounts
  - Bounding-box proximity analysis (when detailed OCR results available)
  - Multi-format date pattern matching

Extracted fields
----------------
amount : float | None   — the total/grand-total monetary value
date   : str   | None   — the invoice date, normalized to "YYYY-MM-DD"

Integration note
----------------
The public function extract_invoice_data() returns a plain dict.  The Manea
backend can compare its values directly against a database transaction record:

    result = extract_invoice_data(raw_text)
    if result["amount"] != transaction.amount:
        flag_for_audit(transaction)

Bounding box format
-------------------
Each bounding box is a list of 4 points: [[x0,y0],[x1,y1],[x2,y2],[x3,y3]]
representing the corners of the detected text region in pixel coordinates.
"""

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


# ===========================================================================
# Section 1 — Numeral normalization
# ===========================================================================

# Maps Arabic-Indic digits + decimal/thousands separators to Western equivalents.
# Arabic comma (٬) used as thousands sep → Western comma
# Arabic decimal point (٫) → Western period
_ARABIC_TO_WESTERN = str.maketrans("٠١٢٣٤٥٦٧٨٩٫٬", "0123456789.,")


def _normalize_numerals(text: str) -> str:
    """
    Convert Arabic-Indic digits (٠١٢…٩) and punctuation (٫٬) to their
    Western counterparts so that a single set of regex patterns covers both
    Arabic and English invoice formats.
    """
    return text.translate(_ARABIC_TO_WESTERN)


# ===========================================================================
# Section 2 — Amount extraction
# ===========================================================================

# Keywords that explicitly indicate VAT, tax, discount, or subtotal
# These lines should be EXCLUDED from amount extraction
_EXCLUDE_KEYWORDS_AR = [
    r"ضريبة\s*القيمة\s*المضافة",  # VAT
    r"ضريبة\s*الدخل",             # income tax
    r"ضريبة",                      # tax (general)
    r"خصم",                        # discount
    r"مجموع\s*جزئي",              # subtotal
    r"المجموع\s*قبل\s*الضريبة",  # subtotal before tax
]

_EXCLUDE_KEYWORDS_EN = [
    r"vat",
    r"tax",
    r"discount",
    r"subtotal",
    r"sub\s*total",
]

# Combined exclusion regex
_EXCLUDE_KEYWORD_RE = re.compile(
    "|".join(_EXCLUDE_KEYWORDS_AR + _EXCLUDE_KEYWORDS_EN),
    re.IGNORECASE | re.UNICODE,
)

# Keywords that EXPLICITLY indicate the final total/grand total
# These are the most specific and should be preferred
_PREFER_KEYWORDS_AR = [
    r"المجموع\s*الإجمالي",       # grand total (most specific)
    r"الإجمالي\s*شامل\s*الضريبة", # total including VAX
    r"إجمالي\s*الفاتورة",         # invoice total
    r"الفاتورة\s*الإجمالية",      # invoice total (alt.)
]

_PREFER_KEYWORDS_EN = [
    r"grand\s*total",
    r"total\s*invoice",
    r"invoice\s*total",
    r"total\s*amount\s*due",
    r"amount\s*due",
]

# Combined preference regex (most specific keywords)
_PREFER_KEYWORD_RE = re.compile(
    "|".join(_PREFER_KEYWORDS_AR + _PREFER_KEYWORDS_EN),
    re.IGNORECASE | re.UNICODE,
)

# Keywords that indicate the main/general total
_AMOUNT_KEYWORDS_AR = [
    r"المجموع\s*الإجمالي",       # grand total (most specific)
    r"الإجمالي\s*شامل\s*الضريبة", # total including VAT
    r"إجمالي\s*الفاتورة",         # invoice total
    r"الفاتورة\s*الإجمالية",      # invoice total (alt.)
    r"الإجمالي\s*الكلي",          # grand total alternative
    r"القيمة\s*الإجمالية",        # total value
    r"المبلغ\s*الإجمالي",         # total amount
    r"المجموع\s*الكلي",           # grand sum
    r"الإجمالي",                  # total
    r"المجموع",                   # sum / total
    r"المبلغ",                    # amount
]

_AMOUNT_KEYWORDS_EN = [
    r"grand\s*total",
    r"total\s*invoice",
    r"invoice\s*total",
    r"total\s*amount",
    r"net\s*amount",
    r"amount\s*due",
    r"total\s*due",
    r"total\s*payable",
    r"total",
    r"amount",
    r"sum",
]

# Combined keyword regex (case-insensitive, Unicode-aware)
_AMOUNT_KEYWORD_RE = re.compile(
    "|".join(_AMOUNT_KEYWORDS_AR + _AMOUNT_KEYWORDS_EN),
    re.IGNORECASE | re.UNICODE,
)

# Matches a monetary number after numeral normalization.
# Handles:  1234  |  1,234  |  1,234.56  |  1234.5  (and Arabic equivalents)
_MONEY_RE = re.compile(
    r"""
    (?<!\d)                   # must not be preceded by a digit
    (
        \d{1,3}               # 1–3 leading digits
        (?:[,،]\d{3})*        # optional thousands groups (comma or Arabic comma)
        (?:[.]\d{1,3})?       # optional decimal portion
    )
    (?!\d)                    # must not be followed by a digit
    """,
    re.VERBOSE,
)

# Regex to detect percentage signs or VAT indicators nearby a number
_PERCENTAGE_RE = re.compile(r"\d+\.?\d*\s*%")

# Currency indicators (SAR, SR, ريال, etc.)
_CURRENCY_INDICATORS = re.compile(
    r"(SAR|SR|ر\.ع|ريال|دينار|درهم|تومان|pound|dollar|dhs|aed|gbp|usd|eur)\b",
    re.IGNORECASE | re.UNICODE,
)


def _parse_money(num_str: str) -> Optional[float]:
    """Strip thousands separators and convert to float. Returns None on failure."""
    try:
        cleaned = re.sub(r"[,،]", "", num_str)
        value = float(cleaned)
        return value if value > 0 else None
    except ValueError:
        return None


def _is_likely_vat_or_percentage(value: float, context_line: str) -> bool:
    """
    Detect if a value is likely a VAT amount, tax percentage, or small intermediate value.
    
    This function is STRICT to avoid extracting VAT instead of total amount.
    
    Heuristics:
      • If the line contains VAT/tax/discount keywords, EXCLUDE it completely
      • If the line contains '%', the number is likely a percentage
      • If the value is between 5 and 100, it's likely a VAT amount or percentage
      • Otherwise, consider it a valid total amount
    """
    line_lower = context_line.lower()
    
    # ====== STRICT CHECK: If line contains VAT/tax/discount keywords, reject completely ======
    if _EXCLUDE_KEYWORD_RE.search(line_lower):
        logger.debug(f"Rejecting value {value} — line contains VAT/tax/discount keyword: {context_line}")
        return True
    
    # Check for percentage symbol nearby
    if "%" in context_line:
        logger.debug(f"Rejecting value {value} — contains percentage symbol")
        return True
    
    # Values 5-100 are typically percentages or small fees, not totals
    # but be careful not to exclude values like 15 SAR prices
    # However, if combined with the line context, we can be more confident
    if 5 <= value <= 100 and re.search(r"(percent|%|ضريبة|خصم)", line_lower, re.UNICODE):
        logger.debug(f"Rejecting value {value} — likely percentage or small fee")
        return True
    
    return False


def _get_bbox_center(bbox: list) -> tuple[float, float]:
    """
    Compute the center point of a bounding box.
    
    Args:
        bbox: List of 4 points [[x0,y0],[x1,y1],[x2,y2],[x3,y3]]
    
    Returns:
        (center_x, center_y) tuple
    """
    xs = [p[0] for p in bbox]
    ys = [p[1] for p in bbox]
    return (sum(xs) / len(xs), sum(ys) / len(ys))


def _euclidean_distance(p1: tuple[float, float], p2: tuple[float, float]) -> float:
    """Compute Euclidean distance between two points."""
    return ((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2) ** 0.5


def _extract_amount(text: str) -> Optional[float]:
    """
    Search normalized text for a total-amount value with intelligent filtering.

    Strategy (order of preference):
      1. Look for numbers on lines containing SPECIFIC total keywords 
         (Grand Total, Total Invoice, etc.) - these are guaranteed to be totals
      2. Look for numbers on lines containing GENERAL amount keywords
         BUT EXCLUDE any lines that also contain VAT/tax/discount keywords
      3. Filter out percentages and VAT amounts
      4. Select the largest remaining value

    Returns:
        The amount as a float, or None if no plausible number was found.
    """
    normalized = _normalize_numerals(text)
    lines = normalized.splitlines()

    # ========================================================================
    # Pass 1: Lines with SPECIFIC PREFER keywords (highest confidence)
    # ========================================================================
    logger.debug("Pass 1: Looking for amounts with specific total keywords...")
    prefer_candidates: list[float] = []
    
    for line in lines:
        # Skip lines that contain VAT/tax keywords
        if _EXCLUDE_KEYWORD_RE.search(line):
            logger.debug(f"Skipping line with exclusion keyword: {line}")
            continue
            
        if _PREFER_KEYWORD_RE.search(line):
            for num_str in _MONEY_RE.findall(line):
                value = _parse_money(num_str)
                if value is None:
                    continue
                
                if _is_likely_vat_or_percentage(value, line):
                    logger.debug(f"Filtered out VAT/percentage: {value} from line: {line}")
                    continue
                
                prefer_candidates.append(value)
                logger.debug(f"Found prefer-keyword candidate: {value} from line: {line}")
    
    if prefer_candidates:
        best_value = max(prefer_candidates)
        logger.info(f"Selected amount from PREFER keywords: {best_value}")
        return best_value
    
    # ========================================================================
    # Pass 2: Lines with general amount keywords, but NOT exclusion keywords
    # ========================================================================
    logger.debug("Pass 2: Looking for amounts with general keywords (excluding VAT lines)...")
    general_candidates: list[float] = []
    
    for line in lines:
        # CRITICAL: Skip any line with VAT/tax/discount keywords
        if _EXCLUDE_KEYWORD_RE.search(line):
            logger.debug(f"Skipping exclusion-keyword line: {line}")
            continue
        
        # Look for general amount keywords
        if _AMOUNT_KEYWORD_RE.search(line):
            for num_str in _MONEY_RE.findall(line):
                value = _parse_money(num_str)
                if value is None:
                    continue
                
                if _is_likely_vat_or_percentage(value, line):
                    logger.debug(f"Filtered out VAT/percentage: {value} from line: {line}")
                    continue
                
                general_candidates.append(value)
                logger.debug(f"Found general-keyword candidate: {value} from line: {line}")
    
    if general_candidates:
        best_value = max(general_candidates)
        logger.info(f"Selected amount from general keywords: {best_value}")
        return best_value
    
    # ========================================================================
    # Pass 3: Look for amounts with currency indicators anywhere
    # ========================================================================
    logger.debug("Pass 3: Searching for currency-prefixed amounts...")
    currency_candidates: list[float] = []
    
    for match in _CURRENCY_INDICATORS.finditer(normalized):
        # Look backwards and forwards from the currency indicator
        start = max(0, match.start() - 100)
        end = min(len(normalized), match.end() + 50)
        context = normalized[start:end]
        
        # Skip if context contains exclusion keywords
        if _EXCLUDE_KEYWORD_RE.search(context):
            logger.debug(f"Skipping currency match in exclusion context: {context[:50]}")
            continue
        
        for num_str in _MONEY_RE.findall(context):
            value = _parse_money(num_str)
            if value is not None and not _is_likely_vat_or_percentage(value, context):
                currency_candidates.append(value)
                logger.debug(f"Found currency candidate: {value}")
    
    if currency_candidates:
        best_value = max(currency_candidates)
        logger.info(f"Selected amount from currency search: {best_value}")
        return best_value
    
    # ========================================================================
    # Pass 4: Fallback — largest number in the whole text (with strict filtering)
    # ========================================================================
    logger.debug("Pass 4: Fallback to largest number with strict filtering...")
    filtered_values = []
    
    for line in lines:
        # Skip lines with exclusion keywords
        if _EXCLUDE_KEYWORD_RE.search(line):
            continue
        
        for num_str in _MONEY_RE.findall(line):
            value = _parse_money(num_str)
            if value is not None and not _is_likely_vat_or_percentage(value, line):
                filtered_values.append(value)
    
    if filtered_values:
        best_value = max(filtered_values)
        logger.info(f"Selected amount from fallback heuristic: {best_value}")
        return best_value
    
    logger.warning("No suitable amount found in invoice text")
    return None


def _extract_amount_with_bbox(
    text: str,
    details: list[dict],
) -> Optional[float]:
    """
    Extract amount using bounding-box proximity analysis with STRICT VAT filtering.
    
    This is more accurate than text-only extraction because it considers
    the spatial layout of the invoice. Numbers physically close to "Total" keywords
    are more likely to be the grand total.
    
    CRITICAL: This function STRICTLY excludes VAT amounts even if they're
    spatially close to a "Total" keyword. The keyword context matters more
    than proximity.
    
    Args:
        text: Raw OCR text
        details: List of dicts with 'bbox', 'text', 'confidence' keys
    
    Returns:
        The amount as a float, or None if not found.
    """
    if not details:
        logger.debug("No bounding box details provided — falling back to text-only extraction")
        return _extract_amount(text)
    
    normalized = _normalize_numerals(text)
    
    # ========================================================================
    # Find all keyword bounding boxes
    # ========================================================================
    
    # Collect PREFER keywords (highest priority)
    prefer_keyword_bboxes: list[dict] = []
    
    # Collect AMOUNT keywords (general, but not VAT)
    amount_keyword_bboxes: list[dict] = []
    
    # Collect EXCLUDE keyword locations (to avoid these)
    exclude_keyword_bboxes: set[int] = set()
    
    for i, detail in enumerate(details):
        detail_text_lower = detail["text"].lower()
        
        # Mark exclusion keywords
        if _EXCLUDE_KEYWORD_RE.search(detail_text_lower):
            exclude_keyword_bboxes.add(i)
            logger.debug(f"Found exclusion keyword at bbox {i}: {detail['text']}")
            continue
        
        # Track prefer keywords
        if _PREFER_KEYWORD_RE.search(detail["text"]):
            prefer_keyword_bboxes.append(detail)
            logger.debug(f"Found PREFER keyword: {detail['text']}")
        
        # Track general amount keywords
        if _AMOUNT_KEYWORD_RE.search(detail["text"]):
            amount_keyword_bboxes.append(detail)
            logger.debug(f"Found amount keyword: {detail['text']}")
    
    # ========================================================================
    # Pass 1: Find numbers near PREFER keywords (highest confidence)
    # ========================================================================
    if prefer_keyword_bboxes:
        logger.debug(f"Pass 1: Looking for numbers near {len(prefer_keyword_bboxes)} PREFER keywords...")
        prefer_candidates: list[tuple[float, float, dict]] = []
        
        for detail in details:
            # Skip if this is a keyword itself or contains exclusion keywords
            if _PREFER_KEYWORD_RE.search(detail["text"]) or _EXCLUDE_KEYWORD_RE.search(detail["text"]):
                continue
            
            # Try to extract a number from this text
            normalized_line = _normalize_numerals(detail["text"])
            matches = _MONEY_RE.findall(normalized_line)
            
            if not matches:
                continue
            
            for num_str in matches:
                value = _parse_money(num_str)
                if value is None:
                    continue
                
                # CRITICAL: Filter out VAT/percentages
                if _is_likely_vat_or_percentage(value, detail["text"]):
                    logger.debug(f"Filtered out VAT/percentage from PREFER context: {value}")
                    continue
                
                # Compute distance to nearest PREFER keyword
                detail_center = _get_bbox_center(detail["bbox"])
                min_distance = min(
                    _euclidean_distance(detail_center, _get_bbox_center(kw["bbox"]))
                    for kw in prefer_keyword_bboxes
                )
                
                prefer_candidates.append((value, min_distance, detail))
                logger.debug(f"Found number {value} at distance {min_distance:.1f} px from PREFER keyword")
        
        if prefer_candidates:
            # Sort by proximity (closer = better), select the one closest to keyword
            prefer_candidates.sort(key=lambda x: x[1])
            best_value = prefer_candidates[0][0]
            logger.info(f"Selected from PREFER keywords: {best_value}")
            return best_value
    
    # ========================================================================
    # Pass 2: Find numbers near AMOUNT keywords, excluding VAT-adjacent numbers
    # ========================================================================
    if amount_keyword_bboxes:
        logger.debug(f"Pass 2: Looking for numbers near {len(amount_keyword_bboxes)} general keywords...")
        amount_candidates: list[tuple[float, float, dict]] = []
        
        for detail in details:
            # Skip if this is a keyword itself
            if _AMOUNT_KEYWORD_RE.search(detail["text"]):
                continue
            
            # CRITICAL: Skip if this detail or nearby details contain VAT keywords
            if _EXCLUDE_KEYWORD_RE.search(detail["text"]):
                logger.debug(f"Skipping detail with exclusion keyword: {detail['text']}")
                continue
            
            # Try to extract a number
            normalized_line = _normalize_numerals(detail["text"])
            matches = _MONEY_RE.findall(normalized_line)
            
            if not matches:
                continue
            
            for num_str in matches:
                value = _parse_money(num_str)
                if value is None:
                    continue
                
                # CRITICAL: Filter out VAT/percentages
                if _is_likely_vat_or_percentage(value, detail["text"]):
                    logger.debug(f"Filtered out VAT/percentage: {value}")
                    continue
                
                # Compute distance to nearest general keyword
                detail_center = _get_bbox_center(detail["bbox"])
                min_distance = min(
                    _euclidean_distance(detail_center, _get_bbox_center(kw["bbox"]))
                    for kw in amount_keyword_bboxes
                )
                
                amount_candidates.append((value, min_distance, detail))
                logger.debug(f"Found number {value} at distance {min_distance:.1f} px")
        
        if amount_candidates:
            # Sort by value (larger = better), select the largest
            amount_candidates.sort(key=lambda x: x[0], reverse=True)
            best_value = amount_candidates[0][0]
            logger.info(f"Selected from amount keywords: {best_value}")
            return best_value
    
    # ========================================================================
    # Pass 3: Fallback to text-only extraction
    # ========================================================================
    logger.debug("No numbers found near keywords — falling back to text-only extraction")
    return _extract_amount(text)



    """
    Search normalized text for a total-amount value with intelligent filtering.

    Strategy (order of preference):
      1. Look for numbers on lines containing total-related keywords.
         Score candidates by:
         a) Presence of currency indicators (SAR, ريال, etc.) — highest priority
         b) Size of the number (larger = more likely to be grand total)
         c) Filter out percentages and VAT amounts
      2. Fallback: Look for numbers with currency indicators anywhere in the text.
      3. Final fallback: Return the largest number anywhere in the text.

    Returns:
        The amount as a float, or None if no plausible number was found.
    """
    normalized = _normalize_numerals(text)
    lines = normalized.splitlines()

    # ========================================================================
    # Pass 1: Lines with amount keywords — scored candidates
    # ========================================================================
    scored_candidates: list[tuple[float, int]] = []  # (value, score)
    
    for line in lines:
        if _AMOUNT_KEYWORD_RE.search(line):
            for num_str in _MONEY_RE.findall(line):
                value = _parse_money(num_str)
                if value is None:
                    continue
                
                # Filter out percentages and VAT amounts
                if _is_likely_vat_or_percentage(value, line):
                    logger.debug(f"Filtered out likely VAT/percentage: {value} from line: {line}")
                    continue
                
                # Score this candidate
                score = 0
                
                # +100 if currency indicator is present on the same line
                if _CURRENCY_INDICATORS.search(line):
                    score += 100
                    logger.debug(f"Found currency indicator for amount {value}")
                
                # +10 for larger amounts (more likely to be grand total)
                if value >= 100:
                    score += 10
                
                scored_candidates.append((value, score))
    
    if scored_candidates:
        # Sort by score (descending), then by value (descending) as tiebreaker
        scored_candidates.sort(key=lambda x: (x[1], x[0]), reverse=True)
        best_value = scored_candidates[0][0]
        logger.debug(f"Best amount from keyword search: {best_value} with score {scored_candidates[0][1]}")
        return best_value
    
    # ========================================================================
    # Pass 2: Look for amounts with currency indicators anywhere
    # ========================================================================
    logger.debug("No keyword-based amount found — searching for currency-prefixed amounts")
    
    # Split text into smaller chunks by currency indicators and extract nearby numbers
    currency_candidates: list[float] = []
    
    for match in _CURRENCY_INDICATORS.finditer(normalized):
        # Look backwards and forwards from the currency indicator
        start = max(0, match.start() - 100)
        end = min(len(normalized), match.end() + 50)
        context = normalized[start:end]
        
        for num_str in _MONEY_RE.findall(context):
            value = _parse_money(num_str)
            if value is not None and not _is_likely_vat_or_percentage(value, context):
                currency_candidates.append(value)
    
    if currency_candidates:
        best_value = max(currency_candidates)
        logger.debug(f"Best amount from currency search: {best_value}")
        return best_value
    
    # ========================================================================
    # Pass 3: Fallback — largest number in the whole text (with filtering)
    # ========================================================================
    logger.debug("No currency-prefixed amount found — using largest-number heuristic with filtering")
    
    filtered_values = []
    for line in lines:
        for num_str in _MONEY_RE.findall(line):
            value = _parse_money(num_str)
            if value is not None and not _is_likely_vat_or_percentage(value, line):
                filtered_values.append(value)
    
    if filtered_values:
        best_value = max(filtered_values)
        logger.debug(f"Best amount from fallback heuristic: {best_value}")
        return best_value
    
    logger.warning("No suitable amount found in invoice text — all numbers filtered as VAT/percentages")
    return None


# ===========================================================================
# Section 3 — Date extraction
# ===========================================================================

# Arabic written month names → zero-padded Gregorian month number
_ARABIC_MONTHS: dict[str, str] = {
    "يناير": "01", "فبراير": "02", "مارس": "03", "أبريل": "04",
    "مايو": "05",  "يونيو": "06", "يوليو": "07", "أغسطس": "08",
    "سبتمبر": "09", "أكتوبر": "10", "نوفمبر": "11", "ديسمبر": "12",
    # Common alternate spellings
    "ابريل": "04", "اغسطس": "08",
}

# English written month names → zero-padded month number
_ENGLISH_MONTHS: dict[str, str] = {
    "january": "01", "february": "02", "march": "03",  "april": "04",
    "may":     "05", "june":     "06", "july":   "07", "august":    "08",
    "september": "09", "october": "10", "november": "11", "december": "12",
    # Abbreviations
    "jan": "01", "feb": "02", "mar": "03", "apr": "04",
    "jun": "06", "jul": "07", "aug": "08", "sep": "09",
    "oct": "10", "nov": "11", "dec": "12",
}

# Lines that start with a date label (Arabic or English).
_DATE_LABEL_RE = re.compile(
    r"(?:date|invoice\s*date|تاريخ|التاريخ|تاريخ\s*الفاتورة)\s*[:\-]?\s*",
    re.IGNORECASE | re.UNICODE,
)

# Numeric date:  DD/MM/YYYY  |  MM-DD-YYYY  |  YYYY.MM.DD  etc.
_NUMERIC_DATE_RE = re.compile(
    r"\b(\d{1,4})[/\-.](\d{1,2})[/\-.](\d{2,4})\b"
)

# Written month, day first:   "15 March 2024"  |  "15 مارس 2024"
_WRITTEN_DMY_RE = re.compile(
    r"\b(\d{1,2})\s+([A-Za-zأ-ي]+)\s+(\d{4})\b",
    re.UNICODE,
)

# Written month, month first: "March 15, 2024"  |  "March 15 2024"
_WRITTEN_MDY_RE = re.compile(
    r"\b([A-Za-zأ-ي]+)\s+(\d{1,2}),?\s+(\d{4})\b",
    re.UNICODE,
)


def _month_name_to_number(name: str) -> Optional[str]:
    """Resolve an Arabic or English month name to a zero-padded month number."""
    return _ARABIC_MONTHS.get(name) or _ENGLISH_MONTHS.get(name.lower())


def _written_date_to_iso(day: str, month_name: str, year: str) -> Optional[str]:
    """Convert (day-str, month-name, year-str) to 'YYYY-MM-DD', or None."""
    month_num = _month_name_to_number(month_name)
    if month_num:
        return f"{year}-{month_num}-{day.zfill(2)}"
    return None


def _resolve_numeric_date(a: str, b: str, c: str) -> Optional[str]:
    """
    Interpret three numeric groups as a date and return 'YYYY-MM-DD'.

    Disambiguation rules (reflect GCC/Saudi Arabia conventions):
      • 4-digit first group  → YYYY-MM-DD
      • 4-digit last group   → DD/MM/YYYY  (default for GCC; fall back to MM/DD)
      • 2-digit last group   → treat as 20YY, assume DD/MM
    """
    try:
        ai, bi, ci = int(a), int(b), int(c)
    except ValueError:
        return None

    if len(a) == 4 and 1 <= bi <= 12 and 1 <= ci <= 31:
        # YYYY-MM-DD
        return f"{a}-{bi:02d}-{ci:02d}"

    if len(c) == 4:
        if 1 <= ai <= 31 and 1 <= bi <= 12:
            # DD/MM/YYYY  ← assumed default (GCC standard)
            return f"{c}-{bi:02d}-{ai:02d}"
        if 1 <= bi <= 31 and 1 <= ai <= 12:
            # MM/DD/YYYY  ← fallback
            return f"{c}-{ai:02d}-{bi:02d}"

    if len(c) == 2:
        year = 2000 + ci
        if 1 <= ai <= 31 and 1 <= bi <= 12:
            return f"{year}-{bi:02d}-{ai:02d}"

    return None


def _search_for_date(text: str) -> Optional[str]:
    """
    Try all date patterns against a text block and return the first match.
    Order: written-DMY → written-MDY → numeric.
    """
    m = _WRITTEN_DMY_RE.search(text)
    if m:
        result = _written_date_to_iso(m.group(1), m.group(2), m.group(3))
        if result:
            return result

    m = _WRITTEN_MDY_RE.search(text)
    if m:
        result = _written_date_to_iso(m.group(2), m.group(1), m.group(3))
        if result:
            return result

    m = _NUMERIC_DATE_RE.search(text)
    if m:
        return _resolve_numeric_date(m.group(1), m.group(2), m.group(3))

    return None


def _extract_date(text: str) -> Optional[str]:
    """
    Extract the invoice date from raw OCR text.

    Tries, in order of confidence:
      Pass 1 — Lines that contain a date label ("Date:", "التاريخ:", …).
      Pass 2 — Written month-name formats anywhere in the text.
      Pass 3 — First numeric date pattern anywhere in the text.

    Returns:
        Date string in "YYYY-MM-DD" format, or None if not found.
    """
    normalized = _normalize_numerals(text)
    lines = normalized.splitlines()

    # Pass 1 — labelled lines only
    for line in lines:
        if _DATE_LABEL_RE.search(line):
            result = _search_for_date(line)
            if result:
                return result

    # Pass 2 & 3 — scan the whole text
    return _search_for_date(normalized)


# ===========================================================================
# Section 4 — Public API
# ===========================================================================

def extract_invoice_data(raw_text: str, details: Optional[list] = None) -> dict:
    """
    Extract structured invoice fields from raw OCR text.

    Args:
        raw_text: Concatenated text output from the OCR engine.
        details: Optional list of dicts with 'bbox', 'text', 'confidence' keys.
                 When provided, enables spatial-proximity-based amount extraction
                 which is more accurate. When None, falls back to text-only regex.

    Returns:
        {
            "amount": float | None,   # detected total amount (SAR, etc.)
            "date":   str   | None,   # detected date in "YYYY-MM-DD" format
        }

    Both fields are None when extraction fails, allowing the Manea backend
    to flag the invoice for manual review rather than comparing bad data.

    Integration example:
        data = extract_invoice_data(raw_text)

        if data["amount"] is None or data["date"] is None:
            # Incomplete extraction — flag for auditor review
            transaction.status = "needs_review"
        elif abs(data["amount"] - transaction.amount) > 0.01:
            # Amount mismatch — flag as suspicious
            transaction.status = "flagged"
        else:
            transaction.status = "verified"
    """
    # Use bbox-based extraction if details available, otherwise text-only
    if details:
        amount = _extract_amount_with_bbox(raw_text, details)
    else:
        amount = _extract_amount(raw_text)
    
    date = _extract_date(raw_text)

    if amount is None:
        logger.warning("Amount not found in invoice text.")
    if date is None:
        logger.warning("Date not found in invoice text.")

    return {
        "amount": amount,
        "date": date,
    }
