"""
OCR Service — wraps EasyOCR to process uploaded invoice images.

Stable pipeline:
  - Single EasyOCR Reader singleton (lazy init)
  - PIL open → RGB convert → resize to max 1200px → EasyOCR → sort top-to-bottom
  - No rotation, no deskew, no preprocessing filters
"""

import io
import logging

import easyocr
import numpy as np
from PIL import Image, UnidentifiedImageError
from flask import current_app

logger = logging.getLogger(__name__)

_reader: easyocr.Reader | None = None


def _get_reader() -> easyocr.Reader:
    global _reader
    if _reader is None:
        languages = current_app.config["OCR_LANGUAGES"]
        use_gpu   = current_app.config["OCR_USE_GPU"]
        logger.info(
            "Initializing EasyOCR reader — languages: %s, GPU: %s",
            languages, use_gpu,
        )
        _reader = easyocr.Reader(languages, gpu=use_gpu)
        logger.info("EasyOCR reader is ready.")
    return _reader


def _load_and_resize(file_storage) -> np.ndarray:
    """
    Read uploaded file, convert to RGB, resize so longest side ≤ 1200px,
    return as NumPy uint8 array for EasyOCR.
    """
    image_bytes = file_storage.read()

    try:
        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    except UnidentifiedImageError as exc:
        raise ValueError(
            "The uploaded file could not be opened as an image. "
            "Please upload a valid PNG, JPG, TIFF, BMP, or WebP file."
        ) from exc

    _MAX = 1200
    if max(img.size) > _MAX:
        scale = _MAX / max(img.size)
        img = img.resize(
            (int(img.width * scale), int(img.height * scale)),
            Image.LANCZOS,
        )
        logger.info("Resized to %dx%d for OCR", img.width, img.height)
    else:
        logger.info("Image size: %dx%d (no resize needed)", img.width, img.height)

    return np.array(img)


def run_ocr(file_storage) -> str:
    """
    Run OCR on an uploaded file. Returns newline-joined text, top-to-bottom.
    """
    image_array = _load_and_resize(file_storage)
    reader = _get_reader()

    try:
        results = reader.readtext(
            image_array,
            detail=1,
            paragraph=False,
            batch_size=1,
        )
    except Exception as exc:
        raise RuntimeError(f"EasyOCR readtext() failed: {exc}") from exc

    if not results:
        logger.warning("EasyOCR returned no detections.")
        return ""

    results.sort(key=lambda r: r[0][0][1])
    return "\n".join(text for _bbox, text, _conf in results)


def run_ocr_with_details(file_storage) -> tuple[str, list]:
    """
    Run OCR on an uploaded file. Returns (raw_text, details list).
    """
    image_array = _load_and_resize(file_storage)
    reader = _get_reader()

    try:
        results = reader.readtext(
            image_array,
            detail=1,
            paragraph=False,
            batch_size=1,
        )
    except Exception as exc:
        raise RuntimeError(f"EasyOCR readtext() failed: {exc}") from exc

    if not results:
        logger.warning("EasyOCR returned no detections.")
        return "", []

    results.sort(key=lambda r: r[0][0][1])

    raw_text = "\n".join(text for _bbox, text, _conf in results)
    details  = [
        {"bbox": bbox, "text": text, "confidence": conf}
        for bbox, text, conf in results
    ]
    return raw_text, details