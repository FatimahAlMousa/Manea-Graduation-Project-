"""
OCR Service — wraps EasyOCR to process uploaded invoice images and PDFs.

Stable pipeline:
  - Single EasyOCR Reader singleton (lazy init)
  - PIL open → RGB convert → resize to max 1200px → EasyOCR → sort top-to-bottom
  - PDF: rendered via pymupdf (fitz) at 150 DPI, first page only
  - No rotation, no deskew, no preprocessing filters
"""

import io
import logging

import easyocr
import numpy as np
from PIL import Image, UnidentifiedImageError
from flask import current_app

logger = logging.getLogger(__name__)

_reader: easyocr.Reader | None = None

_MAX = 1200   # max pixels on longest side before OCR


def _get_reader() -> easyocr.Reader:
    global _reader
    if _reader is None:
        languages = current_app.config["OCR_LANGUAGES"]
        use_gpu   = current_app.config["OCR_USE_GPU"]
        logger.info(
            "Initializing EasyOCR reader — languages: %s, GPU: %s",
            languages, use_gpu,
        )
        _reader = easyocr.Reader(languages, gpu=use_gpu)
        logger.info("EasyOCR reader is ready.")
    return _reader


def _pdf_to_image(pdf_bytes: bytes) -> np.ndarray:
    """
    Render the first page of a PDF to a NumPy RGB array using pymupdf.
    Raises RuntimeError if pymupdf is not installed.
    """
    try:
        import fitz  # pymupdf
    except ImportError as exc:
        raise RuntimeError(
            "PDF support requires pymupdf. Run: pip install pymupdf"
        ) from exc

    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    except Exception as exc:
        raise ValueError("The uploaded PDF could not be opened.") from exc

    if doc.page_count == 0:
        raise ValueError("The PDF has no pages.")

    page = doc[0]
    # 2.0 zoom ≈ 144 DPI — good balance of quality vs RAM
    mat = fitz.Matrix(2.0, 2.0)
    pix = page.get_pixmap(matrix=mat, colorspace=fitz.csRGB)
    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(
        pix.height, pix.width, 3
    ).copy()
    pix = None
    doc.close()
    logger.info("PDF page 1 rendered: %dx%d", pix.width if False else arr.shape[1], arr.shape[0])
    return arr


def _resize(arr: np.ndarray) -> np.ndarray:
    """Resize so the longest side ≤ _MAX, preserving aspect ratio."""
    h, w = arr.shape[:2]
    longest = max(h, w)
    if longest <= _MAX:
        logger.info("Image %dx%d — no resize needed", w, h)
        return arr
    scale = _MAX / longest
    new_w, new_h = int(w * scale), int(h * scale)
    img = Image.fromarray(arr).resize((new_w, new_h), Image.LANCZOS)
    logger.info("Resized %dx%d → %dx%d", w, h, new_w, new_h)
    return np.array(img)


def _ocr_array(image_array: np.ndarray) -> list:
    """Run EasyOCR on a NumPy array. Returns sorted result list."""
    reader = _get_reader()
    try:
        results = reader.readtext(
            image_array,
            detail=1,
            paragraph=False,
            batch_size=1,
        )
    except Exception as exc:
        raise RuntimeError(f"EasyOCR readtext() failed: {exc}") from exc

    if not results:
        logger.warning("EasyOCR returned no detections.")
        return []

    results.sort(key=lambda r: r[0][0][1])
    return results


def _load(file_storage) -> np.ndarray:
    """
    Load an uploaded file (image or PDF) as a NumPy RGB array, resized.
    """
    image_bytes = file_storage.read()
    filename    = (file_storage.filename or "").lower()

    if filename.endswith(".pdf"):
        arr = _pdf_to_image(image_bytes)
    else:
        # Try as image; if that fails, try as PDF (some PDFs lack extension)
        try:
            img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            arr = np.array(img)
        except UnidentifiedImageError:
            # Fallback: attempt PDF rendering
            try:
                arr = _pdf_to_image(image_bytes)
                logger.info("File opened as PDF (no .pdf extension)")
            except Exception:
                raise ValueError(
                    "The uploaded file could not be opened as an image. "
                    "Please upload a valid PNG, JPG, TIFF, BMP, WebP, or PDF file."
                )

    return _resize(arr)


def run_ocr(file_storage) -> str:
    """Run OCR on an uploaded file. Returns newline-joined text, top-to-bottom."""
    results = _ocr_array(_load(file_storage))
    return "\n".join(text for _bbox, text, _conf in results)


def run_ocr_with_details(file_storage) -> tuple[str, list]:
    """Run OCR on an uploaded file. Returns (raw_text, details list)."""
    results  = _ocr_array(_load(file_storage))
    raw_text = "\n".join(text for _bbox, text, _conf in results)
    details  = [
        {"bbox": bbox, "text": text, "confidence": conf}
        for bbox, text, conf in results
    ]
    return raw_text, details