"""
Flagging Service — Exactly 3 flag types per project report:
  1. AI_AMOUNT_MISMATCH  — invoice amount != transaction amount
  2. OVERDUE_TRANSACTION — invoice not uploaded within 7 days of transaction
  3. DUPLICATE_INVOICE   — same invoice_number already in DB
"""
import json
from datetime import date, timedelta
from services.db import get_db


def _next_flag_ref(cur) -> str:
    cur.execute("SELECT COUNT(*) AS cnt FROM flags")
    return f"FLG-{cur.fetchone()['cnt'] + 1:03d}"


def flag_amount_mismatch(invoice_id: int) -> dict | None:
    """AI_AMOUNT_MISMATCH — triggered when invoice amount != matched transaction amount."""
    db  = get_db()
    cur = db.cursor()
    cur.execute("""
        SELECT i.invoice_id, i.employee_id, i.fund_request_id,
               i.invoice_amount, i.ocr_vendor_name,
               it.transaction_id, t.amount AS tx_amount
        FROM   invoices i
        JOIN   invoice_transactions it ON it.invoice_id = i.invoice_id
        JOIN   transactions t ON t.transaction_id = it.transaction_id
        WHERE  i.invoice_id = %s
    """, (invoice_id,))
    row = cur.fetchone()
    if not row: return None

    inv_amt = float(row["invoice_amount"] or 0)
    tx_amt  = float(row["tx_amount"] or 0)
    if inv_amt <= 0 or tx_amt <= 0: return None

    diff_pct = abs(inv_amt - tx_amt) / max(inv_amt, tx_amt)
    if diff_pct <= 0.001:  # exact or near-exact match — no flag
        return None

    diff_sar = abs(inv_amt - tx_amt)
    ref = _next_flag_ref(cur)
    # Close existing overdue flag for this transaction first
    cur.execute("""
        UPDATE flags SET status='RESOLVED', resolved_at=NOW()
        WHERE transaction_id=%s AND flag_reason='OVERDUE_TRANSACTION' AND status='OPEN'
    """, (row["transaction_id"],))

    cur.execute("""
        INSERT INTO flags
            (flag_ref, fund_request_id, transaction_id, invoice_id, employee_id,
             flag_reason, priority, status, details)
        VALUES (%s,%s,%s,%s,%s,'AI_AMOUNT_MISMATCH',%s,'OPEN',%s)
    """, (ref, row["fund_request_id"], row["transaction_id"], invoice_id,
          row["employee_id"],
          'HIGH' if diff_pct > 0.10 else 'MEDIUM',
          f"Invoice amount (SAR {inv_amt:,.2f}) does not match transaction amount (SAR {tx_amt:,.2f}). Difference: SAR {diff_sar:,.2f}."))

    cur.execute("UPDATE invoices SET verification_status='FLAGGED' WHERE invoice_id=%s", (invoice_id,))
    cur.execute("UPDATE transactions SET verification_status='FLAGGED' WHERE transaction_id=%s",
                (row["transaction_id"],))

    # Notify auditor (user_id=1 or any AUDITOR)
    cur.execute("""
        INSERT INTO notifications (user_id, type, message)
        SELECT u.user_id,
               'FLAGGED_TRANSACTION',
               CONCAT(%s, ': Amount mismatch — invoice SAR ', %s, ' vs transaction SAR ', %s)
        FROM users u WHERE u.role='AUDITOR' AND u.is_active=1 LIMIT 3
    """, (ref, f"{inv_amt:,.2f}", f"{tx_amt:,.2f}"))

    db.commit()
    return {"flag_ref": ref, "type": "AI_AMOUNT_MISMATCH", "diff": diff_sar}


def flag_duplicate_invoice(invoice_id: int) -> dict | None:
    """DUPLICATE_INVOICE — same invoice_number already in DB."""
    db  = get_db()
    cur = db.cursor()
    cur.execute("""
        SELECT invoice_id, employee_id, fund_request_id,
               invoice_number, invoice_amount
        FROM   invoices WHERE invoice_id = %s
    """, (invoice_id,))
    inv = cur.fetchone()
    if not inv or not inv["invoice_number"]: return None

    cur.execute("""
        SELECT invoice_id, uploaded_at FROM invoices
        WHERE  invoice_number = %s AND invoice_id != %s
        ORDER  BY uploaded_at LIMIT 1
    """, (inv["invoice_number"], invoice_id))
    original = cur.fetchone()
    if not original: return None

    ref = _next_flag_ref(cur)
    # Resolve any existing overdue flag for this fund request
    cur.execute("""
        UPDATE flags SET status='RESOLVED', resolved_at=NOW()
        WHERE fund_request_id=%s AND flag_reason='OVERDUE_TRANSACTION' AND status='OPEN'
    """, (inv["fund_request_id"],))

    # Get transaction_id for this invoice
    cur.execute("""
        SELECT transaction_id FROM invoice_transactions WHERE invoice_id=%s LIMIT 1
    """, (invoice_id,))
    tx_row = cur.fetchone()
    tx_id = tx_row["transaction_id"] if tx_row else None

    cur.execute("""
        INSERT INTO flags
            (flag_ref, fund_request_id, transaction_id, invoice_id, employee_id,
             flag_reason, priority, status, details)
        VALUES (%s,%s,%s,%s,%s,'DUPLICATE_INVOICE','HIGH','OPEN',%s)
    """, (ref, inv["fund_request_id"], tx_id, invoice_id, inv["employee_id"],
          f"Invoice {inv['invoice_number']} submitted again. Original upload: {original['uploaded_at']}."))

    cur.execute("UPDATE invoices SET verification_status='FLAGGED' WHERE invoice_id=%s", (invoice_id,))

    cur.execute("""
        INSERT INTO notifications (user_id, type, message)
        SELECT u.user_id, 'FLAGGED_TRANSACTION',
               CONCAT(%s, ': Duplicate invoice ', %s, ' detected')
        FROM users u WHERE u.role='AUDITOR' AND u.is_active=1 LIMIT 3
    """, (ref, inv["invoice_number"]))

    db.commit()
    return {"flag_ref": ref, "type": "DUPLICATE_INVOICE"}


def flag_overdue_invoices() -> list:
    """
    OVERDUE_TRANSACTION — invoice not uploaded within 7 days of transaction date.
    Scans all active transactions with no linked invoice.
    """
    db  = get_db()
    cur = db.cursor()
    today = date.today()
    deadline = today - timedelta(days=7)

    cur.execute("""
        SELECT t.transaction_id, t.fund_request_id, t.transaction_date,
               t.amount, t.description,
               ec.user_id AS employee_id,
               fr.request_title
        FROM   transactions t
        JOIN   employee_cards ec ON ec.card_id = t.card_id
        JOIN   fund_requests fr  ON fr.fund_request_id = t.fund_request_id
        WHERE  t.transaction_date <= %s
          AND  t.verification_status = 'UNMATCHED'
          AND  t.fund_request_id IS NOT NULL
          AND  NOT EXISTS (
              SELECT 1 FROM invoice_transactions it
              WHERE  it.transaction_id = t.transaction_id
          )
          AND  NOT EXISTS (
              SELECT 1 FROM flags f
              WHERE  f.transaction_id = t.transaction_id
                AND  f.flag_reason = 'OVERDUE_TRANSACTION'
          )
    """, (deadline,))
    overdue = cur.fetchall()

    created = []
    for tx in overdue:
        ref = _next_flag_ref(cur)
        days_late = (today - tx["transaction_date"]).days - 7
        cur.execute("""
            INSERT INTO flags
                (flag_ref, fund_request_id, transaction_id, employee_id,
                 flag_reason, priority, status, details)
            VALUES (%s,%s,%s,%s,'OVERDUE_TRANSACTION','HIGH','OPEN',%s)
        """, (ref, tx["fund_request_id"], tx["transaction_id"], tx["employee_id"],
              f"Invoice not uploaded within 7 days. Transaction: {tx['transaction_date']}. {days_late} days overdue."))

        cur.execute("""
            INSERT INTO notifications (user_id, type, message)
            SELECT u.user_id, 'INVOICE_OVERDUE',
                   CONCAT(%s, ': Overdue invoice — ', %s)
            FROM users u WHERE u.role='AUDITOR' AND u.is_active=1 LIMIT 3
        """, (ref, tx["request_title"]))

        cur.execute("UPDATE transactions SET verification_status='FLAGGED' WHERE transaction_id=%s",
                    (tx["transaction_id"],))
        created.append({"flag_ref": ref, "transaction_id": tx["transaction_id"]})

    db.commit()
    return created


def run_all_flags_for_invoice(invoice_id: int) -> list:
    """Run all flag checks after invoice upload + matching.
    If duplicate is detected, skip mismatch check — duplicate takes priority."""
    results = []
    r = flag_duplicate_invoice(invoice_id)
    if r:
        results.append(r)
        # Skip mismatch check if duplicate already flagged
        return results
    r = flag_amount_mismatch(invoice_id)
    if r: results.append(r)
    return results
