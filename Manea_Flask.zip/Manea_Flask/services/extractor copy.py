"""
Invoice Data Extractor

Parses raw OCR text (Arabic or English) to pull out structured invoice fields.
No ML training is required — the module relies entirely on:
  - Arabic-to-Western numeral normalization
  - STRICT keyword-based amount extraction
  - Multi-format date pattern matching

Extracted fields
----------------
amount : float | None   — the total/grand-total monetary value
date   : str   | None   — the invoice date, normalized to "YYYY-MM-DD"

Integration note
----------------
The public function extract_invoice_data() returns a plain dict.  The Manea
backend can compare its values directly against a database transaction record:

    result = extract_invoice_data(raw_text)
    if result["amount"] != transaction.amount:
        flag_for_audit(transaction)

Bounding box format
-------------------
Each bounding box is a list of 4 points: [[x0,y0],[x1,y1],[x2,y2],[x3,y3]]
representing the corners of the detected text region in pixel coordinates.
"""

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


# ===========================================================================
# Section 1 — Numeral normalization
# ===========================================================================

_ARABIC_TO_WESTERN = str.maketrans("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669\u066b\u066c", "0123456789.,")


def _normalize_numerals(text: str) -> str:
    return text.translate(_ARABIC_TO_WESTERN)


# ===========================================================================
# Section 2 — Amount extraction
# ===========================================================================

_TOTAL_KEYWORDS = [
    "total invoice", "invoice total", "grand total", "total amount",
    "amount due", "total amount due",
    "\u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629",
    "\u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629 \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a\u0629",
    "\u0627\u0644\u0645\u062c\u0645\u0648\u0639 \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a",
    "\u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0643\u0644\u064a",
    "\u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a \u0634\u0627\u0645\u0644",
    "\u0625\u062c\u0645\u0627\u0644\u064a",
    "\u0627\u0644\u0645\u062c\u0645\u0648\u0639",
    "\u0627\u0644\u0645\u0628\u0644\u063a \u0627\u0644\u0635\u0627\u0641\u064a",
    "\u0635\u0627\u0641\u064a \u0627\u0644\u0645\u0628\u0644\u063a",
    "\u0627\u0644\u0645\u0628\u0644\u063a \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a",
    "\u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a",
    "\u0627\u0644\u0645\u0628\u0644\u063a \u0627\u0644\u0646\u0647\u0627\u0626\u064a",
    "amount after tax", "total after tax", "net amount", "net total",
    "payable amount", "total payable",
]

_EXCLUDE_KEYWORDS = [
    "vat", "discount", "qty", "quantity", "unit", "%", "percent",
    "tax rate", "tax 1", "tax amount", "before tax", "amount before tax",
    "\u0636\u0631\u064a\u0628\u0629", "\u062e\u0635\u0645",
    "\u0643\u0645\u064a\u0629", "\u062a\u0643\u0644\u0641\u0629 \u0627\u0644\u0648\u062d\u062f\u0629",
]

_MONEY_PATTERN = r"(?<![\w.])([1-9]\d{0,2}(?:[,\u060c]\d{3})*(?:[.]\d{1,2})?|\d{1,7}[.]\d{1,2})(?![\w,])"


def _extract_numbers_from_line(line: str) -> list:
    normalized = _normalize_numerals(line)
    normalized = re.sub(
        r"(?:SAR|SR|QAR|AED|KWD|USD|\$|\u0631\u064a\u0627\u0644|\u0631\.\u0633)\s*(?=[1-9])",
        "", normalized, flags=re.IGNORECASE
    )
    normalized = re.sub(r"(\d)\s*[,\u060c]\s*(\d{3}(?=[,\u060c.\s]|$))", r"\1,\2", normalized)
    matches = re.findall(_MONEY_PATTERN, normalized)
    values = []
    for match in matches:
        try:
            cleaned = match.replace(",", "").replace("\u060c", "")
            value = float(cleaned)
            if value > 0:
                values.append(value)
        except ValueError:
            continue
    return values


def _line_contains_keyword(line: str, keywords: list) -> bool:
    line_lower = line.lower()
    return any(kw.lower() in line_lower for kw in keywords)


def _extract_amount(text: str) -> Optional[float]:
    lines = text.splitlines()
    total_amounts = []
    for i, line in enumerate(lines):
        if _line_contains_keyword(line, _EXCLUDE_KEYWORDS):
            continue
        if _line_contains_keyword(line, _TOTAL_KEYWORDS):
            numbers = _extract_numbers_from_line(line)
            if numbers:
                total_amounts.extend(numbers)
            else:
                # Value may be on next line (label-then-value layout)
                # e.g. "Amount After Tax\n65.00"
                for delta in (1, 2):
                    if i + delta < len(lines):
                        next_nums = _extract_numbers_from_line(lines[i + delta])
                        if next_nums:
                            total_amounts.extend(next_nums)
                            break
    if total_amounts:
        return max(total_amounts)
    logger.warning("\u26a0 No lines with total keywords found. Using fallback...")
    all_amounts = []
    for line in text.splitlines():
        if _line_contains_keyword(line, _EXCLUDE_KEYWORDS):
            continue
        all_amounts.extend(_extract_numbers_from_line(line))
    if all_amounts:
        best = max(all_amounts)
        logger.warning("\u26a0 RESULT (FALLBACK): %s (largest number in document)", best)
        return best
    return None


def _extract_amount_with_bbox(text: str, details: list) -> Optional[float]:
    return _extract_amount(text)


# ===========================================================================
# Section 3 — Date extraction
# ===========================================================================

_ARABIC_MONTHS = {
    "\u064a\u0646\u0627\u064a\u0631": "01", "\u0641\u0628\u0631\u0627\u064a\u0631": "02",
    "\u0645\u0627\u0631\u0633": "03", "\u0623\u0628\u0631\u064a\u0644": "04",
    "\u0645\u0627\u064a\u0648": "05", "\u064a\u0648\u0646\u064a\u0648": "06",
    "\u064a\u0648\u0644\u064a\u0648": "07", "\u0623\u063a\u0633\u0637\u0633": "08",
    "\u0633\u0628\u062a\u0645\u0628\u0631": "09", "\u0623\u0643\u062a\u0648\u0628\u0631": "10",
    "\u0646\u0648\u0641\u0645\u0628\u0631": "11", "\u062f\u064a\u0633\u0645\u0628\u0631": "12",
    "\u0627\u0628\u0631\u064a\u0644": "04", "\u0627\u063a\u0633\u0637\u0633": "08",
}

_ENGLISH_MONTHS = {
    "january": "01", "february": "02", "march": "03", "april": "04",
    "may": "05", "june": "06", "july": "07", "august": "08",
    "september": "09", "october": "10", "november": "11", "december": "12",
    "jan": "01", "feb": "02", "mar": "03", "apr": "04",
    "jun": "06", "jul": "07", "aug": "08", "sep": "09",
    "oct": "10", "nov": "11", "dec": "12",
}

_DATE_LABEL_RE = re.compile(
    r"(?:e[\s\-]*invoice\s*date|invoice\s*date|date"
    r"|\u062a\u0627\u0631\u064a\u062e\s*\u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629"
    r"|\u0627\u0644\u062a\u0627\u0631\u064a\u062e|\u062a\u0627\u0631\u064a\u062e)"
    r"\s*[:#\-]?\s*",
    re.IGNORECASE | re.UNICODE,
)
_NUMERIC_DATE_RE = re.compile(r"\b(\d{1,4})[/\-.](\d{1,2})[/\-.](\d{2,4})\b")
_WRITTEN_DMY_RE  = re.compile(r"\b(\d{1,2})\s+([A-Za-z\u0623-\u064a]+)\s+(\d{4})\b", re.UNICODE)
_WRITTEN_MDY_RE  = re.compile(r"\b([A-Za-z\u0623-\u064a]+)\s+(\d{1,2}),?\s+(\d{4})\b", re.UNICODE)


def _month_name_to_number(name: str) -> Optional[str]:
    return _ARABIC_MONTHS.get(name) or _ENGLISH_MONTHS.get(name.lower())


def _written_date_to_iso(day: str, month_name: str, year: str) -> Optional[str]:
    m = _month_name_to_number(month_name)
    return f"{year}-{m}-{day.zfill(2)}" if m else None


def _resolve_numeric_date(a: str, b: str, c: str) -> Optional[str]:
    try:
        ai, bi, ci = int(a), int(b), int(c)
    except ValueError:
        return None
    if len(a) == 4 and 1 <= bi <= 12 and 1 <= ci <= 31:
        return f"{a}-{bi:02d}-{ci:02d}"
    if len(c) == 4:
        if 1 <= ai <= 31 and 1 <= bi <= 12:
            return f"{c}-{bi:02d}-{ai:02d}"
        if 1 <= bi <= 31 and 1 <= ai <= 12:
            return f"{c}-{ai:02d}-{bi:02d}"
    if len(c) == 2:
        year = 2000 + ci
        if 1 <= ai <= 31 and 1 <= bi <= 12:
            return f"{year}-{bi:02d}-{ai:02d}"
    return None


def _search_for_date(text: str) -> Optional[str]:
    m = _WRITTEN_DMY_RE.search(text)
    if m:
        r = _written_date_to_iso(m.group(1), m.group(2), m.group(3))
        if r: return r
    m = _WRITTEN_MDY_RE.search(text)
    if m:
        r = _written_date_to_iso(m.group(2), m.group(1), m.group(3))
        if r: return r
    m = _NUMERIC_DATE_RE.search(text)
    if m:
        return _resolve_numeric_date(m.group(1), m.group(2), m.group(3))
    return None


def _extract_date(text: str) -> Optional[str]:
    normalized = _normalize_numerals(text)
    for line in normalized.splitlines():
        if _DATE_LABEL_RE.search(line):
            r = _search_for_date(line)
            if r: return r
    return _search_for_date(normalized)


# ===========================================================================
# Section 4 — Currency extraction
# ===========================================================================

_CURRENCY_PATTERNS = [
    (re.compile(r"SAR", re.IGNORECASE), "SAR"),
    (re.compile(r"SR(?=\s*[\d,\u060c\u0660-\u0669]|$|\s)", re.IGNORECASE), "SAR"),
    (re.compile(r"(?<![A-Za-z])SR(?![A-Za-z])", re.IGNORECASE), "SAR"),
    (re.compile(r"Saudi\s+Riyal", re.IGNORECASE), "SAR"),
    (re.compile(r"\u0631\u064a\u0627\u0644", re.UNICODE), "SAR"),
    (re.compile(r"\u0631\.\u0633", re.UNICODE), "SAR"),
    (re.compile(r"\bUSD\b", re.IGNORECASE), "USD"),
    (re.compile(r"\$"), "USD"),
    (re.compile(r"\bDollar\b", re.IGNORECASE), "USD"),
    (re.compile(r"\u062f\u0648\u0644\u0627\u0631", re.UNICODE), "USD"),
]

_AMOUNT_LINE_KEYWORDS = _TOTAL_KEYWORDS + ["total", "amount", "\u0627\u0644\u0645\u0628\u0644\u063a"]


def _find_currencies_in_text(text: str) -> list:
    found, seen = [], set()
    for pattern, code in _CURRENCY_PATTERNS:
        for match in pattern.finditer(text):
            pos = match.start()
            if pos not in seen:
                seen.add(pos)
                found.append((pos, code))
    found.sort(key=lambda x: x[0])
    return found


def _extract_currency(text: str) -> Optional[str]:
    for line in text.splitlines():
        line_lower = line.lower()
        if any(kw.lower() in line_lower for kw in _AMOUNT_LINE_KEYWORDS):
            hits = _find_currencies_in_text(line)
            if hits:
                return hits[0][1]
    hits = _find_currencies_in_text(text)
    if hits:
        codes = list(dict.fromkeys(c for _, c in hits))
        return codes[0]
    return None


# ===========================================================================
# Section 5 — Invoice number extraction
# ===========================================================================

_INV_ARABIC_RE = re.compile(
    r'(?:'
    # رقم/رفم/رهم + ال...ورة/وره
    # Loose match: accepts OCR-mangled forms like الهائورة, الهاتورة, etc.
    # Only requires: starts with رX م, then ال, ends with ورة or وره
    r'\u0631[\u0642\u0641\u0647\u0648]\u0645\s+\u0627\u0644[\u0600-\u06ff]+\u0648[\u0631\u062f][\u0629\u0647]'
    r'|\u0641[\u0627\u0623]\u062a\u0648\u0631[\u0629\u0647]\s+\u0631[\u0642\u0641\u0647]\u0645'
    r')',
    re.UNICODE,
)

_INV_ENGLISH_RE = re.compile(
    r'(?:e[\s\-]*invoice\b|inv[a-z]*\s*(?:no\.?|number|#|num\.?)|invoice\s*(?:no\.?|number|#|num\.?))',
    re.IGNORECASE,
)

_INV_VALUE_RE = re.compile(
    r'([A-Za-z0-9][A-Za-z0-9\-_\/]{2,30})',
    re.UNICODE,
)


def _extract_invoice_number(text: str) -> Optional[str]:
    lines = text.splitlines()

    def _first_number_after(line: str, match_end: int) -> Optional[str]:
        remainder = line[match_end:].lstrip(": #|\t\u200f\u200e\u202a\u202b ")
        m = _INV_VALUE_RE.search(remainder)
        return m.group(1).strip("-_/ ") if m else None

    _date_re  = re.compile(r"\d{4}[-/.]\d{2}[-/.]\d{2}")
    _year_re  = re.compile(r"^(?:19|20)\d{2}$")

    def _clean(val: str) -> Optional[str]:
        val = val.strip("-_/ ")
        if not val or _year_re.match(val):
            return None
        # Must contain at least one digit — rejects "VAT", "NO", etc.
        if not re.search(r"\d", val):
            return None
        longest = max((len(m.group()) for m in re.finditer(r"\d+", val)), default=0)
        return val if longest < 10 else None

    # Pass 1: label scan — after, before (RTL), prev line, next line
    for i, line in enumerate(lines):
        for pat in (_INV_ARABIC_RE, _INV_ENGLISH_RE):
            m = pat.search(line)
            if not m:
                continue

            # (a) after label on same line
            val = _clean(_first_number_after(line, m.end()) or "")
            if val:
                logger.info("Invoice number (after label): %s", val)
                return val

            # (b) before label — RTL: "21160 :رقم الفاتورة"
            prefix = line[:m.start()].rstrip(": #|\t\u200f\u200e ")
            if prefix and not _date_re.search(prefix):
                for pm in reversed(list(_INV_VALUE_RE.finditer(prefix))):
                    val = _clean(pm.group(1))
                    if val and not _year_re.match(val):
                        logger.info("Invoice number (before label/RTL): %s", val)
                        return val

            # (c) previous lines — scan up to 3 lines back
            # skipping noise lines (single words, partial labels, empty)
            def _is_noise(s: str) -> bool:
                """True if line is OCR noise / partial label, not a real value."""
                if not s: return True
                # Lines that are just a field label fragment
                if re.match(r"^[\u0600-\u06ff\s:]{1,8}:?\s*$", s, re.UNICODE): return True
                # Known single-word noise tokens
                noise_words = {"اسم","الم","فاسم","البائع","المرع","الفرع",
                               "مالي","الإج","اسما","فاسما"}
                if s in noise_words: return True
                # Short Arabic-only lines (likely partial label fragments)
                if (len(s) <= 8
                    and not re.search(r"[A-Za-z0-9]", s)
                    and s.rstrip(": \u200f\u200e")):
                    return True
                # Branch/location lines — not invoice numbers
                # e.g. "معرض ومستودع المنار", "الفرع: المنار"
                branch_re = re.compile(
                    r"\u0645\u0639\u0631\u0636|\u0645\u0633\u062a\u0648\u062f\u0639"
                    r"|\u0627\u0644\u0645\u0646\u0627\u0631|\u0641\u0631\u0639",
                    re.UNICODE,
                )
                if branch_re.search(s) and not re.search(r"\d", s):
                    return True
                return False

            for back in range(1, 5):
                if i - back < 0:
                    break
                prev = lines[i - back].strip()
                if not prev:
                    continue
                if _date_re.search(prev) or pat.search(prev):
                    break  # hit a date or another label — stop
                if _is_noise(prev):
                    continue  # skip noise, keep looking back
                vm = _INV_VALUE_RE.search(prev)
                if vm:
                    val = _clean(vm.group(1))
                    if val and not _year_re.match(val):
                        logger.info("Invoice number (prev line -%d): %s", back, val)
                        return val
                break  # real line with no invoice number — stop

            # (d) scan forward up to 5 lines — skip date/noise lines
            # Handles table layouts where label and value are rows apart
            _fwd_noise_words = {
                "customer", "cash", "credit", "cheque", "payment", "mode",
                "date", "salesman", "warehouse", "type", "remarks",
            }
            for fwd in range(1, 10):  # scan up to 9 lines forward for table layouts
                if i + fwd >= len(lines):
                    break
                nxt = lines[i + fwd].strip()
                if not nxt:
                    continue
                # Skip date lines
                if _date_re.search(nxt):
                    continue
                # Skip known table header words
                if nxt.lower() in _fwd_noise_words:
                    continue
                vm = _INV_VALUE_RE.search(nxt)
                if vm:
                    val = _clean(vm.group(1))
                    if val and not _year_re.match(val):
                        logger.info("Invoice number (next line +%d): %s", fwd, val)
                        return val
                # Stop only if line has BOTH letters AND digits
                # Pure-text lines like "Customer", "فاتورة ضريبية" are headers — keep scanning
                if (re.search(r"[A-Za-z\u0600-\u06ff]", nxt)
                        and re.search(r"\d", nxt)
                        and len(nxt) > 4):
                    break

    # Pass 2: fallback
    fallback = re.search(
        r'(?:'
        r'\u0631\u0642\u0645\s+[\u0627\u0623\u0625\u0622\u0671]\u0644\s*\u0641[\u0627\u0623]\u062a\u0648\u0631[\u0629\u0647]'
        r'|\u0641[\u0627\u0623]\u062a\u0648\u0631[\u0629\u0647]\s+\u0631\u0642\u0645'
        r'|e[\s\-]*invoice\b'
        r'|(?:invoice|inv)\s*(?:no\.?|number|#|num\b)'
        r')[\s:#|]*'
        r'([A-Za-z0-9][A-Za-z0-9\-_\/]{2,30})',
        text, re.IGNORECASE | re.UNICODE,
    )
    if fallback:
        val = _clean(fallback.group(1))
        if val:
            logger.info("Invoice number (fallback): %s", val)
            return val

    logger.warning("Invoice number not found in invoice text.")
    return None


# ===========================================================================
# Section 5b — Vendor name extraction
# ===========================================================================

_VN_ENTITY_AR = re.compile(
    r"\u0645\u0624\u0633\u0633\u0629|\u0645\u0624\u0633\u0633\u0647|\u0634\u0631\u0643\u0629|\u0634\u0631\u0643\u0647|\u0645\u062c\u0645\u0648\u0639\u0629|\u0645\u062c\u0645\u0648\u0639\u0647|\u0645\u0635\u0646\u0639|\u0645\u0643\u062a\u0628"
    r"|\u0644\u0644\u062a\u062c\u0627\u0631\u0629|\u0644\u0644\u0645\u0642\u0627\u0648\u0644\u0627\u062a|\u0644\u0644\u0643\u0647\u0631\u0628\u0627\u0621|\u0644\u0644\u062f\u064a\u0643\u0648\u0631|\u0644\u0644\u062e\u062f\u0645\u0627\u062a|\u0644\u0644\u062a\u0648\u0631\u064a\u062f",
    re.UNICODE,
)
_VN_ENTITY_EN = re.compile(
    r"\bEst\.?\b|\bCo\.?\b|\bLtd\.?\b|\bLLC\b|\bCorp\.?\b|\bInc\.?\b"
    r"|\bGroup\b|\bTrading\b|\bCompany\b|\bEnterprises?\b"
    r"|\bFactory\b|\bSupply\b|\bSolutions?\b|\bTechnology\b|\bIndustries\b",
    re.IGNORECASE,
)
_VN_REJECT_EN = re.compile(
    r"^\s*(?:invoice\s*(?:no|number|date|#)|vat\s*(?:no|number|reg)|cr\s*no|"
    r"date|total|subtotal|amount|balance|discount|paid|receipt|"
    r"bill\s*to|ship\s*to|customer|client|item|description|qty|unit|price|"
    r"tel|phone|fax|address|www\.|http)", re.IGNORECASE,
)
_VN_REJECT_AR = re.compile(
    r"\u0627\u0633\u0645\s*\u0627\u0644\u0639\u0645\u064a\u0644|\u0639\u0646\u0648\u0627\u0646\s*\u0627\u0644\u0639\u0645\u064a\u0644"
    r"|\u0631\u0642\u0645\s*\u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629|\u062a\u0627\u0631\u064a\u062e\s*\u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629"
    r"|\u0627\u0644\u0631\u0642\u0645\s*\u0627\u0644\u0636\u0631\u064a\u0628\u064a|\u0627\u0644\u0633\u062c\u0644\s*\u0627\u0644\u062a\u062c\u0627\u0631\u064a"
    r"|\u0627\u0633\u0645\s*\u0627\u0644\u0641\u0631\u0639|\u0627\u0633\u0645\s*\u0627\u0644\u0628\u0627\u0626\u0639|\u0627\u0633\u0645\s*\u0627\u0644\u0639\u0645\u064a\u0644"
    r"|\u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a|\u0627\u0644\u0627\u062c\u0645\u0627\u0644\u064a|\u0627\u0644\u0645\u062c\u0645\u0648\u0639|\u0627\u0644\u062e\u0635\u0645"
    r"|\u0627\u0644\u0636\u0631\u064a\u0628\u0629|\u0627\u0644\u0645\u0628\u0644\u063a|\u0627\u0644\u0643\u0645\u064a\u0629|\u0645\u0644\u0627\u062d\u0638\u0627\u062a|\u0627\u0644\u062a\u0648\u0642\u064a\u0639",
    re.UNICODE,
)
_VN_DESCRIPTOR = re.compile(
    r"^(?:wholesale(?:\s+and\s+retail)?|retail(?:\s+and\s+wholesale)?"
    r"|import(?:\s+(?:and|&)\s+export)?|general\s+trading|manufacturing"
    r"|\u0627\u0644\u062c\u0645\u0644\u0629(?:\s+\u0648\u0627\u0644\u062a\u062c\u0632\u0626\u0629)?|\u0627\u0644\u062a\u062c\u0632\u0626\u0629)$",
    re.IGNORECASE | re.UNICODE,
)
_VN_OCR_FIXES = [
    (re.compile("\u0645\u0624\u0633\u0633\u0647"), "\u0645\u0624\u0633\u0633\u0629"),
    (re.compile("\u0634\u0631\u0643\u0647"), "\u0634\u0631\u0643\u0629"),
]
_VN_FIELD_LABEL_RE = re.compile(
    r"(?:\u0627\u0633\u0645\s*\u0627\u0644\u0641\u0631\u0639|\u0627\u0633\u0645\s*\u0627\u0644\u0628\u0627\u0626\u0639|\u0627\u0633\u0645\s*\u0627\u0644\u0639\u0645\u064a\u0644"
    r"|\u0639\u0646\u0648\u0627\u0646\s*\u0627\u0644\u0639\u0645\u064a\u0644|\u0631\u0642\u0645\s*\u0647\u0627\u062a\u0641\s*\u0627\u0644\u0641\u0631\u0639"
    r"|bill\s*to|ship\s*to|customer\s*name|branch\s*name)\s*:?\s*$",
    re.IGNORECASE | re.UNICODE,
)


def _vn_has_entity(s: str) -> bool:
    return bool(_VN_ENTITY_AR.search(s) or _VN_ENTITY_EN.search(s))


def _vn_is_valid(s: str) -> bool:
    if not s or len(s) < 6: return False
    if _VN_REJECT_EN.search(s): return False
    if _VN_REJECT_AR.search(s): return False
    if _VN_DESCRIPTOR.match(s): return False
    if re.match(r"^\u0644[\u0644\u0627]?\S", s, re.UNICODE) and len(s.split()) < 3: return False
    lc = len(re.sub(r"[^\u0600-\u06ffA-Za-z]", "", s))
    if len(s) > 4 and lc / len(s) < 0.40: return False
    if re.search(r"\d{7,}", s): return False
    if re.search(r"https?://|www\.|@", s): return False
    return 2 <= len(s.split()) <= 10


def _extract_vendor_name(text: str) -> Optional[str]:
    lines = text.splitlines()
    total = len(lines)
    top30 = max(1, int(total * 0.30))
    top60 = max(1, int(total * 0.60))

    def _prev_is_label(i):
        if i == 0: return False
        return bool(_VN_FIELD_LABEL_RE.search(lines[i-1].strip()))

    def _collect(limit, need_entity):
        out = []
        for i in range(min(limit, len(lines))):
            s = lines[i].strip()
            if not s or not _vn_is_valid(s) or _prev_is_label(i): continue
            if need_entity and not _vn_has_entity(s): continue
            out.append((i, s))
        return out

    candidates = _collect(top30, True) or _collect(top60, True)
    if not candidates:
        logger.warning("Vendor: no candidates found")
        return None

    def _score(item):
        _, s = item
        sc = 5 if _vn_has_entity(s) else 0
        w = len(s.split())
        if 2 <= w <= 6: sc += 3
        if len(s) > 8: sc += 1
        has_ar = any("\u0600" <= c <= "\u06ff" for c in s)
        has_en = any(c.isascii() and c.isalpha() for c in s)
        if has_ar and has_en: sc += 2
        if s.strip() in {"\u0634\u0631\u0643\u0629","\u0645\u0624\u0633\u0633\u0629","\u0645\u0624\u0633\u0633\u0647","\u0634\u0631\u0643\u0647"}: sc -= 10
        return sc

    candidates.sort(key=_score, reverse=True)
    best_idx, best_line = candidates[0]

    result = " ".join(best_line.split())
    for pat, repl in _VN_OCR_FIXES:
        result = pat.sub(repl, result)

    # Merge adjacent lines to build complete vendor name
    for delta in (1, -1):
        adj_i = best_idx + delta
        if not (0 <= adj_i < len(lines)): continue
        adj = lines[adj_i].strip()
        if not adj: continue
        if not _vn_has_entity(result): continue

        adj_words = adj.split()
        # Case A: continuation line like "لتجارة الجملة والتجزئة"
        is_cont = bool(re.match(r"^\u0644[\u0644\u0627]?\S", adj, re.UNICODE) and len(adj_words) >= 2)
        # Case B: single Arabic word completing the name (e.g. "الأسد" after "مؤسسة تقنية")
        is_arabic_word = (
            len(adj_words) == 1
            and re.match(r"^[\u0600-\u06ff]+$", adj, re.UNICODE)
            and not re.search(r"\d", adj)
            and len(adj) >= 3
        )

        if (is_cont or is_arabic_word) and not _VN_DESCRIPTOR.match(adj):
            merged = (result + " " + adj) if delta == 1 else (adj + " " + result)
            if len(merged.split()) <= 10:
                result = merged
                break

    # Deduplicate
    words = result.split()
    half = len(words) // 2
    if half > 1 and words[:half] == words[half:half*2]:
        result = " ".join(words[:half])

    logger.info("Vendor SELECTED: %r", result)
    return result if result else None


# ===========================================================================
# Section 6 — Public API
# ===========================================================================

def extract_invoice_data(raw_text: str, details: Optional[list] = None) -> dict:
    amount         = _extract_amount(raw_text)
    date           = _extract_date(raw_text)
    currency       = _extract_currency(raw_text)
    invoice_number = _extract_invoice_number(raw_text)
    vendor_name    = _extract_vendor_name(raw_text)

    if amount is None:        logger.warning("Amount not found in invoice text.")
    if date is None:          logger.warning("Date not found in invoice text.")
    if currency is None:      logger.warning("Currency not found in invoice text.")
    if invoice_number is None: logger.warning("Invoice number not found in invoice text.")
    if vendor_name is None:   logger.warning("Vendor name not found in invoice text.")

    return {
        "amount":         amount,
        "date":           date,
        "currency":       currency,
        "invoice_number": invoice_number,
        "vendor_name":    vendor_name,
    }