"""
Invoice-to-Transaction Matching Service
Matches by: employee_id (via card) + amount similarity + date proximity
fund_request_id in transactions may be NULL (real bank CSV has no request ID)
"""
import difflib
from services.db import get_db


def _amount_score(inv_amt, tx_amt):
    if not inv_amt or not tx_amt: return 0.0
    ratio = min(inv_amt, tx_amt) / max(inv_amt, tx_amt)
    return ratio if ratio >= 0.90 else ratio * 0.4


def _date_score(inv_date, tx_date):
    if not inv_date or not tx_date: return 0.0
    delta = abs((inv_date - tx_date).days)
    return max(0.0, 1.0 - delta / 30.0)


def _desc_score(inv_vendor, tx_desc):
    if not inv_vendor or not tx_desc: return 0.0
    return difflib.SequenceMatcher(
        None, inv_vendor.lower().strip(), tx_desc.lower().strip()
    ).ratio()


def match_invoice(invoice_id: int) -> list:
    """
    Find best matching transaction for an invoice.
    Matches by: same employee + amount similarity + date proximity.
    Does NOT require fund_request_id to match (bank CSV has NULL).
    """
    db  = get_db()
    cur = db.cursor()

    # Get invoice + employee_id via fund_request
    cur.execute("""
        SELECT i.invoice_id, i.invoice_amount, i.invoice_date,
               i.ocr_vendor_name, i.fund_request_id,
               fr.employee_id
        FROM   invoices i
        JOIN   fund_requests fr ON fr.fund_request_id = i.fund_request_id
        WHERE  i.invoice_id = %s
    """, (invoice_id,))
    inv = cur.fetchone()
    if not inv: return []

    # Get ALL unmatched transactions for this employee via their card
    cur.execute("""
        SELECT t.transaction_id, t.transaction_date, t.amount,
               t.description, t.fund_request_id
        FROM   transactions t
        JOIN   employee_cards ec ON ec.card_id = t.card_id
        WHERE  ec.user_id = %s
          AND  t.verification_status != 'MATCHED'
    """, (inv["employee_id"],))
    candidates = cur.fetchall()

    results = []
    for tx in candidates:
        a = _amount_score(float(inv["invoice_amount"] or 0), float(tx["amount"]))
        d = _date_score(inv["invoice_date"], tx["transaction_date"])
        v = _desc_score(inv["ocr_vendor_name"], tx["description"])
        score = (a * 0.65) + (d * 0.25) + (v * 0.10)
        results.append({
            "transaction_id": tx["transaction_id"],
            "score":          round(score, 3),
            "amount_match":   a >= 0.99,
            "amount_score":   round(a, 3),
            "date_score":     round(d, 3),
        })

    return sorted(results, key=lambda x: x["score"], reverse=True)


def run_matching_for_invoice(invoice_id: int, threshold: float = 0.40, specific_tx_id: int = None) -> dict:
    """
    Run matching and save result.
    If specific_tx_id provided, use that transaction directly (bypasses scoring).
    Threshold lowered to 0.40 since bank CSV has no merchant name.
    """
    db  = get_db()
    cur = db.cursor()

    # If we know the exact transaction, use it directly
    if specific_tx_id:
        try:
            # Get transaction amount
            cur.execute("SELECT amount FROM transactions WHERE transaction_id = %s",
                       (specific_tx_id,))
            tx_row = cur.fetchone()
            if not tx_row:
                return {"matched": False, "reason": "transaction_not_found"}

            # Get invoice amount
            cur.execute("SELECT invoice_amount, fund_request_id FROM invoices WHERE invoice_id = %s",
                       (invoice_id,))
            inv_row = cur.fetchone()
            if not inv_row:
                return {"matched": False, "reason": "invoice_not_found"}

            tx_amt  = float(tx_row["amount"] or 0)
            inv_amt = float(inv_row["invoice_amount"] or 0)
            amount_match = tx_amt > 0 and abs(tx_amt - inv_amt) / max(tx_amt, 1) < 0.01

            # Save to invoice_transactions
            cur.execute("""
                INSERT INTO invoice_transactions
                    (invoice_id, transaction_id, match_score, match_method, is_confirmed)
                VALUES (%s, %s, %s, 'direct_link', %s)
                ON DUPLICATE KEY UPDATE match_score=VALUES(match_score)
            """, (invoice_id, specific_tx_id,
                  1.0 if amount_match else 0.7,
                  1 if amount_match else 0))

            # Update transaction status
            cur.execute("""
                UPDATE transactions
                SET verification_status = %s
                WHERE transaction_id = %s
            """, ('MATCHED' if amount_match else 'FLAGGED', specific_tx_id))

            # Update invoice status
            if amount_match:
                cur.execute(
                    "UPDATE invoices SET verification_status='VERIFIED' WHERE invoice_id=%s",
                    (invoice_id,))

            db.commit()
            return {
                "matched":        True,
                "transaction_id": specific_tx_id,
                "score":          1.0 if amount_match else 0.7,
                "amount_match":   amount_match,
                "tx_amount":      tx_amt,
                "inv_amount":     inv_amt,
            }
        except Exception as e:
            return {"matched": False, "reason": f"error: {str(e)}"}

    candidates = match_invoice(invoice_id)
    if not candidates or candidates[0]["score"] < threshold:
        return {"matched": False, "reason": "no_candidate_above_threshold",
                "best_score": candidates[0]["score"] if candidates else 0}

    best = candidates[0]
    db   = get_db()
    cur  = db.cursor()

    # Save match record
    cur.execute("""
        INSERT INTO invoice_transactions
            (invoice_id, transaction_id, match_score, match_method, is_confirmed)
        VALUES (%s, %s, %s, 'amount+date', %s)
        ON DUPLICATE KEY UPDATE
            match_score  = VALUES(match_score),
            match_method = VALUES(match_method)
    """, (invoice_id, best["transaction_id"], best["score"],
          1 if best["score"] >= 0.60 else 0))

    # Link fund_request to transaction
    cur.execute("""
        UPDATE transactions
        SET    fund_request_id = (
                   SELECT fund_request_id FROM invoices WHERE invoice_id = %s
               ),
               verification_status = CASE
                   WHEN %s = 1 THEN 'MATCHED'
                   ELSE 'FLAGGED'
               END
        WHERE  transaction_id = %s
    """, (invoice_id, 1 if best["amount_match"] else 0, best["transaction_id"]))

    # Update invoice status
    if best["amount_match"]:
        cur.execute("""
            UPDATE invoices SET verification_status = 'VERIFIED'
            WHERE  invoice_id = %s
        """, (invoice_id,))
    # If amount doesn't match → flag will be created by flagging service

    db.commit()
    return {
        "matched":        True,
        "transaction_id": best["transaction_id"],
        "score":          best["score"],
        "amount_match":   best["amount_match"],
    }
