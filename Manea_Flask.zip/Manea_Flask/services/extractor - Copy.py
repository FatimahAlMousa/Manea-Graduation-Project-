"""
Invoice Data Extractor

Parses raw OCR text (Arabic or English) to pull out structured invoice fields.
No ML training is required — the module relies entirely on:
  - Arabic-to-Western numeral normalization
  - STRICT keyword-based amount extraction
  - Multi-format date pattern matching

Extracted fields
----------------
amount : float | None   — the total/grand-total monetary value
date   : str   | None   — the invoice date, normalized to "YYYY-MM-DD"

Integration note
----------------
The public function extract_invoice_data() returns a plain dict.  The Manea
backend can compare its values directly against a database transaction record:

    result = extract_invoice_data(raw_text)
    if result["amount"] != transaction.amount:
        flag_for_audit(transaction)

Bounding box format
-------------------
Each bounding box is a list of 4 points: [[x0,y0],[x1,y1],[x2,y2],[x3,y3]]
representing the corners of the detected text region in pixel coordinates.
"""

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


# ===========================================================================
# Section 1 — Numeral normalization
# ===========================================================================

# Maps Arabic-Indic digits + decimal/thousands separators to Western equivalents.
# Arabic comma (٬) used as thousands sep → Western comma
# Arabic decimal point (٫) → Western period
_ARABIC_TO_WESTERN = str.maketrans("٠١٢٣٤٥٦٧٨٩٫٬", "0123456789.,")


def _normalize_numerals(text: str) -> str:
    """
    Convert Arabic-Indic digits (٠١٢…٩) and punctuation (٫٬) to their
    Western counterparts so that a single set of regex patterns covers both
    Arabic and English invoice formats.
    """
    return text.translate(_ARABIC_TO_WESTERN)


# ===========================================================================
# Section 2 — Amount extraction (STRICT and deterministic)
# ===========================================================================

# KEYWORDS THAT GUARANTEE A TOTAL/GRAND TOTAL (STRONG INDICATORS)
_TOTAL_KEYWORDS = [
    # English — must match exactly (case-insensitive)
    "total invoice",
    "invoice total",
    "grand total",
    "total amount",
    "amount due",
    "total amount due",
    # Arabic
    "إجمالي الفاتورة",
    "الفاتورة الإجمالية",
    "المجموع الإجمالي",
    "الإجمالي الكلي",
    "الإجمالي شامل",
    "إجمالي",
    "المجموع",
    # Net payable / final total
    "المبلغ الصافي",
    "صافي المبلغ",
    "المبلغ الإجمالي",
    "الإجمالي",
    "المبلغ النهائي",
]

# KEYWORDS THAT MUST BE EXCLUDED (these indicate VAT, tax, discount, etc.)
_EXCLUDE_KEYWORDS = [
    "vat", "tax", "discount", "qty", "quantity",
    "unit", "%", "percent",
    "ضريبة", "خصم", "كمية", "تكلفة الوحدة",
]

# Pattern to extract numbers from text
# Matches: 1234 | 1,234 | 1,234.56 | 1234.5
_MONEY_PATTERN = r"(?<![\w.])([1-9]\d{0,2}(?:[,،]\d{3})*(?:[.]\d{1,2})?|\d{1,7}[.]\d{1,2})(?![\w,])"


def _extract_numbers_from_line(line: str) -> list[float]:
    """
    Extract all monetary values from a single line.
    Handles: 1234, 1,234, 1,234.56 (and Arabic equivalents).
    
    Returns:
        List of float values found in the line, or empty list.
    """
    # Normalize numerals first
    normalized = _normalize_numerals(line)
    normalized = re.sub(
        r"(?:SAR|SR|QAR|AED|KWD|USD|\$|\u0631\u064a\u0627\u0644|\u0631\.\u0633)\s*(?=[1-9])",
        "", normalized, flags=re.IGNORECASE
    )
    normalized = re.sub(r"(\d)\s*[,\u060c]\s*(\d{3}(?=[,\u060c.\s]|$))", r"\1,\2", normalized)
    
    matches = re.findall(_MONEY_PATTERN, normalized)
    values = []
    
    for match in matches:
        try:
            # Remove thousands separators (both comma and Arabic comma)
            cleaned = match.replace(",", "").replace("،", "")
            value = float(cleaned)
            if value > 0:
                values.append(value)
        except ValueError:
            continue
    
    return values


def _line_contains_keyword(line: str, keywords: list[str]) -> bool:
    """Check if line contains any of the given keywords (case-insensitive)."""
    line_lower = line.lower()
    for keyword in keywords:
        if keyword.lower() in line_lower:
            return True
    return False


def _extract_amount(text: str) -> Optional[float]:
    """
    STRICT and DETERMINISTIC amount extraction.
    
    Algorithm:
      1. Split text into lines
      2. Find lines with STRONG total keywords (Total Invoice, Grand Total, etc.)
      3. From those lines only, extract the LARGEST number
      4. If no total keyword found, fallback to largest number in entire document
      5. Skip lines with exclusion keywords (VAT, Tax, Discount, Qty, Unit, %)
    
    Returns:
        The invoice total amount, or None if no suitable number found.
    """
    lines = text.splitlines()
    
    logger.info("=" * 60)
    logger.info("AMOUNT EXTRACTION (STRICT MODE)")
    logger.info("=" * 60)
    
    # ========================================================================
    # PASS 1: Look for lines with STRONG total keywords
    # ========================================================================
    logger.info("PASS 1: Searching for lines with TOTAL keywords...")
    
    total_amounts: list[float] = []
    
    for i, line in enumerate(lines):
        # Skip lines with exclusion keywords
        if _line_contains_keyword(line, _EXCLUDE_KEYWORDS):
            logger.debug(f"Line {i}: SKIP (has exclusion keyword): {line[:60]}")
            continue
        
        # Check if this line contains a strong total keyword
        if _line_contains_keyword(line, _TOTAL_KEYWORDS):
            logger.info(f"Line {i}: FOUND TOTAL KEYWORD: {line}")
            
            # Extract all numbers from this line
            numbers = _extract_numbers_from_line(line)
            if numbers:
                total_amounts.extend(numbers)
                logger.info(f"  → Extracted numbers: {numbers}")
            else:
                logger.info(f"  → No numbers found on this line")
    
    # If we found numbers on total keyword lines, return the largest
    if total_amounts:
        best_amount = max(total_amounts)
        logger.info(f"✓ RESULT: {best_amount} (from TOTAL keywords)")
        logger.info("=" * 60)
        return best_amount
    
    logger.warning("⚠ No lines with total keywords found. Using fallback...")
    
    # ========================================================================
    # PASS 2 (Fallback): Use the largest number in the entire document
    # ========================================================================
    logger.info("PASS 2: Fallback — extracting largest number from entire document...")
    
    all_amounts: list[float] = []
    
    for i, line in enumerate(lines):
        # Skip lines with exclusion keywords even in fallback
        if _line_contains_keyword(line, _EXCLUDE_KEYWORDS):
            continue
        
        numbers = _extract_numbers_from_line(line)
        if numbers:
            all_amounts.extend(numbers)
            logger.debug(f"Line {i}: {numbers}: {line[:60]}")
    
    if all_amounts:
        best_amount = max(all_amounts)
        logger.warning(f"⚠ RESULT (FALLBACK): {best_amount} (largest number in document)")
        logger.info("=" * 60)
        return best_amount
    
    logger.error("✗ No suitable numbers found in invoice text")
    logger.info("=" * 60)
    return None


def _extract_amount_with_bbox(
    text: str,
    details: list[dict],
) -> Optional[float]:
    """
    Extract amount using bounding-box details.
    
    For now, delegates to text-only extraction since the strict
    single keyword approach doesn't require spatial analysis.
    
    Args:
        text: Raw OCR text
        details: List of dicts with 'bbox', 'text', 'confidence' keys
    
    Returns:
        The amount as a float, or None if not found.
    """
    # Use text-only extraction — the strict keyword-only approach
    # doesn't need spatial proximity analysis
    return _extract_amount(text)


# ===========================================================================
# Section 3 — Date extraction
# ===========================================================================

# Arabic written month names → zero-padded Gregorian month number
_ARABIC_MONTHS: dict[str, str] = {
    "يناير": "01", "فبراير": "02", "مارس": "03", "أبريل": "04",
    "مايو": "05",  "يونيو": "06", "يوليو": "07", "أغسطس": "08",
    "سبتمبر": "09", "أكتوبر": "10", "نوفمبر": "11", "ديسمبر": "12",
    # Common alternate spellings
    "ابريل": "04", "اغسطس": "08",
}

# English written month names → zero-padded month number
_ENGLISH_MONTHS: dict[str, str] = {
    "january": "01", "february": "02", "march": "03",  "april": "04",
    "may":     "05", "june":     "06", "july":   "07", "august":    "08",
    "september": "09", "october": "10", "november": "11", "december": "12",
    # Abbreviations
    "jan": "01", "feb": "02", "mar": "03", "apr": "04",
    "jun": "06", "jul": "07", "aug": "08", "sep": "09",
    "oct": "10", "nov": "11", "dec": "12",
}

# Lines that contain a date label (Arabic or English).
# Covers: "Date", "Invoice Date", "E-Invoice Date", etc.
_DATE_LABEL_RE = re.compile(
    r"(?:"
    r"e[\s\-]*invoice\s*date"
    r"|invoice\s*date"
    r"|date"
    r"|تاريخ\s*الفاتورة"
    r"|التاريخ"
    r"|تاريخ"
    r")\s*[:#\-]?\s*",
    re.IGNORECASE | re.UNICODE,
)

# Numeric date:  DD/MM/YYYY  |  MM-DD-YYYY  |  YYYY.MM.DD  etc.
_NUMERIC_DATE_RE = re.compile(
    r"\b(\d{1,4})[/\-.](\d{1,2})[/\-.](\d{2,4})\b"
)

# Written month, day first:   "15 March 2024"  |  "15 مارس 2024"
_WRITTEN_DMY_RE = re.compile(
    r"\b(\d{1,2})\s+([A-Za-zأ-ي]+)\s+(\d{4})\b",
    re.UNICODE,
)

# Written month, month first: "March 15, 2024"  |  "March 15 2024"
_WRITTEN_MDY_RE = re.compile(
    r"\b([A-Za-zأ-ي]+)\s+(\d{1,2}),?\s+(\d{4})\b",
    re.UNICODE,
)


def _month_name_to_number(name: str) -> Optional[str]:
    """Resolve an Arabic or English month name to a zero-padded month number."""
    return _ARABIC_MONTHS.get(name) or _ENGLISH_MONTHS.get(name.lower())


def _written_date_to_iso(day: str, month_name: str, year: str) -> Optional[str]:
    """Convert (day-str, month-name, year-str) to 'YYYY-MM-DD', or None."""
    month_num = _month_name_to_number(month_name)
    if month_num:
        return f"{year}-{month_num}-{day.zfill(2)}"
    return None


def _resolve_numeric_date(a: str, b: str, c: str) -> Optional[str]:
    """
    Interpret three numeric groups as a date and return 'YYYY-MM-DD'.

    Disambiguation rules (reflect GCC/Saudi Arabia conventions):
      • 4-digit first group  → YYYY-MM-DD
      • 4-digit last group   → DD/MM/YYYY  (default for GCC; fall back to MM/DD)
      • 2-digit last group   → treat as 20YY, assume DD/MM
    """
    try:
        ai, bi, ci = int(a), int(b), int(c)
    except ValueError:
        return None

    if len(a) == 4 and 1 <= bi <= 12 and 1 <= ci <= 31:
        # YYYY-MM-DD
        return f"{a}-{bi:02d}-{ci:02d}"

    if len(c) == 4:
        if 1 <= ai <= 31 and 1 <= bi <= 12:
            # DD/MM/YYYY  ← assumed default (GCC standard)
            return f"{c}-{bi:02d}-{ai:02d}"
        if 1 <= bi <= 31 and 1 <= ai <= 12:
            # MM/DD/YYYY  ← fallback
            return f"{c}-{ai:02d}-{bi:02d}"

    if len(c) == 2:
        year = 2000 + ci
        if 1 <= ai <= 31 and 1 <= bi <= 12:
            return f"{year}-{bi:02d}-{ai:02d}"

    return None


def _search_for_date(text: str) -> Optional[str]:
    """
    Try all date patterns against a text block and return the first match.
    Order: written-DMY → written-MDY → numeric.
    """
    m = _WRITTEN_DMY_RE.search(text)
    if m:
        result = _written_date_to_iso(m.group(1), m.group(2), m.group(3))
        if result:
            return result

    m = _WRITTEN_MDY_RE.search(text)
    if m:
        result = _written_date_to_iso(m.group(2), m.group(1), m.group(3))
        if result:
            return result

    m = _NUMERIC_DATE_RE.search(text)
    if m:
        return _resolve_numeric_date(m.group(1), m.group(2), m.group(3))

    return None


def _extract_date(text: str) -> Optional[str]:
    """
    Extract the invoice date from raw OCR text.

    Tries, in order of confidence:
      Pass 1 — Lines that contain a date label ("Date:", "التاريخ:", …).
      Pass 2 — Written month-name formats anywhere in the text.
      Pass 3 — First numeric date pattern anywhere in the text.

    Returns:
        Date string in "YYYY-MM-DD" format, or None if not found.
    """
    normalized = _normalize_numerals(text)
    lines = normalized.splitlines()

    # Pass 1 — labelled lines only
    for line in lines:
        if _DATE_LABEL_RE.search(line):
            result = _search_for_date(line)
            if result:
                return result

    # Pass 2 & 3 — scan the whole text
    return _search_for_date(normalized)


# ===========================================================================
# Section 4 — Currency extraction
# ===========================================================================

# Currency keyword maps: each entry is (regex_pattern, normalized_code)
# NOTE: No \b word boundaries for SR/SAR — they often appear glued to digits
#       e.g. "SR1,160.00" or "SAR250.00"
_CURRENCY_PATTERNS: list[tuple[re.Pattern, str]] = [
    # SAR — Saudi Riyal (order matters: longer/more specific patterns first)
    (re.compile(r"SAR", re.IGNORECASE), "SAR"),
    (re.compile(r"SR(?=\s*[\d,،٠-٩]|$|\s)", re.IGNORECASE), "SAR"),  # SR followed by digit/space/end
    (re.compile(r"(?<![A-Za-z])SR(?![A-Za-z])", re.IGNORECASE), "SAR"),  # SR not surrounded by letters
    (re.compile(r"Saudi\s+Riyal", re.IGNORECASE), "SAR"),
    (re.compile(r"ريال", re.UNICODE), "SAR"),
    (re.compile(r"ر\.س", re.UNICODE), "SAR"),
    # USD — US Dollar
    (re.compile(r"\bUSD\b", re.IGNORECASE), "USD"),
    (re.compile(r"\$"), "USD"),
    (re.compile(r"\bDollar\b", re.IGNORECASE), "USD"),
    (re.compile(r"دولار", re.UNICODE), "USD"),
]

# Keywords that indicate a total/amount line (reused to prefer currency near total)
_AMOUNT_LINE_KEYWORDS = _TOTAL_KEYWORDS + ["total", "amount", "المبلغ"]


def _find_currencies_in_text(text: str) -> list[tuple[int, str]]:
    """
    Find all currency occurrences in text.
    Returns list of (char_position, currency_code) sorted by position.
    Deduplicates overlapping matches at the same position.
    """
    found: list[tuple[int, str]] = []
    seen_positions: set[int] = set()

    for pattern, code in _CURRENCY_PATTERNS:
        for match in pattern.finditer(text):
            pos = match.start()
            if pos not in seen_positions:
                seen_positions.add(pos)
                found.append((pos, code))

    found.sort(key=lambda x: x[0])
    return found


def _extract_currency(text: str) -> Optional[str]:
    """
    Detect the invoice currency from raw OCR text.

    Strategy:
      1. Search lines that contain a total/amount keyword — prefer currency found there.
      2. If multiple currencies found near totals, pick the first one.
      3. If no currency near totals, fall back to any currency found in the document.
      4. Return None if no currency detected.

    Returns:
        "SAR", "USD", or None.
    """
    lines = text.splitlines()

    # Pass 1 — look for currency on total/amount lines
    for line in lines:
        line_lower = line.lower()
        if any(kw.lower() in line_lower for kw in _AMOUNT_LINE_KEYWORDS):
            hits = _find_currencies_in_text(line)
            if hits:
                code = hits[0][1]
                logger.info("Currency '%s' found near total keyword: %s", code, line[:80])
                return code

    # Pass 2 — fallback: any currency anywhere in the document
    hits = _find_currencies_in_text(text)
    if hits:
        # If only one distinct currency, return it
        codes = list(dict.fromkeys(c for _, c in hits))  # preserve order, dedupe
        if len(codes) == 1:
            logger.info("Currency '%s' found in document (fallback).", codes[0])
            return codes[0]
        # Multiple distinct currencies — return the first one encountered
        logger.warning("Multiple currencies found %s — returning first.", codes)
        return codes[0]

    logger.warning("No currency found in invoice text.")
    return None


# ===========================================================================
# Section 5 — Invoice number extraction
# ===========================================================================

# ---------------------------------------------------------------------------
# Invoice number extraction — regex-based, tolerant of Arabic OCR noise
# ---------------------------------------------------------------------------
#
# WHY REGEX INSTEAD OF STRING MATCHING:
# EasyOCR frequently introduces extra spaces inside Arabic words,
# different alef forms (ا/أ/إ), and kashida characters.
# Regex with \s* between word parts handles all of these.

# Arabic label patterns
_INV_ARABIC_RE = re.compile(
    r'(?:'
    r'رقم\s+[اأإآٱ]ل\s*ف[اأ]تور[ةه]'
    r'|ف[اأ]تور[ةه]\s+رقم'
    r')',
    re.UNICODE,
)

# English label patterns
_INV_ENGLISH_RE = re.compile(
    r'(?:e[\s\-]*invoice\b|(?:invoice|inv)\s*(?:no\.?|number|#|num\.?))',
    re.IGNORECASE,
)

# Valid invoice number value
_INV_VALUE_RE = re.compile(
    r'([A-Za-z0-9][A-Za-z0-9\-_\/]{2,30})',
    re.UNICODE,
)


def _extract_invoice_number(text: str) -> Optional[str]:
    """
    Extract the invoice number from raw OCR text.

    Uses regex to tolerate EasyOCR noise: extra spaces in Arabic words,
    different alef forms, missing colons, double spaces.

    Pass 1: line-by-line scan for label then grab first valid number.
    Pass 2: fallback full-text search near keyword patterns.

    Returns:
        Clean invoice number string (e.g. "3235", "INV-2023-001"), or None.
    """
    lines = text.splitlines()

    def _first_number_after(line: str, match_end: int) -> Optional[str]:
        remainder = line[match_end:].lstrip(": #|\t\u200f\u200e\u202a\u202b ")
        m = _INV_VALUE_RE.search(remainder)
        if m:
            val = m.group(1).strip("-_/ ")
            return val if val else None
        return None

    # Date string pattern — used to reject date lines as invoice numbers
    _date_line_re = re.compile(r"\d{4}[-/.]\d{2}[-/.]\d{2}")
    _year_only_re = re.compile(r"^(?:19|20)\d{2}$")

    def _clean_inv_val(raw: str) -> Optional[str]:
        """Return val if it looks like an invoice number, else None."""
        val = raw.strip("-_/ ")
        if not val:
            return None
        # Reject bare years and date strings
        if _year_only_re.match(val):
            return None
        # Reject VAT/CR/phone — these have long CONTINUOUS digit runs (>=10).
        # Alphanumeric invoice numbers like "07-21-014290C" have short runs
        # split by separators, so we check the longest unbroken digit sequence.
        longest_run = max((len(m.group()) for m in re.finditer(r"\d+", val)), default=0)
        if longest_run >= 10:
            return None
        return val

    # Pass 1: line-by-line — check same line, then prev line (RTL), then next line
    for i, line in enumerate(lines):
        for pat in (_INV_ARABIC_RE, _INV_ENGLISH_RE):
            m = pat.search(line)
            if not m:
                continue

            # (a) value after label on same line
            val = _clean_inv_val(_first_number_after(line, m.end()) or "")
            if val:
                logger.info("Invoice number (same-line after): %s | %r", val, line[:70])
                return val

            # (a2) value BEFORE label on same line
            # Handles RTL layout "21160 :رقم الفاتورة" and table "|21160|label|"
            prefix = line[:m.start()].rstrip(": #|	‏‎‪‫ ")
            if prefix:
                for pm in reversed(list(_INV_VALUE_RE.finditer(prefix))):
                    val = _clean_inv_val(pm.group(1))
                    if val:
                        # Skip if it looks like part of a date
                        if not _date_line_re.search(prefix[pm.start():pm.end()+5]):
                            logger.info("Invoice number (same-line before/RTL): %s | %r", val, line[:70])
                            return val

            # (b) value on PREVIOUS line — RTL layout: value box left of label box
            if i > 0:
                prev = lines[i - 1].strip()
                if not _date_line_re.search(prev) and not pat.search(prev):
                    vm = _INV_VALUE_RE.search(prev)
                    if vm:
                        val = _clean_inv_val(vm.group(1))
                        if val:
                            logger.info("Invoice number (prev line): %s | label=%r", val, line[:50])
                            return val

            # (c) value on NEXT line
            if i + 1 < len(lines):
                nxt = lines[i + 1].strip()
                if not _date_line_re.search(nxt):
                    vm = _INV_VALUE_RE.search(nxt)
                    if vm:
                        val = _clean_inv_val(vm.group(1))
                        if val:
                            logger.info("Invoice number (next line): %s | label=%r", val, line[:50])
                            return val

    # Pass 2: fallback full-text
    fallback = re.search(
        r'(?:'
        r'رقم\s+[اأإآٱ]ل\s*ف[اأ]تور[ةه]'
        r'|ف[اأ]تور[ةه]\s+رقم'
        r'|e[\s\-]*invoice\b'
        r'|(?:invoice|inv)\s*(?:no\.?|number|#|num\b)'
        r')[\s:#|]*'
        r'([A-Za-z0-9][A-Za-z0-9\-_\/]{2,30})',
        text,
        re.IGNORECASE | re.UNICODE,
    )
    if fallback:
        val = fallback.group(1).strip("-_/ ")
        if val:
            logger.info("Invoice number (fallback) found: %s", val)
            return val

    logger.warning("Invoice number not found in invoice text.")
    return None



# ===========================================================================
# Section 5 — Vendor name extraction (deterministic header-first)
# ===========================================================================
#
# Algorithm:
#   Pass 1 — top 30% of document, lines with strong entity keywords
#   Pass 2 — top 30%, any line that is not a known field label
#   Pass 3 — top 60% fallback with entity keywords only
#
# A line passes if it:
#   - Contains a business entity marker (مؤسسة, Est, Trading, LLC, …)
#   - Does NOT contain invoice/date/VAT/customer/total labels
#   - Is not a pure descriptor (Wholesale and retail)
#   - Has 2–10 words, mostly alphabetic characters
#
# The highest-confidence candidate is returned.
# If Arabic + English versions both exist in the header, the one with
# an entity marker is preferred; longer wins on a tie.

# ── Entity markers (strong = real company name) ───────────────────────────
_VN_ENTITY_AR = re.compile(
    r"مؤسسة|مؤسسه|شركة|شركه|مجموعة|مجموعه|مصنع|مكتب|معرض\s+و|مستودع\s+و"
    r"|للتجارة|للمقاولات|للكهرباء|للديكور|للخدمات|للتوريد",
    re.UNICODE,
)
_VN_ENTITY_EN = re.compile(
    r"\bEst\.?\b|\bCo\.?\b|\bLtd\.?\b|\bLLC\b|\bCorp\.?\b|\bInc\.?\b"
    r"|\bGroup\b|\bTrading\b|\bCompany\b|\bEnterprises?\b"
    r"|\bFactory\b|\bSupply\b|\bSolutions?\b|\bTechnology\b|\bIndustries\b",
    re.IGNORECASE,
)

# ── Hard reject: these labels identify a field, not a company name ─────────
_VN_REJECT_EN = re.compile(
    r"^\s*(?:invoice\s*(?:no|number|date|#)|vat\s*(?:no|number|reg)|"
    r"cr\s*no|tax\s*(?:no|invoice)|commercial\s*re(?:g)?|"
    r"date|total|subtotal|amount|balance|discount|paid|receipt|"
    r"bill\s*to|ship\s*to|customer|client|receiver|"
    r"vendor\s*(?:name)?|supplier\s*(?:name)?|"  # label rows, not values
    r"item|description|qty|quantity|unit|price|note|remarks|signature|"
    r"ref(?:erence)?|tel|phone|fax|address|po\s*box|www\.|http)",
    re.IGNORECASE,
)
_VN_REJECT_AR = re.compile(
    r"اسم\s*العميل|عنوان\s*العميل|رقم\s*الفاتورة|تاريخ\s*الفاتورة"
    r"|الرقم\s*الضريبي|السجل\s*التجاري|رقم\s*السجل"
    r"|اسم\s*الفرع|رقم\s*(?:هاتف\s*)?الفرع|اسم\s*البائع|اسم\s*الموظف"
    r"|هاتف\s*العميل|جوال\s*العميل"
    r"|الإجمالي|الاجمالي|المجموع|الخصم|الضريبة|المبلغ|الكمية|الوحدة"
    r"|ملاحظات|التوقيع|المستلم",
    re.UNICODE,
)

# ── Pure descriptor: business activity, not entity name ───────────────────
_VN_DESCRIPTOR = re.compile(
    r"^(?:wholesale(?:\s+and\s+retail)?|retail(?:\s+and\s+wholesale)?"
    r"|import(?:\s+(?:and|&)\s+export)?|export(?:\s+(?:and|&)\s+import)?"
    r"|general\s+(?:trading|merchandise)|manufacturing|"
    r"|الجملة(?:\s+والتجزئة)?|التجزئة|نشاط\s+تجاري|خدمات\s+عامة)$",
    re.IGNORECASE | re.UNICODE,
)

# ── OCR normalisation ─────────────────────────────────────────────────────
_VN_OCR_FIXES = [
    (re.compile(r"مؤسسه"), "مؤسسة"),
    (re.compile(r"شركه"),  "شركة"),
    (re.compile(r"مجموعه"), "مجموعة"),
]

# ── Label prefix to strip from result ────────────────────────────────────
_VN_LABEL_PREFIX = re.compile(
    r"^(?:vendor|supplier|company|from|issued\s*by|"
    r"مورد|اسم\s*(?:المورد|الشركة))\s*[:\-]\s*",
    re.IGNORECASE | re.UNICODE,
)


def _vn_clean(line: str) -> str:
    """Normalise spaces, fix OCR Arabic errors, strip label prefixes."""
    line = " ".join(line.split())
    for pat, repl in _VN_OCR_FIXES:
        line = pat.sub(repl, line)
    line = _VN_LABEL_PREFIX.sub("", line).strip()
    return line


def _vn_is_valid(line: str) -> bool:
    """
    Return True if line is a plausible company name line.
    Rejects: field labels, pure descriptors, digit-heavy noise, URLs.
    """
    s = line.strip()
    if not s or len(s) < 3:
        return False
    # Hard rejects
    if _VN_REJECT_EN.search(s):
        return False
    if _VN_REJECT_AR.search(s):
        return False
    if _VN_DESCRIPTOR.match(s):
        return False
    # Reject lines starting with preposition لـ (descriptor suffix)
    if re.match(r"^ل[لا]?\S", s, re.UNICODE) and len(s.split()) < 3:
        return False
    # Reject noisy lines: <40% real letters
    letter_chars = len(re.sub(r"[^؀-ۿA-Za-z]", "", s))
    if len(s) > 4 and letter_chars / len(s) < 0.40:
        return False
    # Reject long-number lines (VAT / CR / phone)
    if re.search(r"\d{7,}", s):
        return False
    # Reject URLs / emails
    if re.search(r"https?://|www\.|@", s):
        return False
    words = s.split()
    if len(words) > 10 or len(words) < 2:   # single-word stubs rejected here
        return False
    return True


def _vn_has_entity(line: str) -> bool:
    """True if line contains a business entity keyword."""
    return bool(_VN_ENTITY_AR.search(line) or _VN_ENTITY_EN.search(line))


def _vn_deduplicate(text: str) -> str:
    """Remove consecutive duplicate words / half-string repetition."""
    text = " ".join(text.split())
    words = text.split()
    half = len(words) // 2
    if half > 1 and words[:half] == words[half:half * 2]:
        return " ".join(words[:half])
    deduped = [words[0]] if words else []
    for w in words[1:]:
        if w != deduped[-1]:
            deduped.append(w)
    return " ".join(deduped)


def _extract_vendor_name(text: str) -> Optional[str]:
    """
    Deterministic header-first vendor extraction.

    Pass 1 — top 30%: lines with entity keywords, reject field labels.
    Pass 2 — top 30%: any valid non-label line (looser, still header-only).
    Pass 3 — top 60%: entity keywords only (fallback for longer invoices).

    Among candidates, prefer:
      - Lines with entity markers over plain names
      - Longer line as tie-breaker (more complete name)

    Arabic + English versions are kept separate; the better one is returned
    (entity marker present AND longer wins).
    """
    lines = text.splitlines()
    total = len(lines)
    top30 = max(1, int(total * 0.30))
    top60 = max(1, int(total * 0.60))

    # Field label patterns — if the PREVIOUS line matches, current line is
    # a field value (branch, seller, customer) and must be rejected as vendor
    _field_label_re = re.compile(
        r"(?:اسم\s*الفرع|اسم\s*البائع|اسم\s*العميل|اسم\s*الموظف"
        r"|عنوان\s*العميل|رقم\s*هاتف\s*الفرع|هاتف\s*العميل"
        r"|bill\s*to|ship\s*to|customer\s*name|branch\s*name"
        r"|sold\s*to|delivered\s*to)\s*:?\s*$",
        re.IGNORECASE | re.UNICODE,
    )

    def _prev_is_field_label(i: int) -> bool:
        """True if the line before i is a standalone field label line."""
        if i == 0:
            return False
        prev = lines[i - 1].strip()
        return bool(_field_label_re.search(prev))

    def _collect(line_range, require_entity: bool) -> list:
        found = []
        for i in line_range:
            if i >= len(lines):
                break
            s = lines[i].strip()
            if not s:
                continue
            if not _vn_is_valid(s):
                continue
            # Reject if previous line is a field label (split label/value OCR)
            if _prev_is_field_label(i):
                logger.debug("  Vendor skip [%d] (prev is field label): %r", i, s[:50])
                continue
            if require_entity and not _vn_has_entity(s):
                continue
            found.append((i, s))
        return found

    # ── Pass 1: top 25%, entity keyword required (primary) ──────────────────
    candidates = _collect(range(top30), require_entity=True)
    logger.info("  Vendor Pass1 (top30+entity): %d candidates", len(candidates))

    # ── Pass 2: top 60%, entity keyword still required (wider zone only) ──
    # Pass 2 does NOT relax the entity requirement — that was the root cause
    # of wrong selections ("any valid line" allowed body text to win)
    if not candidates:
        candidates = _collect(range(top60), require_entity=True)
        logger.info("  Vendor Pass2 (top60+entity): %d candidates", len(candidates))

    if not candidates:
        logger.warning("  Vendor: no candidates found")
        return None

    # ── Scoring (replaces simple entity-bool / length tie-breaker) ─────────
    def _vn_rank(item) -> int:
        idx, s = item
        score = 0

        # Entity keyword is the strongest signal
        if _vn_has_entity(s):
            score += 5

        # Prefer realistic name length (2–6 words)
        words = s.split()
        if 2 <= len(words) <= 6:
            score += 3

        # Longer name is more complete
        if len(s) > 8:
            score += 1

        # Bilingual line (Arabic + Latin) is a very strong vendor signal
        has_ar = any("؀" <= c <= "ۿ" for c in s)
        has_en = any(c.isascii() and c.isalpha() for c in s)
        if has_ar and has_en:
            score += 2

        # Penalise bare generic stubs
        if s.strip() in {"شركة", "مؤسسة", "مؤسسه", "شركه"}:
            score -= 10

        # Penalise lines containing field/contact keywords
        if any(x in s.lower() for x in ["tel", "mobile", "vat", "cr no", "phone"]):
            score -= 5

        return score

    # Log all candidates with scores
    for idx, s in candidates:
        sc = _vn_rank((idx, s))
        logger.info("  Vendor candidate [%02d] score=%d | %r", idx, sc, s[:70])

    candidates.sort(key=_vn_rank, reverse=True)
    best_idx, best_line = candidates[0]
    result = _vn_clean(best_line)

    # ── Safe merge: only when base line already contains entity keyword ─────
    # Prevents merging random lines onto weak candidates
    for delta in (1, -1):
        adj_i = best_idx + delta
        if not (0 <= adj_i < len(lines)):
            continue
        adj = lines[adj_i].strip()
        if not adj or not _vn_is_valid(adj):
            continue
        # Only merge if the BASE line has an entity keyword
        if not _vn_has_entity(result):
            continue
        # Only merge preposition-prefix continuations (لتجارة...) or entity lines
        is_continuation = bool(
            re.match(r"^ل[لا]?\S", adj, re.UNICODE) and len(adj.split()) >= 2
        )
        if is_continuation and not _VN_DESCRIPTOR.match(adj):
            adj_clean = _vn_clean(adj)
            merged = (result + " " + adj_clean) if delta == 1 else (adj_clean + " " + result)
            if len(merged.split()) <= 10:
                result = merged
                logger.info("  Vendor: merged continuation -> %r", result)
                break

    result = _vn_deduplicate(result)
    logger.info("  Vendor SELECTED: %r (line %d)", result, best_idx)
    return result if result else None


# ===========================================================================
# Section 6 — Public API
# ===========================================================================

def extract_invoice_data(raw_text: str, details: Optional[list] = None) -> dict:
    """
    Extract structured invoice fields from raw OCR text.

    Args:
        raw_text: Concatenated text output from the OCR engine.
        details: Optional list of dicts with 'bbox', 'text', 'confidence' keys.
                 When provided, enables enhanced extraction (currently unused for amount).

    Returns:
        {
            "amount":         float | None,  # detected total amount
            "date":           str   | None,  # detected date in "YYYY-MM-DD" format
            "currency":       str   | None,  # "SAR", "USD", or None
            "invoice_number": str   | None,  # e.g. "INV-2023-001" or "12345"
        }

    Both fields are None when extraction fails, allowing the Manea backend
    to flag the invoice for manual review rather than comparing bad data.

    Integration example:
        data = extract_invoice_data(raw_text)

        if data["amount"] is None or data["date"] is None:
            # Incomplete extraction — flag for auditor review
            transaction.status = "needs_review"
        elif abs(data["amount"] - transaction.amount) > 0.01:
            # Amount mismatch — flag as suspicious
            transaction.status = "flagged"
        else:
            transaction.status = "verified"
    """
    amount         = _extract_amount(raw_text)
    date           = _extract_date(raw_text)
    currency       = _extract_currency(raw_text)
    invoice_number = _extract_invoice_number(raw_text)
    vendor_name    = _extract_vendor_name(raw_text)

    if amount is None:
        logger.warning("Amount not found in invoice text.")
    if date is None:
        logger.warning("Date not found in invoice text.")
    if currency is None:
        logger.warning("Currency not found in invoice text.")
    if invoice_number is None:
        logger.warning("Invoice number not found in invoice text.")
    if vendor_name is None:
        logger.warning("Vendor name not found in invoice text.")

    return {
        "amount":         amount,
        "date":           date,
        "currency":       currency,
        "invoice_number": invoice_number,
        "vendor_name":    vendor_name,
    }